# FoodBridge backend

FastAPI + SQLAlchemy + SQLite. Setup, environment variables, seeding and test commands are in the
[top-level README](../README.md).

Quick start (from this folder):

```bash
python3 -m venv .venv && source .venv/bin/activate     # Windows: python -m venv .venv ; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload       # http://localhost:8000/docs
pytest
```

Layering rule: **routes** (`app/api`) only handle HTTP; **services** (`app/services`) hold business rules;
the matching engine's scoring (`app/matching/scoring.py`) and the status machine (`app/services/status_machine.py`)
are pure Python with no database so they can be tested and explained on their own.
