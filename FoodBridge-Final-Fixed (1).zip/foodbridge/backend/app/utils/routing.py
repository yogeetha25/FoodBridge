"""Optional OSRM road-distance lookup. Always returns None on any failure so the caller
can fall back to straight-line (Haversine) distance. The app never depends on this."""
import json
import logging
import urllib.request
from typing import Optional, Tuple

from app.config import settings

log = logging.getLogger("foodbridge.routing")


def osrm_route(lat1: float, lng1: float, lat2: float, lng2: float,
               timeout: float = 3.0) -> Optional[Tuple[float, float]]:
    """Return (distance_km, duration_minutes) by road, or None if unavailable."""
    # NOTE: OSRM expects "longitude,latitude" order.
    url = (f"{settings.OSRM_BASE_URL}/route/v1/driving/"
           f"{lng1},{lat1};{lng2},{lat2}?overview=false")
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        route = data["routes"][0]
        return route["distance"] / 1000.0, route["duration"] / 60.0
    except Exception as exc:  # noqa: BLE001 - any failure means "fall back"
        log.warning("OSRM unavailable, using straight-line distance: %s", exc)
        return None
