"""Operating-hours parsing. Format: "HH:MM-HH:MM" (local time, may cross midnight) or "24/7"."""
import re
from datetime import datetime, timedelta

_PATTERN = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)-([01]\d|2[0-3]):([0-5]\d)$")
ALWAYS_OPEN = (0, 1440)


def parse_hours(value: str):
    """Return (start_minute, end_minute) since local midnight. Raises ValueError if invalid."""
    v = (value or "").strip().lower().replace(" ", "")
    if v in ("24/7", "24x7"):
        return ALWAYS_OPEN
    m = _PATTERN.match(v)
    if not m:
        raise ValueError('Operating hours must look like "09:00-18:00" or "24/7"')
    start = int(m.group(1)) * 60 + int(m.group(2))
    end = int(m.group(3)) * 60 + int(m.group(4))
    if start == end:
        raise ValueError("Opening and closing time must be different")
    return start, end


def is_valid_hours(value: str) -> bool:
    try:
        parse_hours(value)
        return True
    except ValueError:
        return False


def is_open_at(hours: str, when_utc: datetime, utc_offset_minutes: int) -> bool:
    """Is an organization with these (local-time) hours open at the given UTC moment?"""
    start, end = parse_hours(hours)
    if (start, end) == ALWAYS_OPEN:
        return True
    local = when_utc + timedelta(minutes=utc_offset_minutes)
    minute = local.hour * 60 + local.minute
    if start < end:
        return start <= minute < end
    return minute >= start or minute < end  # window crosses midnight
