"""SQLAlchemy ORM models. One class per table in the ER diagram."""
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (JSON, Boolean, CheckConstraint, DateTime, Float, ForeignKey, Index, Integer,
                        String, Text, UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.constants import (AVAILABLE, REPORT_OPEN, VERIFICATION_PENDING)
from app.database.session import Base
from app.utils.time import utcnow


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), index=True)           # DONOR | ORGANIZATION | ADMIN
    full_name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[Optional[str]] = mapped_column(String(30))
    donor_type: Mapped[Optional[str]] = mapped_column(String(30))       # only for donors
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    organization: Mapped[Optional["Organization"]] = relationship(back_populates="user", uselist=False)
    donations: Mapped[List["Donation"]] = relationship(back_populates="donor")


class Organization(Base):
    __tablename__ = "organizations"
    __table_args__ = (
        CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_org_lat"),
        CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_org_lng"),
        CheckConstraint("service_radius_km > 0", name="ck_org_radius"),
        CheckConstraint("max_capacity_meals > 0", name="ck_org_capacity"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)  # 1:1 with user
    name: Mapped[str] = mapped_column(String(160), index=True)
    organization_type: Mapped[str] = mapped_column(String(30))
    contact_person: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str] = mapped_column(String(30))
    address: Mapped[str] = mapped_column(String(300))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    service_radius_km: Mapped[float] = mapped_column(Float, default=10.0)
    max_capacity_meals: Mapped[int] = mapped_column(Integer)
    preferred_categories: Mapped[list] = mapped_column(JSON, default=list)   # [] means "accepts all"
    food_preferences: Mapped[str] = mapped_column(String(20), default="BOTH")
    operating_hours: Mapped[str] = mapped_column(String(20), default="09:00-18:00")
    verification_status: Mapped[str] = mapped_column(String(15), default=VERIFICATION_PENDING, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    user: Mapped["User"] = relationship(back_populates="organization")
    matches: Mapped[List["Match"]] = relationship(back_populates="organization")
    pickups: Mapped[List["Pickup"]] = relationship(back_populates="organization")


class Donation(Base):
    __tablename__ = "donations"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_donation_quantity"),
        CheckConstraint("estimated_meals > 0", name="ck_donation_meals"),
        CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_donation_lat"),
        CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_donation_lng"),
        Index("ix_donations_status_expiry", "status", "available_until"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    donor_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(160))
    category: Mapped[str] = mapped_column(String(30))
    is_vegetarian: Mapped[bool] = mapped_column(Boolean)
    quantity: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(15))
    estimated_meals: Mapped[int] = mapped_column(Integer)
    prepared_at: Mapped[datetime] = mapped_column(DateTime)
    available_until: Mapped[datetime] = mapped_column(DateTime)
    pickup_address: Mapped[str] = mapped_column(String(300))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    description: Mapped[Optional[str]] = mapped_column(Text)
    handling_notes: Mapped[Optional[str]] = mapped_column(Text)
    contact_info: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default=AVAILABLE, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    donor: Mapped["User"] = relationship(back_populates="donations")
    matches: Mapped[List["Match"]] = relationship(back_populates="donation", order_by="Match.rank",
                                                  cascade="all, delete-orphan")
    pickup: Mapped[Optional["Pickup"]] = relationship(back_populates="donation", uselist=False,
                                                      cascade="all, delete-orphan")
    impact: Mapped[Optional["ImpactRecord"]] = relationship(back_populates="donation", uselist=False,
                                                            cascade="all, delete-orphan")
    reports: Mapped[List["Report"]] = relationship(back_populates="donation")


class Match(Base):
    __tablename__ = "matches"
    __table_args__ = (UniqueConstraint("donation_id", "organization_id", name="uq_match_donation_org"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    donation_id: Mapped[int] = mapped_column(ForeignKey("donations.id", ondelete="CASCADE"), index=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    score: Mapped[float] = mapped_column(Float)
    score_breakdown: Mapped[dict] = mapped_column(JSON)
    rank: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    donation: Mapped["Donation"] = relationship(back_populates="matches")
    organization: Mapped["Organization"] = relationship(back_populates="matches")


class Pickup(Base):
    __tablename__ = "pickups"

    id: Mapped[int] = mapped_column(primary_key=True)
    # unique: a donation can be accepted by only one organization, ever (second line of defence
    # behind the atomic UPDATE used in the accept service)
    donation_id: Mapped[int] = mapped_column(ForeignKey("donations.id", ondelete="CASCADE"), unique=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    scheduled_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    collected_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    notes: Mapped[Optional[str]] = mapped_column(Text)

    donation: Mapped["Donation"] = relationship(back_populates="pickup")
    organization: Mapped["Organization"] = relationship(back_populates="pickups")


class ImpactRecord(Base):
    __tablename__ = "impact_records"

    id: Mapped[int] = mapped_column(primary_key=True)
    donation_id: Mapped[int] = mapped_column(ForeignKey("donations.id", ondelete="CASCADE"), unique=True)
    meals_redistributed: Mapped[int] = mapped_column(Integer)
    quantity_kg_est: Mapped[float] = mapped_column(Float)       # ESTIMATE
    people_served_est: Mapped[int] = mapped_column(Integer)     # ESTIMATE
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    donation: Mapped["Donation"] = relationship(back_populates="impact")


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    donation_id: Mapped[int] = mapped_column(ForeignKey("donations.id", ondelete="CASCADE"), index=True)
    reporter_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    reason: Mapped[str] = mapped_column(String(30))
    details: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(15), default=REPORT_OPEN, index=True)
    resolved_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    resolution_notes: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    donation: Mapped["Donation"] = relationship(back_populates="reports")
    reporter: Mapped["User"] = relationship(foreign_keys=[reporter_id])
    resolver: Mapped[Optional["User"]] = relationship(foreign_keys=[resolved_by])
