"""Tiny in-memory brute-force protection for the login endpoint.

After LOGIN_MAX_ATTEMPTS failed sign-ins for the same (client IP, email) inside LOGIN_WINDOW_SECONDS,
further attempts are refused with HTTP 429 until the window passes. A successful sign-in clears the
counter. State lives in process memory, which is enough for one server process; with several workers
or servers use a shared store (e.g. Redis) instead. Keying on IP *and* email means an attacker cannot
lock a real user out of their account from a different machine.
"""
import threading
import time
from typing import Callable, Dict, List, Tuple

from app.config import settings
from app.errors import AppError


class TooManyAttemptsError(AppError):
    status_code = 429
    code = "too_many_attempts"


class LoginThrottle:
    def __init__(self, clock: Callable[[], float] = time.monotonic):
        self._clock = clock
        self._lock = threading.Lock()
        self._failures: Dict[Tuple[str, str], List[float]] = {}

    @staticmethod
    def _key(ip: str, email: str) -> Tuple[str, str]:
        return (ip or "unknown", (email or "").strip().lower())

    def _recent(self, key: Tuple[str, str]) -> List[float]:
        cutoff = self._clock() - settings.LOGIN_WINDOW_SECONDS
        recent = [t for t in self._failures.get(key, []) if t > cutoff]
        if recent:
            self._failures[key] = recent
        else:
            self._failures.pop(key, None)
        return recent

    def check(self, ip: str, email: str) -> None:
        """Raise TooManyAttemptsError if this client has used up its attempts."""
        with self._lock:
            recent = self._recent(self._key(ip, email))
            if len(recent) >= settings.LOGIN_MAX_ATTEMPTS:
                wait = int(recent[0] + settings.LOGIN_WINDOW_SECONDS - self._clock()) + 1
                raise TooManyAttemptsError(
                    f"Too many failed sign-in attempts. Please try again in {max(1, (wait + 59) // 60)} minute(s).")

    def record_failure(self, ip: str, email: str) -> None:
        with self._lock:
            key = self._key(ip, email)
            self._recent(key)
            self._failures.setdefault(key, []).append(self._clock())
            if len(self._failures) > 10_000:  # bound memory under a flood of distinct keys
                oldest = sorted(self._failures, key=lambda k: self._failures[k][-1])[:5_000]
                for k in oldest:
                    self._failures.pop(k, None)

    def reset(self, ip: str, email: str) -> None:
        with self._lock:
            self._failures.pop(self._key(ip, email), None)

    def clear_all(self) -> None:
        with self._lock:
            self._failures.clear()


login_throttle = LoginThrottle()
