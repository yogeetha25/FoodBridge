"""FastAPI dependencies: who is calling, and are they allowed?"""
from typing import Optional

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.auth.security import decode_access_token
from app.constants import ROLE_ADMIN, ROLE_DONOR, ROLE_ORG
from app.database.session import get_db
from app.errors import ForbiddenError, UnauthorizedError
from app.models import User

# auto_error=False so *we* control the error message/status. Also gives Swagger an "Authorize" button.
bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
                     db: Session = Depends(get_db)) -> User:
    if credentials is None:
        raise UnauthorizedError("Please sign in to continue.", code="not_authenticated")
    payload = decode_access_token(credentials.credentials)
    try:
        user_id = int(payload["sub"])
    except (KeyError, ValueError):
        raise UnauthorizedError("Invalid authentication token.", code="invalid_token")
    user = db.get(User, user_id)
    if user is None:
        raise UnauthorizedError("This account no longer exists.", code="invalid_token")
    if not user.is_active:
        raise ForbiddenError("This account has been deactivated.", code="account_inactive")
    return user


def require_roles(*roles: str):
    """Build a dependency that only lets the given roles through (role-based authorization)."""
    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise ForbiddenError("You do not have permission to do that.", code="wrong_role")
        return user
    return checker


require_donor = require_roles(ROLE_DONOR)
require_org = require_roles(ROLE_ORG)
require_admin = require_roles(ROLE_ADMIN)
