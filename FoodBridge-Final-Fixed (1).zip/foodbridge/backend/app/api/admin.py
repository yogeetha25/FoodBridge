from typing import List, Optional

from fastapi import APIRouter, Depends
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.auth.dependencies import require_admin
from app.api.serializers import serialize_donation, serialize_org_full, serialize_org_list, serialize_user
from app.constants import (ACTIVE_STATUSES, COMPLETED, EXPIRED, CANCELLED, REPORT_OPEN, REPORT_IN_REVIEW, ROLE_DONOR, ROLES, VERIFICATION_PENDING, VERIFICATION_REJECTED,
                           VERIFICATION_VERIFIED)
from app.database.session import get_db
from app.errors import ConflictError, NotFoundError, UnprocessableError
from app.matching.engine import org_current_load, org_current_loads
from app.models import Donation, Organization, Report, User
from app.services import donation_service, impact_service
from app.services import organization_service as org_svc
from app.services.expiry import expire_overdue
from app.schemas.admin import DashboardOut
from app.schemas.auth import UserOut
from app.schemas.donation import DonationOut
from app.schemas.organization import OrganizationOut

router = APIRouter(prefix="/admin", tags=["Admin"], dependencies=[Depends(require_admin)])


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    expire_overdue(db)

    def count(model, *conds):
        return db.scalar(select(func.count()).select_from(model).where(*conds)) or 0

    impact = impact_service.platform_impact(db)
    recent = db.scalars(select(Donation).options(*donation_service._LOAD_OPTIONS)
                        .order_by(Donation.created_at.desc()).limit(6)).unique().all()
    return {
        "users_total": count(User),
        "donors_total": count(User, User.role == ROLE_DONOR),
        "organizations_total": count(Organization),
        "organizations_verified": count(Organization, Organization.verification_status == VERIFICATION_VERIFIED),
        "organizations_pending": count(Organization, Organization.verification_status == VERIFICATION_PENDING),
        "donations_total": count(Donation),
        "donations_active": count(Donation, Donation.status.in_(ACTIVE_STATUSES)),
        "donations_completed": count(Donation, Donation.status == COMPLETED),
        "donations_expired": count(Donation, Donation.status == EXPIRED),
        "donations_cancelled": count(Donation, Donation.status == CANCELLED),
        "meals_redistributed": impact["totals"]["meals_redistributed"],
        "open_reports": count(Report, Report.status.in_((REPORT_OPEN, REPORT_IN_REVIEW))),
        "recent_donations": [serialize_donation(d, admin) for d in recent],
    }


@router.get("/users", response_model=List[UserOut])
def list_users(role: Optional[str] = None, search: Optional[str] = None, db: Session = Depends(get_db)):
    stmt = select(User).options(selectinload(User.organization)).order_by(User.created_at.desc())
    if role:
        if role not in ROLES:
            raise UnprocessableError("Unknown role.")
        stmt = stmt.where(User.role == role)
    if search:
        term = search.strip().lower().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")  # literal match
        like = f"%{term}%"
        stmt = stmt.where(or_(func.lower(User.email).like(like, escape="\\"),
                              func.lower(User.full_name).like(like, escape="\\")))
    loads = org_current_loads(db)
    return [serialize_user(db, u, loads) for u in db.scalars(stmt).all()]


@router.post("/users/{user_id}/toggle-active", response_model=UserOut)
def toggle_active(user_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    user = db.get(User, user_id)
    if user is None:
        raise NotFoundError("User not found.")
    if user.id == admin.id:
        raise ConflictError("You cannot deactivate your own account.")
    user.is_active = not user.is_active
    db.commit()
    return serialize_user(db, user)


@router.get("/organizations", response_model=List[OrganizationOut])
def list_organizations(status: Optional[str] = None, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    return serialize_org_list(db, org_svc.list_organizations(db, admin, status))


@router.post("/organizations/{org_id}/verify", response_model=OrganizationOut)
def verify_organization(org_id: int, db: Session = Depends(get_db)):
    org = org_svc.set_verification(db, org_id, VERIFICATION_VERIFIED)
    return serialize_org_full(org, org_current_load(db, org.id))


@router.post("/organizations/{org_id}/reject", response_model=OrganizationOut)
def reject_organization(org_id: int, db: Session = Depends(get_db)):
    org = org_svc.set_verification(db, org_id, VERIFICATION_REJECTED)
    return serialize_org_full(org, org_current_load(db, org.id))


@router.get("/donations", response_model=List[DonationOut])
def list_donations(status: Optional[str] = None, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    return [serialize_donation(d, admin, extra) for d, extra in donation_service.list_donations(db, admin, None, status)]
