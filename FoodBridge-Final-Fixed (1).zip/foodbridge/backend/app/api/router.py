from fastapi import APIRouter

from app.api import admin, auth, donations, impact, organizations, reports

api_router = APIRouter(prefix="/api")
for module in (auth, donations, organizations, reports, admin, impact):
    api_router.include_router(module.router)
