from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.auth.security import create_access_token
from app.auth.throttle import login_throttle
from app.api.serializers import serialize_user
from app.database.session import get_db
from app.errors import AppError
from app.models import User
from app.schemas.auth import LoginRequest, ProfileUpdate, RegisterRequest, TokenResponse, UserOut
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _token_response(db: Session, user: User) -> dict:
    return {"access_token": create_access_token(user.id, user.role), "token_type": "bearer",
            "user": serialize_user(db, user)}


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    """Create a donor or organization account. Organizations start unverified."""
    return _token_response(db, auth_service.register_user(db, payload))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    ip = request.client.host if request.client else "unknown"
    login_throttle.check(ip, payload.email)                 # HTTP 429 after too many failures
    try:
        user = auth_service.authenticate(db, payload)
    except AppError as exc:
        if exc.code == "invalid_credentials":               # only wrong credentials count as a failure
            login_throttle.record_failure(ip, payload.email)
        raise
    login_throttle.reset(ip, payload.email)
    return _token_response(db, user)


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return serialize_user(db, user)


@router.patch("/me", response_model=UserOut)
def update_me(payload: ProfileUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return serialize_user(db, auth_service.update_profile(db, user, payload))
