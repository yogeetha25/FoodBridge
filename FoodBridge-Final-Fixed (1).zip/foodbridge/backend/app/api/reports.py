from typing import List, Optional

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_admin, require_roles
from app.api.serializers import serialize_report
from app.constants import ROLE_DONOR, ROLE_ORG
from app.database.session import get_db
from app.models import User
from app.schemas.report import ReportCreate, ReportOut, ReportUpdate
from app.services import report_service as svc

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.post("", response_model=ReportOut, status_code=201)
def create_report(payload: ReportCreate, user: User = Depends(require_roles(ROLE_DONOR, ROLE_ORG)),
                  db: Session = Depends(get_db)):
    """Report a problem with a donation you are involved in."""
    return serialize_report(svc.create_report(db, user, payload))


@router.get("", response_model=List[ReportOut])
def list_reports(status: Optional[str] = None, user: User = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    """Admins see every report; everyone else sees only the reports they filed."""
    return [serialize_report(r) for r in svc.list_reports(db, user, status)]


@router.patch("/{report_id}", response_model=ReportOut)
def update_report(report_id: int, payload: ReportUpdate, admin: User = Depends(require_admin),
                  db: Session = Depends(get_db)):
    return serialize_report(svc.update_report(db, admin, report_id, payload))
