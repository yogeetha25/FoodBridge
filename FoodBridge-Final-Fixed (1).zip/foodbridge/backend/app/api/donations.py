from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_donor, require_org
from app.api.serializers import serialize_donation, serialize_match
from app.database.session import get_db
from app.matching.config import DEFAULT_WEIGHTS
from app.models import User
from app.schemas.donation import (DonationCreate, DonationOut, DonationUpdate, MatchesResponse, NoteBody,
                                  PickupSchedule)
from app.services import donation_service as svc

router = APIRouter(prefix="/donations", tags=["Donations"])


@router.post("", response_model=DonationOut, status_code=201)
def create_donation(payload: DonationCreate, user: User = Depends(require_donor), db: Session = Depends(get_db)):
    """Create a donation. The server validates it, then runs the matching algorithm."""
    return serialize_donation(svc.create_donation(db, user, payload), user)


@router.get("", response_model=List[DonationOut])
def list_donations(
    view: Optional[str] = Query(default=None, description="Organizations only: available, recommended, accepted, pickups, completed"),
    status: Optional[str] = Query(default=None, description="Filter by status (donors and admins)"),
    user: User = Depends(get_current_user), db: Session = Depends(get_db),
):
    return [serialize_donation(d, user, extra) for d, extra in svc.list_donations(db, user, view, status)]


@router.get("/{donation_id}", response_model=DonationOut)
def get_donation(donation_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    donation, extra = svc.get_donation_for_viewer(db, user, donation_id)
    return serialize_donation(donation, user, extra)


@router.patch("/{donation_id}", response_model=DonationOut)
def update_donation(donation_id: int, payload: DonationUpdate, user: User = Depends(require_donor),
                    db: Session = Depends(get_db)):
    return serialize_donation(svc.update_donation(db, user, donation_id, payload), user)


@router.post("/{donation_id}/cancel", response_model=DonationOut)
def cancel_donation(donation_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return serialize_donation(svc.cancel_donation(db, user, donation_id), user)


@router.get("/{donation_id}/matches", response_model=MatchesResponse)
def get_matches(donation_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Ranked organizations with score breakdowns. Donation owner or admin only."""
    from app.constants import ROLE_ORG
    from app.errors import ForbiddenError
    if user.role == ROLE_ORG:
        raise ForbiddenError("Organizations see their own match on the donation page.")
    donation, matches, exclusions = svc.get_matches(db, user, donation_id)
    return {
        "donation_id": donation.id, "status": donation.status,
        "matches": [serialize_match(m) for m in matches],
        "excluded": [{"organization_id": e.organization_id, "organization_name": e.organization_name,
                      "code": e.code, "message": e.message} for e in exclusions],
        "weights": DEFAULT_WEIGHTS.as_dict(),
    }


@router.post("/{donation_id}/accept", response_model=DonationOut)
def accept_donation(donation_id: int, user: User = Depends(require_org), db: Session = Depends(get_db)):
    """Organization accepts a donation. First valid acceptance wins (HTTP 409 for the others)."""
    return serialize_donation(svc.accept_donation(db, user, donation_id), user)


@router.post("/{donation_id}/pickup", response_model=DonationOut)
def schedule_pickup(donation_id: int, payload: PickupSchedule, user: User = Depends(require_org),
                    db: Session = Depends(get_db)):
    return serialize_donation(svc.schedule_pickup(db, user, donation_id, payload), user)


@router.post("/{donation_id}/collect", response_model=DonationOut)
def collect(donation_id: int, payload: Optional[NoteBody] = None, user: User = Depends(require_org),
            db: Session = Depends(get_db)):
    return serialize_donation(svc.mark_collected(db, user, donation_id, payload), user)


@router.post("/{donation_id}/complete", response_model=DonationOut)
def complete(donation_id: int, payload: Optional[NoteBody] = None, user: User = Depends(require_org),
             db: Session = Depends(get_db)):
    return serialize_donation(svc.mark_completed(db, user, donation_id, payload), user)
