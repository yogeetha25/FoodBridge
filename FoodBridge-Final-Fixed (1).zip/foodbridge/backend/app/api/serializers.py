"""Turn ORM objects into plain dicts for the API. This is also where we decide WHAT each kind of
viewer may see (e.g. an organization cannot see a donor's contact info before accepting)."""
from typing import Dict, Optional

from sqlalchemy.orm import Session

from app.constants import ROLE_ADMIN, ROLE_DONOR, ROLE_ORG
from app.matching.engine import org_current_load, org_current_loads
from app.models import Donation, Match, Organization, Pickup, Report, User


def serialize_org_public(org: Organization) -> Dict:
    return {
        "id": org.id, "name": org.name, "organization_type": org.organization_type,
        "address": org.address, "latitude": org.latitude, "longitude": org.longitude,
        "service_radius_km": org.service_radius_km, "max_capacity_meals": org.max_capacity_meals,
        "preferred_categories": org.preferred_categories or [], "food_preferences": org.food_preferences,
        "operating_hours": org.operating_hours, "verification_status": org.verification_status,
    }


def serialize_org_full(org: Organization, load: int = 0) -> Dict:
    data = serialize_org_public(org)
    data.update({
        "user_id": org.user_id, "email": org.user.email if org.user else None,
        "contact_person": org.contact_person, "phone": org.phone,
        "current_load_meals": load, "created_at": org.created_at,
    })
    return data


def serialize_org_list(db: Session, orgs) -> list:
    loads = org_current_loads(db)
    return [serialize_org_full(o, loads.get(o.id, 0)) for o in orgs]


def serialize_user(db: Session, user: User, loads: Optional[Dict[int, int]] = None) -> Dict:
    """Pass `loads` (from org_current_loads) when serializing many users, so it is queried once."""
    org = None
    if user.organization is not None:
        load = loads.get(user.organization.id, 0) if loads is not None else org_current_load(db, user.organization.id)
        org = serialize_org_full(user.organization, load)
    return {
        "id": user.id, "email": user.email, "role": user.role, "full_name": user.full_name,
        "phone": user.phone, "donor_type": user.donor_type, "is_active": user.is_active,
        "created_at": user.created_at, "organization": org,
    }


def serialize_pickup(pickup: Optional[Pickup]) -> Optional[Dict]:
    if pickup is None:
        return None
    return {
        "id": pickup.id, "organization_id": pickup.organization_id,
        "organization_name": pickup.organization.name if pickup.organization else None,
        "scheduled_at": pickup.scheduled_at, "collected_at": pickup.collected_at,
        "completed_at": pickup.completed_at, "notes": pickup.notes,
    }


def serialize_donation(donation: Donation, viewer: User, extra: Optional[Dict] = None) -> Dict:
    pickup = donation.pickup
    accepting_org = pickup.organization if pickup else None

    # Privacy rule: donor contact details are shown to the donor, admins and the ACCEPTING organization only.
    viewer_is_accepting_org = bool(viewer.role == ROLE_ORG and viewer.organization and accepting_org
                                   and accepting_org.id == viewer.organization.id)
    can_see_contact = viewer.role == ROLE_ADMIN or donation.donor_id == viewer.id or viewer_is_accepting_org

    data = {
        "id": donation.id, "donor_id": donation.donor_id,
        "donor_name": donation.donor.full_name if donation.donor else None,
        "title": donation.title, "category": donation.category, "is_vegetarian": donation.is_vegetarian,
        "quantity": donation.quantity, "unit": donation.unit, "estimated_meals": donation.estimated_meals,
        "prepared_at": donation.prepared_at, "available_until": donation.available_until,
        "pickup_address": donation.pickup_address, "latitude": donation.latitude,
        "longitude": donation.longitude, "description": donation.description,
        "handling_notes": donation.handling_notes,
        "contact_info": donation.contact_info if can_see_contact else None,
        "status": donation.status, "created_at": donation.created_at,
        "accepted_by": {"id": accepting_org.id, "name": accepting_org.name} if accepting_org else None,
        "pickup": serialize_pickup(pickup),
        "impact": ({"meals_redistributed": donation.impact.meals_redistributed,
                    "quantity_kg_est": donation.impact.quantity_kg_est,
                    "people_served_est": donation.impact.people_served_est,
                    "created_at": donation.impact.created_at} if donation.impact else None),
    }
    if viewer.role in (ROLE_DONOR, ROLE_ADMIN):
        data["match_count"] = len(donation.matches)
        data["top_match_score"] = donation.matches[0].score if donation.matches else None
    if extra:
        data.update(extra)
    return data


def serialize_match(match: Match) -> Dict:
    return {
        "id": match.id, "donation_id": match.donation_id, "organization_id": match.organization_id,
        "organization": serialize_org_public(match.organization), "score": match.score,
        "rank": match.rank, "score_breakdown": match.score_breakdown, "created_at": match.created_at,
    }


def serialize_report(report: Report) -> Dict:
    return {
        "id": report.id, "donation_id": report.donation_id,
        "donation_title": report.donation.title if report.donation else None,
        "reporter_id": report.reporter_id,
        "reporter_name": report.reporter.full_name if report.reporter else None,
        "reason": report.reason, "details": report.details, "status": report.status,
        "resolved_by": report.resolved_by, "resolution_notes": report.resolution_notes,
        "created_at": report.created_at,
    }
