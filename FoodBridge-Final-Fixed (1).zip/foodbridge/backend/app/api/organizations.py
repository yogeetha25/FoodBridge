from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.api.serializers import serialize_org_full, serialize_org_public
from app.constants import ROLE_ADMIN, ROLE_ORG, VERIFICATION_VERIFIED
from app.database.session import get_db
from app.errors import ForbiddenError, NotFoundError
from app.matching.engine import org_current_load
from app.models import User
from app.schemas.organization import OrganizationOut, OrganizationPublic, OrganizationUpdate
from app.services import organization_service as svc

router = APIRouter(prefix="/organizations", tags=["Organizations"])


@router.get("", response_model=List[OrganizationPublic])
def list_organizations(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Verified organizations (public details only). Admins use /api/admin/organizations for full data."""
    return [serialize_org_public(o) for o in svc.list_organizations(db, user)]


@router.get("/me", response_model=OrganizationOut)
def my_organization(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != ROLE_ORG or user.organization is None:
        raise NotFoundError("You do not have an organization profile.")
    return serialize_org_full(user.organization, org_current_load(db, user.organization.id))


@router.get("/{org_id}")
def get_organization(org_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = svc.get_organization_or_404(db, org_id)
    is_owner = org.user_id == user.id
    if user.role == ROLE_ADMIN or is_owner:
        return OrganizationOut(**serialize_org_full(org, org_current_load(db, org.id)))
    if org.verification_status != VERIFICATION_VERIFIED:
        raise NotFoundError("Organization not found.")
    return OrganizationPublic(**serialize_org_public(org))


@router.patch("/{org_id}", response_model=OrganizationOut)
def update_organization(org_id: int, payload: OrganizationUpdate, user: User = Depends(get_current_user),
                        db: Session = Depends(get_db)):
    if user.role not in (ROLE_ORG, ROLE_ADMIN):
        raise ForbiddenError("You do not have permission to do that.", code="wrong_role")
    org = svc.update_organization(db, org_id, user, payload)
    return serialize_org_full(org, org_current_load(db, org.id))
