from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import require_donor, require_org
from app.database.session import get_db
from app.models import User
from app.services import impact_service

router = APIRouter(prefix="/impact", tags=["Impact"])


@router.get("")
def platform_impact(db: Session = Depends(get_db)):
    """Platform-wide totals and trends. Aggregates only (no personal data), so it is public:
    the landing page shows it. Every figure is an ESTIMATE; see the 'assumptions' list."""
    return impact_service.platform_impact(db)


@router.get("/donor")
def donor_impact(user: User = Depends(require_donor), db: Session = Depends(get_db)):
    return impact_service.donor_impact(db, user.id)


@router.get("/organization")
def organization_impact(user: User = Depends(require_org), db: Session = Depends(get_db)):
    return impact_service.organization_impact(db, user.organization.id)
