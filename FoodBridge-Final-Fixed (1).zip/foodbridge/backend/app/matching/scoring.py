"""Rule-based matching engine: pure functions, NO database, NO web framework.

Step 1 - hard eligibility filters  -> organization is excluded with a reason
Step 2 - weighted score (0-100)    -> eligible organizations get a score
Step 3 - explanation               -> every factor returns a number AND a sentence

Because this module is pure, it can be unit-tested and explained on its own.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, List, Optional, Tuple, Union

from app.constants import FOOD_CATEGORY_LABELS
from app.matching.config import (AVERAGE_SPEED_KMH, DEFAULT_WEIGHTS, LOCAL_UTC_OFFSET_MINUTES,
                                 PICKUP_PREP_BUFFER_MIN, ROAD_DETOUR_FACTOR, MatchWeights)
from app.utils.geo import haversine_km
from app.utils.hours import is_open_at

# Exclusion codes (hard filters)
NOT_VERIFIED = "NOT_VERIFIED"
INACTIVE = "INACTIVE"
EXPIRED = "EXPIRED"
DIET_MISMATCH = "DIET_MISMATCH"
CATEGORY_UNSUPPORTED = "CATEGORY_UNSUPPORTED"
INSUFFICIENT_CAPACITY = "INSUFFICIENT_CAPACITY"
OUT_OF_RANGE = "OUT_OF_RANGE"
CANNOT_ARRIVE_IN_TIME = "CANNOT_ARRIVE_IN_TIME"

# A "travel estimator" returns (distance_km, driving_minutes, source_label)
TravelEstimate = Tuple[float, float, str]
TravelEstimator = Callable[["DonationInfo", "OrganizationInfo"], TravelEstimate]


@dataclass(frozen=True)
class DonationInfo:
    id: int
    category: str
    is_vegetarian: bool
    estimated_meals: int
    latitude: float
    longitude: float
    available_until: datetime  # naive UTC


@dataclass(frozen=True)
class OrganizationInfo:
    id: int
    name: str
    is_verified: bool
    is_active: bool
    latitude: float
    longitude: float
    service_radius_km: float
    max_capacity_meals: int
    current_load_meals: int            # meals already committed (accepted / pickup / collected)
    preferred_categories: Tuple[str, ...]  # empty tuple = accepts every category
    food_preferences: str              # BOTH | VEG_ONLY | NON_VEG_ONLY
    operating_hours: str               # "09:00-18:00" or "24/7" (local time)


@dataclass
class Exclusion:
    organization_id: int
    organization_name: str
    code: str
    message: str


@dataclass
class MatchResult:
    organization_id: int
    organization_name: str
    score: float                       # 0-100
    distance_km: float
    eta_minutes: float
    time_left_minutes: float
    routing: str
    factors: dict = field(default_factory=dict)
    reasons: List[dict] = field(default_factory=list)
    weights: dict = field(default_factory=dict)

    def breakdown(self) -> dict:
        """JSON-serialisable explanation stored in matches.score_breakdown."""
        return {
            "total": self.score,
            "distance_km": round(self.distance_km, 2),
            "eta_minutes": round(self.eta_minutes),
            "time_left_minutes": round(self.time_left_minutes),
            "routing": self.routing,
            "weights": self.weights,
            "factors": self.factors,
            "reasons": self.reasons,
        }


# ---------------------------------------------------------------- helpers

def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def fmt_minutes(minutes: float) -> str:
    minutes = max(0, int(round(minutes)))
    if minutes < 60:
        return f"{minutes} min"
    hours, rest = divmod(minutes, 60)
    return f"{hours} h {rest} min" if rest else f"{hours} h"


def default_travel_estimate(donation: DonationInfo, org: OrganizationInfo) -> TravelEstimate:
    """Straight-line (Haversine) distance; driving time uses a detour factor and average speed."""
    km = haversine_km(donation.latitude, donation.longitude, org.latitude, org.longitude)
    minutes = (km * ROAD_DETOUR_FACTOR) / AVERAGE_SPEED_KMH * 60
    return km, minutes, "haversine"


# ---------------------------------------------------------------- sub-scores (each returns 0..1)

def distance_score(distance_km: float, service_radius_km: float) -> float:
    """1 when the donor is next door, 0 at the edge of the service radius."""
    if service_radius_km <= 0:
        return 0.0
    return clamp(1 - distance_km / service_radius_km)


def capacity_score(estimated_meals: int, remaining_capacity: int) -> float:
    """Reward organizations that can take the food comfortably, without favouring huge ones.
    fill = meals / free capacity.
      fill <= 0.5      -> 0.4 + 1.2*fill  (a tiny donation for a huge NGO is a poor fit: 0.4..1.0)
      0.5 < fill <= .95 -> 1.0             (good fit)
      fill > 0.95      -> 0.9              (fits, but leaves no spare room)"""
    if remaining_capacity <= 0:
        return 0.0
    fill = estimated_meals / remaining_capacity
    if fill <= 0.5:
        return clamp(0.4 + 1.2 * fill)
    if fill <= 0.95:
        return 1.0
    return 0.9


def urgency_score(time_left_min: float, eta_min: float) -> float:
    """Share of the remaining time window that is still unused after the organization arrives.
    Close organizations leave a big margin (-> high), far ones barely arrive in time (-> low)."""
    if time_left_min <= 0 or eta_min >= time_left_min:
        return 0.0
    return clamp((time_left_min - eta_min) / time_left_min)


def food_score(donation: DonationInfo, org: OrganizationInfo) -> Tuple[float, str]:
    """60% category fit + 40% diet fit. Returns (score, explanation)."""
    label = FOOD_CATEGORY_LABELS.get(donation.category, donation.category.title())
    if org.preferred_categories:
        category_part, cat_text = 1.0, f"{label} is one of its accepted categories"
    else:
        category_part, cat_text = 0.7, "No category restrictions"
    diet_word = "vegetarian" if donation.is_vegetarian else "non-vegetarian"
    if org.food_preferences == "BOTH":
        diet_part, diet_text = 0.8, f"accepts {diet_word} food"
    else:
        diet_part, diet_text = 1.0, f"specialises in {diet_word} food"
    return 0.6 * category_part + 0.4 * diet_part, f"{cat_text}; {diet_text}"


def availability_score(org: OrganizationInfo, now: datetime, eta_min: float,
                       time_left_min: float) -> Tuple[float, str]:
    """Is the organization open now, and open when it would actually arrive?"""
    offset = LOCAL_UTC_OFFSET_MINUTES
    open_now = is_open_at(org.operating_hours, now, offset)
    arrival = now + timedelta(minutes=eta_min)
    open_at_arrival = is_open_at(org.operating_hours, arrival, offset)
    if open_now and open_at_arrival:
        return 1.0, "Open now and still open on arrival"
    if open_at_arrival:
        return 0.8, "Closed right now, but open by the time it could arrive"
    # Does it open at some point before the donation expires?
    t = eta_min
    while t <= time_left_min:
        if is_open_at(org.operating_hours, now + timedelta(minutes=t), offset):
            return 0.4, "Opens later within the pickup window"
        t += 15
    return 0.1, "Closed for the whole pickup window; call to confirm"


# ---------------------------------------------------------------- main evaluation

def evaluate_organization(donation: DonationInfo, org: OrganizationInfo, now: datetime,
                          weights: MatchWeights = DEFAULT_WEIGHTS,
                          travel: Optional[TravelEstimator] = None) -> Union[MatchResult, Exclusion]:
    """Apply the hard filters, then score. Returns a MatchResult or an Exclusion (with reason)."""
    def excluded(code: str, message: str) -> Exclusion:
        return Exclusion(org.id, org.name, code, message)

    # ---- Step 1: hard eligibility filters -------------------------------------------
    if not org.is_verified:
        return excluded(NOT_VERIFIED, "Organization is not verified by an administrator.")
    if not org.is_active:
        return excluded(INACTIVE, "Organization account is inactive.")
    if donation.available_until <= now:
        return excluded(EXPIRED, "This donation has expired.")
    if org.food_preferences == "VEG_ONLY" and not donation.is_vegetarian:
        return excluded(DIET_MISMATCH, f"{org.name} accepts vegetarian food only.")
    if org.food_preferences == "NON_VEG_ONLY" and donation.is_vegetarian:
        return excluded(DIET_MISMATCH, f"{org.name} accepts non-vegetarian food only.")
    if org.preferred_categories and donation.category not in org.preferred_categories:
        label = FOOD_CATEGORY_LABELS.get(donation.category, donation.category)
        return excluded(CATEGORY_UNSUPPORTED, f"{org.name} does not accept this food category ({label}).")
    remaining = max(0, org.max_capacity_meals - org.current_load_meals)
    if donation.estimated_meals > remaining:
        return excluded(INSUFFICIENT_CAPACITY,
                        f"Not enough free capacity: {remaining} meals free, {donation.estimated_meals} needed.")

    distance_km, drive_min, source = (travel or default_travel_estimate)(donation, org)
    if distance_km > org.service_radius_km:
        return excluded(OUT_OF_RANGE,
                        f"{distance_km:.1f} km away, outside the {org.service_radius_km:g} km service area.")
    time_left = (donation.available_until - now).total_seconds() / 60
    eta = drive_min + PICKUP_PREP_BUFFER_MIN
    if eta >= time_left:
        return excluded(CANNOT_ARRIVE_IN_TIME,
                        f"Needs about {fmt_minutes(eta)} to arrive, but only {fmt_minutes(time_left)} remain.")

    # ---- Step 2: weighted score ----------------------------------------------------
    s_dist = distance_score(distance_km, org.service_radius_km)
    s_cap = capacity_score(donation.estimated_meals, remaining)
    s_urg = urgency_score(time_left, eta)
    s_food, food_text = food_score(donation, org)
    s_avail, avail_text = availability_score(org, now, eta, time_left)

    w = weights
    total = (s_dist * w.distance + s_cap * w.capacity + s_urg * w.urgency
             + s_food * w.food + s_avail * w.availability)
    score = round(clamp(total) * 100, 1)

    # ---- Step 3: explanation ---------------------------------------------------------
    spare = time_left - eta
    dist_text = (f"Only {distance_km:.1f} km away" if s_dist >= 0.7 else f"{distance_km:.1f} km away")
    cap_text = (f"Capacity is sufficient ({donation.estimated_meals} meals needed, {remaining} free)"
                if s_cap >= 0.6 else
                f"Capacity fits, but this is a small share of its {remaining} free meals")
    urg_text = (f"Can arrive in about {fmt_minutes(eta)}, with {fmt_minutes(spare)} to spare"
                if s_urg >= 0.5 else
                f"Tight timing: about {fmt_minutes(eta)} to arrive, only {fmt_minutes(spare)} to spare")

    def factor(label, sub, weight, detail):
        return {"label": label, "score": round(sub, 3), "weight": weight,
                "points": round(sub * weight * 100, 1), "detail": detail}

    factors = {
        "distance": factor("Distance", s_dist, w.distance, dist_text),
        "capacity": factor("Capacity fit", s_cap, w.capacity, cap_text),
        "urgency": factor("Time feasibility", s_urg, w.urgency, urg_text),
        "food": factor("Food compatibility", s_food, w.food, food_text),
        "availability": factor("Availability", s_avail, w.availability, avail_text),
    }
    reasons = [{"text": f["detail"], "positive": f["score"] >= 0.6} for f in factors.values()]
    return MatchResult(org.id, org.name, score, distance_km, eta, time_left, source,
                       factors, reasons, w.as_dict())


def rank_organizations(donation: DonationInfo, organizations: List[OrganizationInfo], now: datetime,
                       weights: MatchWeights = DEFAULT_WEIGHTS,
                       travel: Optional[TravelEstimator] = None
                       ) -> Tuple[List[MatchResult], List[Exclusion]]:
    """Evaluate every organization. Returns (ranked matches best-first, exclusions)."""
    matches: List[MatchResult] = []
    exclusions: List[Exclusion] = []
    for org in organizations:
        result = evaluate_organization(donation, org, now, weights, travel)
        (matches if isinstance(result, MatchResult) else exclusions).append(result)
    # Highest score first; ties broken by shorter distance, then id (stable & deterministic)
    matches.sort(key=lambda m: (-m.score, m.distance_km, m.organization_id))
    return matches, exclusions
