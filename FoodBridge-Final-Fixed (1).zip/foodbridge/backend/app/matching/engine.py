"""Glue between the database and the pure scoring functions in scoring.py.
Loads organizations, computes their current load, runs the scoring, saves Match rows."""
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Union

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session, joinedload

from app.config import settings
from app.constants import AVAILABLE, LOAD_STATUSES, MATCHED, VERIFICATION_VERIFIED
from app.matching.config import DEFAULT_WEIGHTS
from app.matching.scoring import (DonationInfo, Exclusion, MatchResult, OrganizationInfo,
                                  default_travel_estimate, evaluate_organization, rank_organizations)
from app.models import Donation, Match, Organization, Pickup
from app.services.status_machine import assert_transition
from app.services.transitions import claim_status
from app.utils.routing import osrm_route
from app.utils.time import utcnow


def org_current_loads(db: Session) -> Dict[int, int]:
    """Meals each organization has already committed to (ACCEPTED / PICKUP_PENDING / COLLECTED)."""
    stmt = (select(Pickup.organization_id, func.coalesce(func.sum(Donation.estimated_meals), 0))
            .join(Donation, Donation.id == Pickup.donation_id)
            .where(Donation.status.in_(LOAD_STATUSES))
            .group_by(Pickup.organization_id))
    return {org_id: int(total) for org_id, total in db.execute(stmt).all()}


def org_current_load(db: Session, org_id: int) -> int:
    """Meals ONE organization has committed to. Cheaper than org_current_loads() when only one is needed."""
    stmt = (select(func.coalesce(func.sum(Donation.estimated_meals), 0))
            .select_from(Pickup).join(Donation, Donation.id == Pickup.donation_id)
            .where(Pickup.organization_id == org_id, Donation.status.in_(LOAD_STATUSES)))
    return int(db.scalar(stmt) or 0)


def to_donation_info(d: Donation) -> DonationInfo:
    return DonationInfo(id=d.id, category=d.category, is_vegetarian=d.is_vegetarian,
                        estimated_meals=d.estimated_meals, latitude=d.latitude,
                        longitude=d.longitude, available_until=d.available_until)


def to_org_info(o: Organization, load: int) -> OrganizationInfo:
    return OrganizationInfo(
        id=o.id, name=o.name,
        is_verified=o.verification_status == VERIFICATION_VERIFIED,
        is_active=bool(o.user.is_active) if o.user else True,
        latitude=o.latitude, longitude=o.longitude, service_radius_km=o.service_radius_km,
        max_capacity_meals=o.max_capacity_meals, current_load_meals=load,
        preferred_categories=tuple(o.preferred_categories or ()),
        food_preferences=o.food_preferences, operating_hours=o.operating_hours)


def get_travel_estimator():
    """None => pure Haversine. With USE_OSRM=true we try road routing and fall back per-pair."""
    if not settings.USE_OSRM:
        return None

    def estimate(donation: DonationInfo, org: OrganizationInfo):
        route = osrm_route(donation.latitude, donation.longitude, org.latitude, org.longitude)
        if route:
            return route[0], route[1], "osrm"
        return default_travel_estimate(donation, org)
    return estimate


def evaluate_all(db: Session, donation: Donation, now: Optional[datetime] = None
                 ) -> Tuple[List[MatchResult], List[Exclusion]]:
    """Run the full matching algorithm for one donation against every organization."""
    now = now or utcnow()
    orgs = db.scalars(select(Organization).options(joinedload(Organization.user))).unique().all()
    loads = org_current_loads(db)
    infos = [to_org_info(o, loads.get(o.id, 0)) for o in orgs]
    return rank_organizations(to_donation_info(donation), infos, now, DEFAULT_WEIGHTS, get_travel_estimator())


def evaluate_for_org(db: Session, donation: Donation, org: Organization,
                     now: Optional[datetime] = None, load: Optional[int] = None) -> Union[MatchResult, Exclusion]:
    """Live evaluation of ONE organization (used for 'recommended' lists and for accepting).
    Pass `load` (meals already committed) when evaluating many donations for the same organization,
    so it is queried once instead of once per donation."""
    if load is None:
        load = org_current_load(db, org.id)
    return evaluate_organization(to_donation_info(donation), to_org_info(org, load),
                                 now or utcnow(), DEFAULT_WEIGHTS, get_travel_estimator())


def compute_matches(db: Session, donation: Donation, now: Optional[datetime] = None
                    ) -> Tuple[List[Match], List[Exclusion]]:
    """Score all organizations, replace the stored matches, and keep the status honest:
    AVAILABLE -> MATCHED when at least one organization is eligible, and MATCHED -> AVAILABLE when none
    is any more (e.g. after an edit, or when capacity was used up). Each flip is a compare-and-set, so it
    can never overwrite an acceptance that happened a moment earlier. The caller commits."""
    results, exclusions = evaluate_all(db, donation, now)
    db.execute(delete(Match).where(Match.donation_id == donation.id))
    db.expire(donation, ["matches"])
    rows = [Match(donation_id=donation.id, organization_id=r.organization_id, score=r.score,
                  score_breakdown=r.breakdown(), rank=i + 1) for i, r in enumerate(results)]
    db.add_all(rows)
    db.flush()
    if rows and donation.status == AVAILABLE:
        assert_transition(AVAILABLE, MATCHED)
        claim_status(db, donation.id, (AVAILABLE,), MATCHED)
    elif not rows and donation.status == MATCHED:
        assert_transition(MATCHED, AVAILABLE)
        claim_status(db, donation.id, (MATCHED,), AVAILABLE)
    return rows, exclusions
