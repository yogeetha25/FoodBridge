"""Matching configuration: weights and assumptions in ONE place.

Final score = 100 * (w_distance*distance + w_capacity*capacity + w_urgency*urgency
                     + w_food*food + w_availability*availability)
where every sub-score is between 0 and 1. The weights must add up to 1.
They can be overridden with environment variables (see .env.example)."""
import os
from dataclasses import dataclass, asdict

import app.config  # noqa: F401  (makes sure backend/.env has been loaded)


@dataclass(frozen=True)
class MatchWeights:
    distance: float = 0.30
    capacity: float = 0.20
    urgency: float = 0.25
    food: float = 0.15
    availability: float = 0.10

    def __post_init__(self):
        total = self.distance + self.capacity + self.urgency + self.food + self.availability
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Matching weights must add up to 1.0 (got {total:.3f})")

    def as_dict(self) -> dict:
        return asdict(self)


def load_weights_from_env() -> MatchWeights:
    def get(name, default):
        return float(os.environ.get(f"MATCH_WEIGHT_{name.upper()}", default))
    return MatchWeights(distance=get("distance", 0.30), capacity=get("capacity", 0.20),
                        urgency=get("urgency", 0.25), food=get("food", 0.15),
                        availability=get("availability", 0.10))


DEFAULT_WEIGHTS = load_weights_from_env()

# Assumptions used for travel-time estimates (documented in docs/matching-algorithm.md)
AVERAGE_SPEED_KMH = 25.0          # typical city driving speed
ROAD_DETOUR_FACTOR = 1.3          # roads are longer than straight lines
PICKUP_PREP_BUFFER_MIN = 15       # time to get a vehicle/volunteers ready and load the food
LOCAL_UTC_OFFSET_MINUTES = int(os.environ.get("LOCAL_UTC_OFFSET_MINUTES", "330"))  # IST = UTC+5:30
