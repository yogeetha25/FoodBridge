from typing import List

from pydantic import BaseModel

from app.schemas.donation import DonationOut


class DashboardOut(BaseModel):
    users_total: int
    donors_total: int
    organizations_total: int
    organizations_verified: int
    organizations_pending: int
    donations_total: int
    donations_active: int
    donations_completed: int
    donations_expired: int
    donations_cancelled: int
    meals_redistributed: int
    open_reports: int
    recent_donations: List[DonationOut]
