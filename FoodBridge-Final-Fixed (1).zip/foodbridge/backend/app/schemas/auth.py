import re
from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from app.constants import DONOR_TYPES, ROLE_DONOR, ROLE_ORG, SELF_REGISTER_ROLES
from app.schemas.common import UTCDateTime, clean_text, strip_min
from app.schemas.organization import OrganizationInput, OrganizationOut

_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _normalise_email(v: str) -> str:
    v = v.strip().lower()
    if not _EMAIL.match(v) or len(v) > 255:
        raise ValueError("Enter a valid email address")
    return v


class RegisterRequest(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=72)
    full_name: str = Field(min_length=2, max_length=120)
    phone: Optional[str] = Field(default=None, max_length=30)
    role: str
    donor_type: Optional[str] = None
    organization: Optional[OrganizationInput] = None

    @field_validator("email")
    @classmethod
    def _check_email(cls, v):
        return _normalise_email(v)

    @field_validator("full_name")
    @classmethod
    def _name(cls, v):
        return strip_min(v, 2)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v):
        return clean_text(v)

    @field_validator("password")
    @classmethod
    def _password_strength(cls, v):
        if not re.search(r"[A-Za-z]", v) or not re.search(r"\d", v):
            raise ValueError("Password must contain at least one letter and one number")
        if len(v.encode("utf-8")) > 72:
            raise ValueError("Password is too long (bcrypt limit is 72 bytes)")
        return v

    @field_validator("role")
    @classmethod
    def _role(cls, v):
        if v not in SELF_REGISTER_ROLES:
            raise ValueError("Role must be DONOR or ORGANIZATION")
        return v

    @model_validator(mode="after")
    def _role_specific(self):
        if self.role == ROLE_ORG and self.organization is None:
            raise ValueError("Organization details are required when registering as an organization")
        if self.role == ROLE_DONOR:
            self.donor_type = self.donor_type or "OTHER"
            if self.donor_type not in DONOR_TYPES:
                raise ValueError(f"Donor type must be one of: {', '.join(DONOR_TYPES)}")
            self.organization = None
        else:
            self.donor_type = None
        return self


class LoginRequest(BaseModel):
    email: str
    password: str = Field(min_length=1, max_length=200)

    @field_validator("email")
    @classmethod
    def _lower_email(cls, v):
        return v.strip().lower()


class ProfileUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    phone: Optional[str] = Field(default=None, max_length=30)
    donor_type: Optional[str] = None

    @field_validator("full_name")
    @classmethod
    def _name(cls, v):
        return strip_min(v, 2)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v):
        return clean_text(v)

    @field_validator("donor_type")
    @classmethod
    def _dt(cls, v):
        if v is not None and v not in DONOR_TYPES:
            raise ValueError(f"Donor type must be one of: {', '.join(DONOR_TYPES)}")
        return v


class UserOut(BaseModel):
    id: int
    email: str
    role: str
    full_name: str
    phone: Optional[str] = None
    donor_type: Optional[str] = None
    is_active: bool
    created_at: UTCDateTime
    organization: Optional[OrganizationOut] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut
