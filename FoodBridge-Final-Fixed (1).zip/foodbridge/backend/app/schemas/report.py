from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from app.constants import REPORT_REASONS, REPORT_STATUSES
from app.schemas.common import UTCDateTime, clean_text


class ReportCreate(BaseModel):
    donation_id: int
    reason: str
    details: Optional[str] = Field(default=None, max_length=2000)

    @field_validator("reason")
    @classmethod
    def _reason(cls, v):
        if v not in REPORT_REASONS:
            raise ValueError(f"Reason must be one of: {', '.join(REPORT_REASONS)}")
        return v

    @field_validator("details")
    @classmethod
    def _details(cls, v):
        return clean_text(v)

    @model_validator(mode="after")
    def _other_needs_details(self):
        if self.reason == "OTHER" and not self.details:
            raise ValueError("Please describe the problem when the reason is 'Other'")
        return self


class ReportUpdate(BaseModel):
    status: Optional[str] = None
    resolution_notes: Optional[str] = Field(default=None, max_length=2000)

    @field_validator("status")
    @classmethod
    def _status(cls, v):
        if v is not None and v not in REPORT_STATUSES:
            raise ValueError(f"Status must be one of: {', '.join(REPORT_STATUSES)}")
        return v

    @field_validator("resolution_notes")
    @classmethod
    def _notes(cls, v):
        return clean_text(v)


class ReportOut(BaseModel):
    id: int
    donation_id: int
    donation_title: Optional[str] = None
    reporter_id: int
    reporter_name: Optional[str] = None
    reason: str
    details: Optional[str] = None
    status: str
    resolved_by: Optional[int] = None
    resolution_notes: Optional[str] = None
    created_at: UTCDateTime
