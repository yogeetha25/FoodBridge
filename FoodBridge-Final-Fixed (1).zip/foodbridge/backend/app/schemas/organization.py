from typing import List, Optional

from pydantic import BaseModel, Field, field_validator

from app.constants import FOOD_CATEGORIES, FOOD_PREFERENCES, ORG_TYPES
from app.schemas.common import UTCDateTime, strip_min
from app.utils.hours import parse_hours


def _check_categories(values: List[str]) -> List[str]:
    bad = [v for v in values if v not in FOOD_CATEGORIES]
    if bad:
        raise ValueError(f"Unknown food categories: {', '.join(bad)}")
    return list(dict.fromkeys(values))  # remove duplicates, keep order


class OrganizationInput(BaseModel):
    """Organization details supplied at registration."""
    name: str = Field(min_length=2, max_length=160)
    organization_type: str
    contact_person: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=5, max_length=30)
    address: str = Field(min_length=5, max_length=300)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    service_radius_km: float = Field(gt=0, le=200)
    max_capacity_meals: int = Field(gt=0, le=1_000_000)
    preferred_categories: List[str] = []
    food_preferences: str = "BOTH"
    operating_hours: str = "09:00-18:00"

    @field_validator("name", "contact_person")
    @classmethod
    def _strip_short(cls, v):
        return strip_min(v, 2)

    @field_validator("phone", "address")
    @classmethod
    def _strip_long(cls, v):
        return strip_min(v, 5)

    @field_validator("organization_type")
    @classmethod
    def _type(cls, v):
        if v not in ORG_TYPES:
            raise ValueError(f"Organization type must be one of: {', '.join(ORG_TYPES)}")
        return v

    @field_validator("food_preferences")
    @classmethod
    def _prefs(cls, v):
        if v not in FOOD_PREFERENCES:
            raise ValueError(f"Food preference must be one of: {', '.join(FOOD_PREFERENCES)}")
        return v

    @field_validator("preferred_categories")
    @classmethod
    def _cats(cls, v):
        return _check_categories(v)

    @field_validator("operating_hours")
    @classmethod
    def _hours(cls, v):
        parse_hours(v)  # raises ValueError with a friendly message
        return v.strip()


class OrganizationUpdate(BaseModel):
    """Every field optional: only the fields sent are changed."""
    name: Optional[str] = Field(default=None, min_length=2, max_length=160)
    organization_type: Optional[str] = None
    contact_person: Optional[str] = Field(default=None, min_length=2, max_length=120)
    phone: Optional[str] = Field(default=None, min_length=5, max_length=30)
    address: Optional[str] = Field(default=None, min_length=5, max_length=300)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    service_radius_km: Optional[float] = Field(default=None, gt=0, le=200)
    max_capacity_meals: Optional[int] = Field(default=None, gt=0, le=1_000_000)
    preferred_categories: Optional[List[str]] = None
    food_preferences: Optional[str] = None
    operating_hours: Optional[str] = None

    @field_validator("name", "contact_person")
    @classmethod
    def _strip_short(cls, v):
        return strip_min(v, 2)

    @field_validator("phone", "address")
    @classmethod
    def _strip_long(cls, v):
        return strip_min(v, 5)

    @field_validator("organization_type")
    @classmethod
    def _type(cls, v):
        if v is not None and v not in ORG_TYPES:
            raise ValueError(f"Organization type must be one of: {', '.join(ORG_TYPES)}")
        return v

    @field_validator("food_preferences")
    @classmethod
    def _prefs(cls, v):
        if v is not None and v not in FOOD_PREFERENCES:
            raise ValueError(f"Food preference must be one of: {', '.join(FOOD_PREFERENCES)}")
        return v

    @field_validator("preferred_categories")
    @classmethod
    def _cats(cls, v):
        return None if v is None else _check_categories(v)

    @field_validator("operating_hours")
    @classmethod
    def _hours(cls, v):
        if v is not None:
            parse_hours(v)
            return v.strip()
        return v


class OrganizationOut(BaseModel):
    """Full organization record (owner and admin only)."""
    id: int
    user_id: int
    email: Optional[str] = None
    name: str
    organization_type: str
    contact_person: str
    phone: str
    address: str
    latitude: float
    longitude: float
    service_radius_km: float
    max_capacity_meals: int
    current_load_meals: int = 0
    preferred_categories: List[str] = []
    food_preferences: str
    operating_hours: str
    verification_status: str
    created_at: UTCDateTime


class OrganizationPublic(BaseModel):
    """What other signed-in users may see: no phone, email or contact person."""
    id: int
    name: str
    organization_type: str
    address: str
    latitude: float
    longitude: float
    service_radius_km: float
    max_capacity_meals: int
    preferred_categories: List[str] = []
    food_preferences: str
    operating_hours: str
    verification_status: str
