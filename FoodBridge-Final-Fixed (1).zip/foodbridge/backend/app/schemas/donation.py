from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from app.constants import FOOD_CATEGORIES, UNITS
from app.schemas.common import UTCDateTime, clean_text, strip_min
from app.schemas.organization import OrganizationPublic
from app.utils.time import to_naive_utc, utcnow

MAX_WINDOW = timedelta(hours=72)  # sanity limit: surplus food is perishable


def _check_times(prepared_at: datetime, available_until: datetime) -> None:
    """Server-side time rules shared by create and update."""
    if available_until <= utcnow():
        raise ValueError("Available-until time must be in the future")
    if prepared_at >= available_until:
        raise ValueError("Prepared time must be before the available-until time")
    if available_until - utcnow() > MAX_WINDOW:
        raise ValueError("Available-until time must be within the next 72 hours")


class DonationCreate(BaseModel):
    title: str = Field(min_length=3, max_length=160)
    category: str
    is_vegetarian: bool
    quantity: float = Field(gt=0, le=1_000_000)
    unit: str
    estimated_meals: int = Field(gt=0, le=1_000_000)
    prepared_at: datetime
    available_until: datetime
    pickup_address: str = Field(min_length=5, max_length=300)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    description: Optional[str] = Field(default=None, max_length=1000)
    handling_notes: Optional[str] = Field(default=None, max_length=1000)
    contact_info: str = Field(min_length=5, max_length=200)

    @field_validator("title")
    @classmethod
    def _title(cls, v):
        return strip_min(v, 3)

    @field_validator("pickup_address", "contact_info")
    @classmethod
    def _strip_required(cls, v):
        return strip_min(v, 5)

    @field_validator("description", "handling_notes")
    @classmethod
    def _strip_optional(cls, v):
        return clean_text(v)

    @field_validator("category")
    @classmethod
    def _category(cls, v):
        if v not in FOOD_CATEGORIES:
            raise ValueError(f"Category must be one of: {', '.join(FOOD_CATEGORIES)}")
        return v

    @field_validator("unit")
    @classmethod
    def _unit(cls, v):
        if v not in UNITS:
            raise ValueError(f"Unit must be one of: {', '.join(UNITS)}")
        return v

    @field_validator("prepared_at", "available_until")
    @classmethod
    def _to_utc(cls, v):
        return to_naive_utc(v)

    @model_validator(mode="after")
    def _time_rules(self):
        _check_times(self.prepared_at, self.available_until)
        return self


class DonationUpdate(BaseModel):
    """Partial update. Only AVAILABLE / MATCHED donations can be edited (checked in the service)."""
    title: Optional[str] = Field(default=None, min_length=3, max_length=160)
    category: Optional[str] = None
    is_vegetarian: Optional[bool] = None
    quantity: Optional[float] = Field(default=None, gt=0, le=1_000_000)
    unit: Optional[str] = None
    estimated_meals: Optional[int] = Field(default=None, gt=0, le=1_000_000)
    prepared_at: Optional[datetime] = None
    available_until: Optional[datetime] = None
    pickup_address: Optional[str] = Field(default=None, min_length=5, max_length=300)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    description: Optional[str] = Field(default=None, max_length=1000)
    handling_notes: Optional[str] = Field(default=None, max_length=1000)
    contact_info: Optional[str] = Field(default=None, min_length=5, max_length=200)

    @field_validator("title")
    @classmethod
    def _title(cls, v):
        return strip_min(v, 3)

    @field_validator("pickup_address", "contact_info")
    @classmethod
    def _strip_required(cls, v):
        return strip_min(v, 5)

    @field_validator("description", "handling_notes")
    @classmethod
    def _strip_optional(cls, v):
        return clean_text(v)

    @field_validator("category")
    @classmethod
    def _category(cls, v):
        if v is not None and v not in FOOD_CATEGORIES:
            raise ValueError(f"Category must be one of: {', '.join(FOOD_CATEGORIES)}")
        return v

    @field_validator("unit")
    @classmethod
    def _unit(cls, v):
        if v is not None and v not in UNITS:
            raise ValueError(f"Unit must be one of: {', '.join(UNITS)}")
        return v

    @field_validator("prepared_at", "available_until")
    @classmethod
    def _to_utc(cls, v):
        return None if v is None else to_naive_utc(v)


class PickupSchedule(BaseModel):
    scheduled_at: datetime
    notes: Optional[str] = Field(default=None, max_length=500)

    @field_validator("scheduled_at")
    @classmethod
    def _to_utc(cls, v):
        return to_naive_utc(v)

    @field_validator("notes")
    @classmethod
    def _notes(cls, v):
        return clean_text(v)


class NoteBody(BaseModel):
    notes: Optional[str] = Field(default=None, max_length=500)

    @field_validator("notes")
    @classmethod
    def _notes(cls, v):
        return clean_text(v)


# ------------------------------------------------------------------ output

class PickupOut(BaseModel):
    id: int
    organization_id: int
    organization_name: Optional[str] = None
    scheduled_at: Optional[UTCDateTime] = None
    collected_at: Optional[UTCDateTime] = None
    completed_at: Optional[UTCDateTime] = None
    notes: Optional[str] = None


class ImpactRecordOut(BaseModel):
    meals_redistributed: int
    quantity_kg_est: float
    people_served_est: int
    created_at: UTCDateTime


class OrgSummary(BaseModel):
    id: int
    name: str


class MatchSummary(BaseModel):
    """A live match evaluation shown to an organization looking at a donation."""
    score: float
    breakdown: Dict[str, Any]


class DonationOut(BaseModel):
    id: int
    donor_id: int
    donor_name: Optional[str] = None
    title: str
    category: str
    is_vegetarian: bool
    quantity: float
    unit: str
    estimated_meals: int
    prepared_at: UTCDateTime
    available_until: UTCDateTime
    pickup_address: str
    latitude: float
    longitude: float
    description: Optional[str] = None
    handling_notes: Optional[str] = None
    contact_info: Optional[str] = None      # hidden from organizations until they accept
    status: str
    created_at: UTCDateTime
    accepted_by: Optional[OrgSummary] = None
    pickup: Optional[PickupOut] = None
    impact: Optional[ImpactRecordOut] = None
    # donor / admin view
    match_count: Optional[int] = None
    top_match_score: Optional[float] = None
    # organization view
    distance_km: Optional[float] = None
    my_match: Optional[MatchSummary] = None
    ineligible_reason: Optional[str] = None


class MatchOut(BaseModel):
    id: int
    donation_id: int
    organization_id: int
    organization: OrganizationPublic
    score: float
    rank: int
    score_breakdown: Dict[str, Any]
    created_at: UTCDateTime


class ExcludedOrg(BaseModel):
    organization_id: int
    organization_name: str
    code: str
    message: str


class MatchesResponse(BaseModel):
    donation_id: int
    status: str
    matches: List[MatchOut]
    excluded: List[ExcludedOrg] = []
    weights: Dict[str, float] = {}
