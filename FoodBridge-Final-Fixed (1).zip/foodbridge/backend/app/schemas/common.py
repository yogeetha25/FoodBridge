"""Shared schema helpers."""
from datetime import datetime, timezone
from typing import Annotated, Optional

from pydantic import PlainSerializer


def _serialize_utc(value: datetime) -> str:
    """Naive UTC datetimes are sent to the browser as ISO strings ending in 'Z'."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


UTCDateTime = Annotated[datetime, PlainSerializer(_serialize_utc, return_type=str, when_used="json")]


def clean_text(value: Optional[str]) -> Optional[str]:
    """Trim whitespace; empty strings become None."""
    if value is None:
        return None
    value = value.strip()
    return value or None


def strip_min(value: Optional[str], min_length: int) -> Optional[str]:
    """Trim whitespace, then re-check the minimum length.

    Field(min_length=...) is evaluated BEFORE trimming, so "   " would pass it and then be stored as an
    empty string. Use this helper in a field validator for every required text field. None passes through
    (for optional fields in partial updates).
    """
    if value is None:
        return None
    value = value.strip()
    if not value:
        raise ValueError("This field is required")
    if len(value) < min_length:
        raise ValueError(f"Enter at least {min_length} characters")
    return value
