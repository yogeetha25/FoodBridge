"""Impact estimation (pure Python).

ALL numbers here are ESTIMATES based on simple, documented assumptions:
  * 1 meal  ~ 0.4 kg of food        (used when a donation is not measured in kg)
  * 1 meal  ~ 1 person served       (one meal feeds one person once)
They are not scientific measurements. We deliberately do NOT compute CO2 figures.
"""
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Iterable, Tuple

KG_PER_MEAL = 0.4
PEOPLE_PER_MEAL = 1.0

ASSUMPTIONS = [
    "Meals redistributed = the donor's estimated number of meals for each COMPLETED donation.",
    f"Food weight is an estimate: donations measured in kg use that value; otherwise 1 meal is assumed to weigh about {KG_PER_MEAL} kg.",
    "People served is an estimate: 1 meal is assumed to serve 1 person once. Actual numbers may differ.",
    "No environmental (e.g. CO2) figures are calculated, because they cannot be measured reliably here.",
]


def calc_impact_figures(estimated_meals: int, quantity: float, unit: str) -> Tuple[int, float, int]:
    """Return (meals_redistributed, quantity_kg_est, people_served_est)."""
    meals = int(estimated_meals)
    kg = float(quantity) if unit == "KG" else meals * KG_PER_MEAL
    people = int(round(meals * PEOPLE_PER_MEAL))
    return meals, round(kg, 1), people


def week_start(dt: datetime) -> datetime:
    """Monday 00:00 of the week containing dt."""
    d = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    return d - timedelta(days=d.weekday())


def build_weekly_trend(created: Iterable[datetime], completed: Iterable[Tuple[datetime, int]],
                       now: datetime, weeks: int = 8):
    """Per-week counts for the last `weeks` weeks (oldest first)."""
    start = week_start(now) - timedelta(weeks=weeks - 1)
    buckets = OrderedDict()
    for i in range(weeks):
        key = start + timedelta(weeks=i)
        buckets[key] = {"label": key.strftime("%d %b"), "donations": 0, "completed": 0, "meals": 0}
    for dt in created:
        key = week_start(dt)
        if key in buckets:
            buckets[key]["donations"] += 1
    for dt, meals in completed:
        key = week_start(dt)
        if key in buckets:
            buckets[key]["completed"] += 1
            buckets[key]["meals"] += meals
    return list(buckets.values())


def _month_key(dt: datetime) -> Tuple[int, int]:
    return dt.year, dt.month


def build_monthly_trend(created: Iterable[datetime], completed: Iterable[Tuple[datetime, int]],
                        now: datetime, months: int = 6):
    """Per-month counts for the last `months` calendar months (oldest first)."""
    keys = []
    y, m = now.year, now.month
    for _ in range(months):
        keys.append((y, m))
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    keys.reverse()
    buckets = OrderedDict((k, {"label": datetime(k[0], k[1], 1).strftime("%b %Y"),
                               "donations": 0, "completed": 0, "meals": 0}) for k in keys)
    for dt in created:
        if _month_key(dt) in buckets:
            buckets[_month_key(dt)]["donations"] += 1
    for dt, meals in completed:
        if _month_key(dt) in buckets:
            buckets[_month_key(dt)]["completed"] += 1
            buckets[_month_key(dt)]["meals"] += meals
    return list(buckets.values())
