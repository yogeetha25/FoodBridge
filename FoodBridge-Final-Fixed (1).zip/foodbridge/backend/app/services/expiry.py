"""Automatic expiry: donations whose available-until time has passed become EXPIRED."""
from datetime import datetime
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.constants import EXPIRABLE_STATUSES, EXPIRED
from app.models import Donation
from app.utils.time import utcnow


def expire_overdue(db: Session, now: Optional[datetime] = None) -> int:
    """Mark overdue donations as EXPIRED. Only statuses that may legally move to EXPIRED
    (AVAILABLE, MATCHED, ACCEPTED - see the state machine) are touched. Returns how many changed."""
    now = now or utcnow()
    overdue = (Donation.status.in_(EXPIRABLE_STATUSES), Donation.available_until <= now)
    # Cheap read first: this runs on almost every request, and an UPDATE (even one matching no rows) would
    # take the database write lock each time.
    if db.scalar(select(Donation.id).where(*overdue).limit(1)) is None:
        return 0
    result = db.execute(
        update(Donation)
        .where(*overdue)
        .values(status=EXPIRED))
    db.commit()
    return result.rowcount or 0
