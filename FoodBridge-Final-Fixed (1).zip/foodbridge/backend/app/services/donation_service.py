"""Donation workflow: create, edit, cancel, list, accept, schedule pickup, collect, complete.
Every status change goes through status_machine.assert_transition()."""
from datetime import timedelta
from typing import Dict, List, Optional, Tuple

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.constants import (ACCEPTED, AVAILABLE, CANCELLED, COLLECTED, COMPLETED, OPEN_STATUSES,
                           PICKUP_PENDING, ROLE_ADMIN, ROLE_DONOR, ROLE_ORG, VERIFICATION_VERIFIED,
                           ALL_STATUSES, EXPIRED)
from app.errors import (ConflictError, ForbiddenError, NotFoundError, UnprocessableError)
from app.matching import scoring
from app.matching.engine import compute_matches, evaluate_for_org, org_current_load
from app.models import Donation, Match, Organization, Pickup, User
from app.schemas.donation import DonationCreate, DonationUpdate, PickupSchedule, NoteBody, _check_times
from app.services.expiry import expire_overdue
from app.services.impact_service import record_impact
from app.services.status_machine import assert_transition
from app.services.transitions import claim_status, ensure_status, transition
from app.utils.geo import haversine_km
from app.utils.time import utcnow

# (donation, extra fields for the organization view such as distance / live match)
Listing = List[Tuple[Donation, Dict]]

_LOAD_OPTIONS = (
    selectinload(Donation.donor),
    selectinload(Donation.pickup).selectinload(Pickup.organization),
    selectinload(Donation.impact),
    selectinload(Donation.matches),
)


# ------------------------------------------------------------------ helpers

def get_donation_or_404(db: Session, donation_id: int) -> Donation:
    # populate_existing: always refresh from the database, so relationships such as `pickup` are
    # never stale after an UPDATE/INSERT made earlier in the same request.
    donation = db.scalar(select(Donation).options(*_LOAD_OPTIONS)
                         .where(Donation.id == donation_id)
                         .execution_options(populate_existing=True))
    if donation is None:
        raise NotFoundError("Donation not found.")
    return donation


def _require_verified_org(user: User) -> Organization:
    org = user.organization
    if user.role != ROLE_ORG or org is None:
        raise ForbiddenError("Only receiving organizations can do that.")
    if org.verification_status != VERIFICATION_VERIFIED:
        raise ForbiddenError("Your organization must be verified by an administrator first.",
                             code="org_not_verified")
    return org


def _require_owner(donation: Donation, user: User) -> None:
    """Ownership check: donors may only touch their own donations (admins may cancel any)."""
    if donation.donor_id != user.id and user.role != ROLE_ADMIN:
        raise ForbiddenError("You can only manage your own donations.", code="not_owner")


def _require_accepting_org(donation: Donation, org: Organization) -> Pickup:
    if donation.pickup is None or donation.pickup.organization_id != org.id:
        raise ForbiddenError("Only the organization that accepted this donation can do that.",
                             code="not_accepting_org")
    return donation.pickup


def _open_and_unexpired(db: Session, donation: Donation) -> None:
    if donation.status == EXPIRED or donation.available_until <= utcnow():
        raise ConflictError("This donation has expired.", code="donation_expired")


def _add_note(pickup: Pickup, note: Optional[str]) -> None:
    """Keep every note from every stage (schedule / collect / complete) instead of overwriting the last."""
    if note:
        pickup.notes = f"{pickup.notes}\n{note}" if pickup.notes else note


# ------------------------------------------------------------------ donor actions

def create_donation(db: Session, donor: User, data: DonationCreate) -> Donation:
    donation = Donation(donor_id=donor.id, status=AVAILABLE, **data.model_dump())
    db.add(donation)
    db.flush()                       # get donation.id
    compute_matches(db, donation)    # AVAILABLE -> MATCHED if somebody is eligible
    db.commit()
    return get_donation_or_404(db, donation.id)


def update_donation(db: Session, donor: User, donation_id: int, data: DonationUpdate) -> Donation:
    expire_overdue(db)               # an overdue donation is EXPIRED (not editable), not "AVAILABLE with bad dates"
    donation = get_donation_or_404(db, donation_id)
    _require_owner(donation, donor)
    if donation.status not in OPEN_STATUSES:
        raise ConflictError("Only donations that are still waiting for an organization can be edited.",
                            code="not_editable")
    # Lock the row and re-check the status NOW: an organization may have accepted it a moment ago, and an
    # edit must never change quantity/location/time after acceptance.
    ensure_status(db, donation_id, OPEN_STATUSES)
    donation = get_donation_or_404(db, donation_id)
    changes = {k: v for k, v in data.model_dump(exclude_unset=True).items()
               if v is not None or k in ("description", "handling_notes")}
    for field, value in changes.items():
        setattr(donation, field, value)
    try:
        _check_times(donation.prepared_at, donation.available_until)
    except ValueError as exc:
        db.rollback()
        raise UnprocessableError(str(exc))
    compute_matches(db, donation)    # location/quantity/time may have changed
    db.commit()
    return get_donation_or_404(db, donation_id)


def cancel_donation(db: Session, user: User, donation_id: int) -> Donation:
    expire_overdue(db)               # an overdue donation must become EXPIRED, not CANCELLED (keeps statistics honest)
    donation = get_donation_or_404(db, donation_id)
    _require_owner(donation, user)
    if user.role == ROLE_DONOR and donation.status == PICKUP_PENDING:
        raise ConflictError("A pickup has already been arranged, so you can no longer cancel here. "
                            "Please contact the organization or report a problem.", code="pickup_started")
    transition(db, donation, CANCELLED)
    db.commit()
    return get_donation_or_404(db, donation_id)


# ------------------------------------------------------------------ listing (role aware)

def _base_query(*filters):
    return select(Donation).options(*_LOAD_OPTIONS).where(*filters).order_by(Donation.created_at.desc())


def list_donations(db: Session, user: User, view: Optional[str] = None,
                   status: Optional[str] = None) -> Listing:
    expire_overdue(db)
    if status and status not in ALL_STATUSES:
        raise UnprocessableError("Unknown donation status.")
    if user.role == ROLE_DONOR:
        filters = [Donation.donor_id == user.id]
        if status:
            filters.append(Donation.status == status)
        return [(d, {}) for d in db.scalars(_base_query(*filters)).unique().all()]
    if user.role == ROLE_ADMIN:
        filters = [Donation.status == status] if status else []
        return [(d, {}) for d in db.scalars(_base_query(*filters)).unique().all()]
    return _list_for_organization(db, user, view or "available")


def _list_for_organization(db: Session, user: User, view: str) -> Listing:
    org = _require_verified_org(user)
    now = utcnow()
    if view in ("available", "recommended"):
        open_donations = db.scalars(_base_query(Donation.status.in_(OPEN_STATUSES),
                                                Donation.available_until > now)).unique().all()
        load = org_current_load(db, org.id)          # one query, not one per donation
        rows: Listing = []
        for d in open_donations:
            distance = haversine_km(d.latitude, d.longitude, org.latitude, org.longitude)
            result = evaluate_for_org(db, d, org, now, load)
            if isinstance(result, scoring.MatchResult):
                extra = {"distance_km": round(result.distance_km, 2),
                         "my_match": {"score": result.score, "breakdown": result.breakdown()}}
            elif view == "recommended":
                continue                      # recommended = only donations this org is eligible for
            elif distance > org.service_radius_km:
                continue                      # "available nearby" = inside the service area
            else:
                extra = {"distance_km": round(distance, 2), "ineligible_reason": result.message}
            rows.append((d, extra))
        if view == "recommended":
            rows.sort(key=lambda r: -r[1]["my_match"]["score"])
        else:
            rows.sort(key=lambda r: r[1]["distance_km"])
        return rows
    mine = select(Pickup.donation_id).where(Pickup.organization_id == org.id)
    wanted = {"accepted": (ACCEPTED,), "pickups": (PICKUP_PENDING, COLLECTED), "completed": (COMPLETED,)}
    if view not in wanted:
        raise UnprocessableError("Unknown view. Use available, recommended, accepted, pickups or completed.")
    donations = db.scalars(_base_query(Donation.id.in_(mine), Donation.status.in_(wanted[view]))).unique().all()
    return [(d, {"distance_km": round(haversine_km(d.latitude, d.longitude, org.latitude, org.longitude), 2)})
            for d in donations]


# ------------------------------------------------------------------ detail & matches

def get_donation_for_viewer(db: Session, user: User, donation_id: int) -> Tuple[Donation, Dict]:
    expire_overdue(db)
    donation = get_donation_or_404(db, donation_id)
    if user.role == ROLE_ADMIN:
        return donation, {}
    if user.role == ROLE_DONOR:
        _require_owner(donation, user)
        return donation, {}
    org = _require_verified_org(user)
    mine = donation.pickup is not None and donation.pickup.organization_id == org.id
    if not mine and donation.status not in OPEN_STATUSES:
        raise ForbiddenError("This donation is no longer available to you.", code="not_visible")
    extra: Dict = {"distance_km": round(haversine_km(donation.latitude, donation.longitude,
                                                     org.latitude, org.longitude), 2)}
    if donation.status in OPEN_STATUSES:
        result = evaluate_for_org(db, donation, org)
        if isinstance(result, scoring.MatchResult):
            extra["distance_km"] = round(result.distance_km, 2)
            extra["my_match"] = {"score": result.score, "breakdown": result.breakdown()}
        else:
            extra["ineligible_reason"] = result.message
    return donation, extra


def get_matches(db: Session, user: User, donation_id: int):
    """Returns (donation, stored matches, exclusions). Open donations are re-scored first so the
    ranking reflects the current time, organization hours and capacity."""
    expire_overdue(db)
    donation = get_donation_or_404(db, donation_id)
    _require_owner(donation, user)           # donor must own it (admins pass)
    exclusions: List[scoring.Exclusion] = []
    if donation.status in OPEN_STATUSES and donation.available_until > utcnow():
        _, exclusions = compute_matches(db, donation)
        db.commit()
        if user.role != ROLE_ADMIN:  # donors never learn about unverified / inactive organizations
            exclusions = [e for e in exclusions if e.code not in (scoring.NOT_VERIFIED, scoring.INACTIVE)]
    else:
        exclusions = []
    matches = db.scalars(select(Match).options(selectinload(Match.organization))
                         .where(Match.donation_id == donation.id).order_by(Match.rank)).all()
    return donation, list(matches), exclusions


# ------------------------------------------------------------------ organization actions

def accept_donation(db: Session, user: User, donation_id: int) -> Donation:
    """First valid acceptance wins.

    Two organizations can click 'Accept' at the same moment. To make sure only one succeeds we do
    NOT rely on the status we read earlier. Instead we run ONE atomic statement:

        UPDATE donations SET status='ACCEPTED'
        WHERE id = ? AND status IN ('AVAILABLE','MATCHED') AND available_until > now

    The database applies it to one request at a time; the loser updates 0 rows and gets HTTP 409.
    The unique constraint on pickups.donation_id is a second safety net."""
    org = _require_verified_org(user)
    now = utcnow()
    expire_overdue(db, now)
    donation = get_donation_or_404(db, donation_id)

    if donation.status == EXPIRED or donation.available_until <= now:
        raise ConflictError("This donation has expired.", code="donation_expired")
    if donation.status not in OPEN_STATUSES:
        raise ConflictError("Another organization has already taken this donation, or it is no longer available.",
                            code="already_accepted")

    result = evaluate_for_org(db, donation, org, now)       # re-check every eligibility rule
    if isinstance(result, scoring.Exclusion):
        if result.code == scoring.INSUFFICIENT_CAPACITY:
            raise ConflictError(result.message, code="capacity_exceeded")
        raise ConflictError(result.message, code=result.code.lower())

    assert_transition(donation.status, ACCEPTED)
    if not claim_status(db, donation_id, OPEN_STATUSES, ACCEPTED):
        db.rollback()
        raise ConflictError("Another organization accepted this donation first.", code="already_accepted")
    db.add(Pickup(donation_id=donation_id, organization_id=org.id))
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise ConflictError("Another organization accepted this donation first.", code="already_accepted")
    # Capacity re-check INSIDE the same transaction. The evaluation above used a snapshot: if this
    # organization accepted a different donation at the same moment, both passed individually. Now that this
    # donation counts as committed, the total must still fit (the claim above holds the write lock).
    if org_current_load(db, org.id) > org.max_capacity_meals:
        db.rollback()
        raise ConflictError("Accepting this donation would exceed your organization's capacity.",
                            code="capacity_exceeded")
    db.commit()
    return get_donation_or_404(db, donation_id)


def schedule_pickup(db: Session, user: User, donation_id: int, data: PickupSchedule) -> Donation:
    org = _require_verified_org(user)
    expire_overdue(db)
    donation = get_donation_or_404(db, donation_id)
    pickup = _require_accepting_org(donation, org)
    _open_and_unexpired(db, donation)
    assert_transition(donation.status, PICKUP_PENDING)
    now = utcnow()
    if data.scheduled_at < now - timedelta(minutes=5):
        raise UnprocessableError("The pickup time cannot be in the past.", code="invalid_pickup_time")
    if data.scheduled_at > donation.available_until:
        raise UnprocessableError("The pickup must happen before the donation expires.", code="invalid_pickup_time")
    transition(db, donation, PICKUP_PENDING)
    pickup.scheduled_at = data.scheduled_at
    _add_note(pickup, data.notes)
    db.commit()
    return get_donation_or_404(db, donation_id)


def mark_collected(db: Session, user: User, donation_id: int, body: Optional[NoteBody]) -> Donation:
    org = _require_verified_org(user)
    donation = get_donation_or_404(db, donation_id)
    pickup = _require_accepting_org(donation, org)
    transition(db, donation, COLLECTED)
    pickup.collected_at = utcnow()
    _add_note(pickup, body.notes if body else None)
    db.commit()
    return get_donation_or_404(db, donation_id)


def mark_completed(db: Session, user: User, donation_id: int, body: Optional[NoteBody]) -> Donation:
    org = _require_verified_org(user)
    donation = get_donation_or_404(db, donation_id)
    pickup = _require_accepting_org(donation, org)
    transition(db, donation, COMPLETED)    # atomic: of two simultaneous requests only one gets here
    pickup.completed_at = utcnow()
    _add_note(pickup, body.notes if body else None)
    record_impact(db, donation)            # impact statistics are updated here
    db.commit()
    return get_donation_or_404(db, donation_id)
