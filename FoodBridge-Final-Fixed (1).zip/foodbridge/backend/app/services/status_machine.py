"""Donation status state machine (pure Python, no database).
Every status change in the application goes through assert_transition()."""
from app.constants import (AVAILABLE, MATCHED, ACCEPTED, PICKUP_PENDING, COLLECTED,
                           COMPLETED, CANCELLED, EXPIRED, ALL_STATUSES)
from app.errors import InvalidTransitionError

ALLOWED_TRANSITIONS = {
    AVAILABLE: {MATCHED, ACCEPTED, CANCELLED, EXPIRED},
    MATCHED: {AVAILABLE, ACCEPTED, CANCELLED, EXPIRED},   # back to AVAILABLE when nobody is eligible any more
    ACCEPTED: {PICKUP_PENDING, CANCELLED, EXPIRED},
    PICKUP_PENDING: {COLLECTED, CANCELLED},
    COLLECTED: {COMPLETED},
    COMPLETED: set(),
    CANCELLED: set(),
    EXPIRED: set(),
}
TERMINAL_STATUSES = (COMPLETED, CANCELLED, EXPIRED)


def can_transition(current: str, new: str) -> bool:
    return new in ALLOWED_TRANSITIONS.get(current, set())


def assert_transition(current: str, new: str) -> None:
    """Raise InvalidTransitionError (HTTP 409) if the change is not allowed."""
    if current not in ALL_STATUSES or new not in ALL_STATUSES:
        raise InvalidTransitionError(f"Unknown status '{current}' or '{new}'.")
    if not can_transition(current, new):
        raise InvalidTransitionError(
            f"A donation that is {current.replace('_', ' ').lower()} "
            f"cannot become {new.replace('_', ' ').lower()}.")
