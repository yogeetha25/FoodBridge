from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.constants import ROLE_ADMIN, VERIFICATION_STATUSES, VERIFICATION_VERIFIED
from app.errors import ConflictError, ForbiddenError, NotFoundError, UnprocessableError
from app.models import Organization, User
from app.schemas.organization import OrganizationUpdate


def get_organization_or_404(db: Session, org_id: int) -> Organization:
    org = db.scalar(select(Organization).options(joinedload(Organization.user)).where(Organization.id == org_id))
    if org is None:
        raise NotFoundError("Organization not found.")
    return org


def list_organizations(db: Session, user: User, status: Optional[str] = None) -> List[Organization]:
    stmt = select(Organization).options(joinedload(Organization.user)).order_by(Organization.created_at.desc())
    if user.role == ROLE_ADMIN:
        if status:
            if status not in VERIFICATION_STATUSES:
                raise UnprocessableError("Unknown verification status.")
            stmt = stmt.where(Organization.verification_status == status)
    else:  # everyone else only ever sees verified organizations
        stmt = stmt.where(Organization.verification_status == VERIFICATION_VERIFIED)
    return list(db.scalars(stmt).unique().all())


def update_organization(db: Session, org_id: int, user: User, data: OrganizationUpdate) -> Organization:
    org = get_organization_or_404(db, org_id)
    # Ownership check: only the organization's own account (or an admin) may edit it.
    if user.role != ROLE_ADMIN and org.user_id != user.id:
        raise ForbiddenError("You can only edit your own organization.")
    for field, value in data.model_dump(exclude_unset=True).items():
        if value is not None:
            setattr(org, field, value)
    db.commit()
    return org


def set_verification(db: Session, org_id: int, status: str) -> Organization:
    org = get_organization_or_404(db, org_id)
    if org.verification_status == status:
        raise ConflictError(f"This organization is already {status.lower()}.")
    org.verification_status = status
    db.commit()
    return org
