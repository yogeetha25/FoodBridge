"""Impact records and analytics. Figures come from impact_calc.py (documented estimates)."""
from datetime import timedelta
from typing import Dict

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.constants import (ACTIVE_STATUSES, CANCELLED, COMPLETED, EXPIRED, VERIFICATION_VERIFIED)
from app.models import Donation, ImpactRecord, Organization, Pickup
from app.services.impact_calc import (ASSUMPTIONS, build_monthly_trend, build_weekly_trend,
                                      calc_impact_figures)
from app.utils.time import utcnow


def record_impact(db: Session, donation: Donation) -> ImpactRecord:
    """Create the impact record for a completed donation (once)."""
    if donation.impact is not None:
        return donation.impact
    meals, kg, people = calc_impact_figures(donation.estimated_meals, donation.quantity, donation.unit)
    record = ImpactRecord(donation_id=donation.id, meals_redistributed=meals,
                          quantity_kg_est=kg, people_served_est=people)
    db.add(record)
    return record


def _summarise(rows, now) -> Dict:
    """rows: (status, created_at, has_pickup, meals, kg, people, impact_created_at) per donation.
    Plain column tuples instead of ORM objects: one query, little memory."""
    completed = [r for r in rows if r.status == COMPLETED and r.meals is not None]
    totals = {
        "total_donations": len(rows),
        "active_donations": sum(1 for r in rows if r.status in ACTIVE_STATUSES),
        "completed_donations": sum(1 for r in rows if r.status == COMPLETED),
        "cancelled_donations": sum(1 for r in rows if r.status == CANCELLED),
        "expired_donations": sum(1 for r in rows if r.status == EXPIRED),
        # a "successful match" = an organization accepted the donation at some point
        "successful_matches": sum(1 for r in rows if r.has_pickup),
        "meals_redistributed": sum(r.meals for r in completed),
        "quantity_kg_est": round(sum(r.kg for r in completed), 1),
        "people_served_est": sum(r.people for r in completed),
    }
    created = [r.created_at for r in rows]
    done = [(r.impact_created_at, r.meals) for r in completed]
    return {
        "totals": totals,
        "weekly": build_weekly_trend(created, done, now, weeks=8),
        "monthly": build_monthly_trend(created, done, now, months=6),
        "assumptions": ASSUMPTIONS,
        "is_estimate": True,
    }


def _load_rows(db: Session, *filters):
    stmt = (select(Donation.status.label("status"), Donation.created_at.label("created_at"),
                  Pickup.id.is_not(None).label("has_pickup"),
                  ImpactRecord.meals_redistributed.label("meals"), ImpactRecord.quantity_kg_est.label("kg"),
                  ImpactRecord.people_served_est.label("people"), ImpactRecord.created_at.label("impact_created_at"))
            .select_from(Donation)
            .outerjoin(Pickup, Pickup.donation_id == Donation.id)
            .outerjoin(ImpactRecord, ImpactRecord.donation_id == Donation.id)
            .where(*filters))
    return db.execute(stmt).all()


def platform_impact(db: Session) -> Dict:
    now = utcnow()
    data = _summarise(_load_rows(db), now)
    recent_cutoff = now - timedelta(days=30)
    data["totals"]["active_donors"] = db.scalar(
        select(func.count(func.distinct(Donation.donor_id))).where(Donation.created_at >= recent_cutoff)) or 0
    data["totals"]["verified_organizations"] = db.scalar(
        select(func.count(Organization.id)).where(Organization.verification_status == VERIFICATION_VERIFIED)) or 0
    return data


def donor_impact(db: Session, donor_id: int) -> Dict:
    return _summarise(_load_rows(db, Donation.donor_id == donor_id), utcnow())


def organization_impact(db: Session, org_id: int) -> Dict:
    return _summarise(_load_rows(db, Pickup.organization_id == org_id), utcnow())
