"""Atomic status changes (compare-and-set).

Reading a donation, checking its status in Python and then writing the new status is NOT safe when two
requests arrive together: both can read "COLLECTED" and both can write "COMPLETED". Instead every status
change here is ONE statement, `UPDATE donations SET status=? WHERE id=? AND status IN (...)`. The database
runs such statements one at a time, so exactly one caller sees rowcount == 1 and the other sees 0.
"""
from typing import Iterable

from sqlalchemy import update
from sqlalchemy.orm import Session

from app.errors import ConflictError
from app.models import Donation
from app.services.status_machine import assert_transition


def claim_status(db: Session, donation_id: int, allowed_from: Iterable[str], new_status: str) -> bool:
    """Move the donation to `new_status` only if it is currently in `allowed_from`.
    Returns True if THIS call performed the change. Does not commit."""
    result = db.execute(
        update(Donation)
        .where(Donation.id == donation_id, Donation.status.in_(tuple(allowed_from)))
        .values(status=new_status)
        .execution_options(synchronize_session="fetch"))
    return result.rowcount == 1


def transition(db: Session, donation: Donation, new_status: str) -> None:
    """Validate with the state machine, then change the status atomically.
    Raises InvalidTransitionError (409) for an illegal move, ConflictError (409) if somebody else changed
    the donation first. The caller commits."""
    current = donation.status
    assert_transition(current, new_status)
    if not claim_status(db, donation.id, (current,), new_status):
        db.rollback()
        raise ConflictError("This donation was just changed by someone else. Please refresh and try again.",
                            code="concurrent_update")


def ensure_status(db: Session, donation_id: int, allowed: Iterable[str]) -> None:
    """Take the write lock on the donation row and verify it is STILL in one of `allowed` (no change made).
    Used before editing, so an edit can never be applied after an organization has accepted the donation."""
    result = db.execute(
        update(Donation)
        .where(Donation.id == donation_id, Donation.status.in_(tuple(allowed)))
        .values(status=Donation.status)
        .execution_options(synchronize_session=False))
    if result.rowcount != 1:
        db.rollback()
        raise ConflictError("This donation can no longer be changed because its status just changed.",
                            code="concurrent_update")
