from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.constants import (REPORT_DISMISSED, REPORT_IN_REVIEW, REPORT_OPEN, REPORT_RESOLVED, REPORT_STATUSES,
                           ROLE_ADMIN)
from app.errors import ConflictError, ForbiddenError, NotFoundError, UnprocessableError
from app.models import Donation, Report, User
from app.schemas.report import ReportCreate, ReportUpdate


def create_report(db: Session, user: User, data: ReportCreate) -> Report:
    donation = db.get(Donation, data.donation_id)
    if donation is None:
        raise NotFoundError("Donation not found.")
    is_donor = donation.donor_id == user.id
    is_accepting_org = bool(user.organization and donation.pickup
                            and donation.pickup.organization_id == user.organization.id)
    if not (is_donor or is_accepting_org):
        raise ForbiddenError("You can only report donations you are involved in.")
    duplicate = db.scalar(select(Report.id).where(
        Report.donation_id == donation.id, Report.reporter_id == user.id, Report.reason == data.reason,
        Report.status.in_((REPORT_OPEN, REPORT_IN_REVIEW))).limit(1))
    if duplicate:
        raise ConflictError("You have already reported this problem and it is still being reviewed.",
                            code="duplicate_report")
    report = Report(donation_id=donation.id, reporter_id=user.id, reason=data.reason, details=data.details)
    db.add(report)
    db.commit()
    return report


def list_reports(db: Session, user: User, status: Optional[str] = None) -> List[Report]:
    stmt = (select(Report).options(joinedload(Report.donation), joinedload(Report.reporter))
            .order_by(Report.created_at.desc()))
    if user.role != ROLE_ADMIN:
        stmt = stmt.where(Report.reporter_id == user.id)   # people only see their own reports
    if status:
        if status not in REPORT_STATUSES:
            raise UnprocessableError("Unknown report status.")
        stmt = stmt.where(Report.status == status)
    return list(db.scalars(stmt).unique().all())


def update_report(db: Session, admin: User, report_id: int, data: ReportUpdate) -> Report:
    report = db.get(Report, report_id)
    if report is None:
        raise NotFoundError("Report not found.")
    changes = data.model_dump(exclude_unset=True)
    if "status" in changes and changes["status"]:
        report.status = changes["status"]
        report.resolved_by = admin.id if report.status in (REPORT_RESOLVED, REPORT_DISMISSED) else None
    if "resolution_notes" in changes:
        report.resolution_notes = changes["resolution_notes"]
    db.commit()
    return report
