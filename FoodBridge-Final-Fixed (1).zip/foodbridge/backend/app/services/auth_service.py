from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.auth.security import hash_password, verify_password
from app.constants import ROLE_ORG, VERIFICATION_PENDING
from app.errors import ConflictError, ForbiddenError, UnauthorizedError
from app.models import Organization, User
from app.schemas.auth import LoginRequest, ProfileUpdate, RegisterRequest

# Hash used to keep login timing similar when the email does not exist.
_DUMMY_HASH = hash_password("not-a-real-password-1")


def register_user(db: Session, data: RegisterRequest) -> User:
    if db.scalar(select(User).where(User.email == data.email)):
        raise ConflictError("An account with this email already exists.", code="email_taken")
    user = User(email=data.email, password_hash=hash_password(data.password), role=data.role,
                full_name=data.full_name, phone=data.phone, donor_type=data.donor_type)
    if data.role == ROLE_ORG:
        # New organizations start PENDING: they cannot be matched until an admin verifies them.
        user.organization = Organization(**data.organization.model_dump(),
                                         verification_status=VERIFICATION_PENDING)
    db.add(user)
    try:
        db.commit()
    except IntegrityError:  # two simultaneous registrations with the same email
        db.rollback()
        raise ConflictError("An account with this email already exists.", code="email_taken")
    return user


def authenticate(db: Session, data: LoginRequest) -> User:
    user = db.scalar(select(User).where(User.email == data.email))
    if user is None:
        verify_password(data.password, _DUMMY_HASH)
        raise UnauthorizedError("Incorrect email or password.", code="invalid_credentials")
    if not verify_password(data.password, user.password_hash):
        raise UnauthorizedError("Incorrect email or password.", code="invalid_credentials")
    if not user.is_active:
        raise ForbiddenError("This account has been deactivated. Contact an administrator.",
                             code="account_inactive")
    return user


def update_profile(db: Session, user: User, data: ProfileUpdate) -> User:
    changes = data.model_dump(exclude_unset=True)
    for field in ("full_name", "phone", "donor_type"):
        if field in changes and (changes[field] is not None or field == "phone"):
            setattr(user, field, changes[field])
    db.commit()
    return user
