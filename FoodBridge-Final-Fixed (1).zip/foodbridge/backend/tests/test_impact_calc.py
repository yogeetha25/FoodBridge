from datetime import datetime

import pytest

from app.services.impact_calc import (KG_PER_MEAL, build_monthly_trend, build_weekly_trend,
                                      calc_impact_figures, week_start)


def test_figures_for_meals_unit():
    meals, kg, people = calc_impact_figures(100, 100, "MEALS")
    assert meals == 100
    assert kg == pytest.approx(100 * KG_PER_MEAL)
    assert people == 100


def test_figures_use_real_kg_when_unit_is_kg():
    meals, kg, people = calc_impact_figures(50, 30, "KG")
    assert meals == 50 and kg == 30 and people == 50


def test_week_start_is_monday():
    assert week_start(datetime(2026, 5, 7, 15, 30)).weekday() == 0  # 7 May 2026 is a Thursday


def test_weekly_trend_buckets():
    now = datetime(2026, 5, 7, 12, 0)
    created = [datetime(2026, 5, 6), datetime(2026, 5, 5), datetime(2026, 4, 28)]
    completed = [(datetime(2026, 5, 6), 40), (datetime(2026, 4, 29), 60)]
    weeks = build_weekly_trend(created, completed, now, weeks=4)
    assert len(weeks) == 4
    assert weeks[-1]["donations"] == 2 and weeks[-1]["meals"] == 40
    assert weeks[-2]["donations"] == 1 and weeks[-2]["meals"] == 60


def test_monthly_trend_handles_year_boundary():
    now = datetime(2026, 2, 10)
    months = build_monthly_trend([datetime(2025, 12, 5)], [(datetime(2026, 1, 3), 25)], now, months=3)
    assert [m["label"] for m in months] == ["Dec 2025", "Jan 2026", "Feb 2026"]
    assert months[0]["donations"] == 1
    assert months[1]["meals"] == 25
