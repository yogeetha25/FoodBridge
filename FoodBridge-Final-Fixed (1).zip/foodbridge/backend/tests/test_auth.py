from app.models import User
from tests.helpers import PASSWORD, auth, register_donor, register_org


def test_register_donor_returns_token_and_user(client):
    token, user = register_donor(client)
    assert token and user["role"] == "DONOR" and user["email"] == "donor@test.dev"
    assert "password" not in str(user).lower().replace("password_hash", "")


def test_register_organization_starts_pending(client):
    _, user = register_org(client)
    assert user["role"] == "ORGANIZATION"
    assert user["organization"]["verification_status"] == "PENDING"


def test_duplicate_email_is_rejected(client):
    register_donor(client)
    resp = client.post("/api/auth/register", json={
        "email": "DONOR@test.dev", "password": PASSWORD, "full_name": "Again", "role": "DONOR"})
    assert resp.status_code == 409 and resp.json()["code"] == "email_taken"


def test_cannot_self_register_as_admin(client):
    resp = client.post("/api/auth/register", json={
        "email": "evil@test.dev", "password": PASSWORD, "full_name": "Evil", "role": "ADMIN"})
    assert resp.status_code == 422


def test_weak_password_is_rejected(client):
    resp = client.post("/api/auth/register", json={
        "email": "a@test.dev", "password": "onlyletters", "full_name": "Weak", "role": "DONOR"})
    assert resp.status_code == 422


def test_organization_registration_requires_organization_details(client):
    resp = client.post("/api/auth/register", json={
        "email": "o@test.dev", "password": PASSWORD, "full_name": "No Org", "role": "ORGANIZATION"})
    assert resp.status_code == 422


def test_password_is_stored_hashed(client, db):
    register_donor(client)
    user = db.query(User).filter_by(email="donor@test.dev").one()
    assert user.password_hash != PASSWORD and user.password_hash.startswith("$2")


def test_login_success(client):
    register_donor(client)
    resp = client.post("/api/auth/login", json={"email": "donor@test.dev", "password": PASSWORD})
    assert resp.status_code == 200 and resp.json()["access_token"]


def test_login_wrong_password(client):
    register_donor(client)
    resp = client.post("/api/auth/login", json={"email": "donor@test.dev", "password": "WrongPass1"})
    assert resp.status_code == 401 and resp.json()["code"] == "invalid_credentials"


def test_login_unknown_email_gives_same_message(client):
    resp = client.post("/api/auth/login", json={"email": "nobody@test.dev", "password": "Whatever1"})
    assert resp.status_code == 401 and resp.json()["detail"] == "Incorrect email or password."


def test_me_requires_authentication(client):
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/auth/me", headers=auth("not.a.token")).status_code == 401


def test_me_returns_current_user(client):
    token, _ = register_donor(client)
    resp = client.get("/api/auth/me", headers=auth(token))
    assert resp.status_code == 200 and resp.json()["email"] == "donor@test.dev"


def test_deactivated_user_cannot_log_in(client, db):
    register_donor(client)
    user = db.query(User).filter_by(email="donor@test.dev").one()
    user.is_active = False
    db.commit()
    resp = client.post("/api/auth/login", json={"email": "donor@test.dev", "password": PASSWORD})
    assert resp.status_code == 403
