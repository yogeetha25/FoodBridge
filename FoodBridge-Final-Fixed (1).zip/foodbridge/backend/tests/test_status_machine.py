import pytest

from app.constants import ALL_STATUSES
from app.errors import InvalidTransitionError
from app.services.status_machine import ALLOWED_TRANSITIONS, assert_transition, can_transition

VALID = [
    ("AVAILABLE", "MATCHED"), ("AVAILABLE", "ACCEPTED"), ("AVAILABLE", "CANCELLED"), ("AVAILABLE", "EXPIRED"),
    ("MATCHED", "AVAILABLE"),   # nobody is eligible any more (edit, or capacity used up)
    ("MATCHED", "ACCEPTED"), ("MATCHED", "CANCELLED"), ("MATCHED", "EXPIRED"),
    ("ACCEPTED", "PICKUP_PENDING"), ("ACCEPTED", "CANCELLED"), ("ACCEPTED", "EXPIRED"),
    ("PICKUP_PENDING", "COLLECTED"), ("PICKUP_PENDING", "CANCELLED"),
    ("COLLECTED", "COMPLETED"),
]


def test_every_valid_transition_is_allowed():
    for current, new in VALID:
        assert can_transition(current, new), (current, new)
        assert_transition(current, new)  # must not raise


def test_every_other_transition_is_rejected():
    valid = set(VALID)
    for current in ALL_STATUSES:
        for new in ALL_STATUSES:
            if (current, new) not in valid:
                assert not can_transition(current, new), (current, new)
                with pytest.raises(InvalidTransitionError):
                    assert_transition(current, new)


def test_terminal_states_have_no_exits():
    for status in ("COMPLETED", "CANCELLED", "EXPIRED"):
        assert ALLOWED_TRANSITIONS[status] == set()


def test_cannot_skip_steps():
    with pytest.raises(InvalidTransitionError):
        assert_transition("ACCEPTED", "COLLECTED")
    with pytest.raises(InvalidTransitionError):
        assert_transition("AVAILABLE", "COMPLETED")


def test_unknown_status_is_rejected():
    with pytest.raises(InvalidTransitionError):
        assert_transition("AVAILABLE", "NOT_A_STATUS")
