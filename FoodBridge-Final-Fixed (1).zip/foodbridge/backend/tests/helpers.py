"""Small helpers that create users and donations through the real API."""
from datetime import datetime, timedelta, timezone

from app.auth.security import hash_password
from app.models import Organization, User

PASSWORD = "Passw0rdTest"


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def register_donor(client, email="donor@test.dev", name="Test Donor"):
    resp = client.post("/api/auth/register", json={
        "email": email, "password": PASSWORD, "full_name": name, "phone": "9999999999",
        "role": "DONOR", "donor_type": "RESTAURANT"})
    assert resp.status_code == 201, resp.text
    body = resp.json()
    return body["access_token"], body["user"]


def org_details(**overrides) -> dict:
    data = {"name": "Test Kitchen", "organization_type": "COMMUNITY_KITCHEN", "contact_person": "Asha",
            "phone": "8888888888", "address": "Koramangala, Bengaluru", "latitude": 12.9279,
            "longitude": 77.6271, "service_radius_km": 15, "max_capacity_meals": 300,
            "preferred_categories": [], "food_preferences": "BOTH", "operating_hours": "24/7"}
    data.update(overrides)
    return data


def register_org(client, email="ngo@test.dev", **org_overrides):
    resp = client.post("/api/auth/register", json={
        "email": email, "password": PASSWORD, "full_name": "Org Contact", "phone": "8888888888",
        "role": "ORGANIZATION", "organization": org_details(**org_overrides)})
    assert resp.status_code == 201, resp.text
    body = resp.json()
    return body["access_token"], body["user"]


def verify_in_db(session_factory, org_id: int, status="VERIFIED"):
    with session_factory() as s:
        org = s.get(Organization, org_id)
        org.verification_status = status
        s.commit()


def make_admin(client, session_factory, email="admin@test.dev"):
    with session_factory() as s:
        s.add(User(email=email, password_hash=hash_password(PASSWORD), role="ADMIN", full_name="Admin"))
        s.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": PASSWORD})
    assert resp.status_code == 200, resp.text
    return resp.json()["access_token"]


def verified_org(client, session_factory, email="ngo@test.dev", **org_overrides):
    token, user = register_org(client, email, **org_overrides)
    verify_in_db(session_factory, user["organization"]["id"])
    return token, user


def donation_payload(**overrides) -> dict:
    now = datetime.now(timezone.utc)
    data = {"title": "Veg meals from fest", "category": "COOKED_MEALS", "is_vegetarian": True,
            "quantity": 100, "unit": "MEALS", "estimated_meals": 100,
            "prepared_at": iso(now - timedelta(minutes=30)), "available_until": iso(now + timedelta(hours=3)),
            "pickup_address": "ABC College, Koramangala", "latitude": 12.9352, "longitude": 77.6245,
            "description": "Freshly cooked", "handling_notes": "Keep covered",
            "contact_info": "Test Donor 9999999999"}
    data.update(overrides)
    return data


def create_donation(client, token, **overrides):
    resp = client.post("/api/donations", json=donation_payload(**overrides), headers=auth(token))
    assert resp.status_code == 201, resp.text
    return resp.json()
