from datetime import datetime, timedelta, timezone

from app.models import Donation
from tests.helpers import auth, create_donation, donation_payload, iso, register_donor, verified_org


def post(client, token, **overrides):
    return client.post("/api/donations", json=donation_payload(**overrides), headers=auth(token))


# ---------------------------------------------------------------- creation & validation
def test_create_donation_without_eligible_organizations_stays_available(client):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    assert d["status"] == "AVAILABLE" and d["match_count"] == 0


def test_create_donation_with_eligible_organization_becomes_matched(client, session_factory):
    token, _ = register_donor(client)
    verified_org(client, session_factory)
    d = create_donation(client, token)
    assert d["status"] == "MATCHED" and d["match_count"] == 1 and d["top_match_score"] > 0


def test_available_until_in_the_past_is_rejected(client):
    token, _ = register_donor(client)
    past = iso(datetime.now(timezone.utc) - timedelta(minutes=5))
    resp = post(client, token, available_until=past, prepared_at=iso(datetime.now(timezone.utc) - timedelta(hours=2)))
    assert resp.status_code == 422


def test_zero_or_negative_quantities_are_rejected(client):
    token, _ = register_donor(client)
    assert post(client, token, quantity=0).status_code == 422
    assert post(client, token, estimated_meals=0).status_code == 422
    assert post(client, token, quantity=-5).status_code == 422


def test_invalid_coordinates_are_rejected(client):
    token, _ = register_donor(client)
    assert post(client, token, latitude=123).status_code == 422
    assert post(client, token, longitude=-200).status_code == 422


def test_missing_required_fields_are_rejected(client):
    token, _ = register_donor(client)
    payload = donation_payload()
    del payload["title"]
    resp = client.post("/api/donations", json=payload, headers=auth(token))
    assert resp.status_code == 422 and resp.json()["errors"]


def test_unknown_category_or_unit_is_rejected(client):
    token, _ = register_donor(client)
    assert post(client, token, category="ROCKS").status_code == 422
    assert post(client, token, unit="TONNES").status_code == 422


def test_prepared_time_must_be_before_available_until(client):
    token, _ = register_donor(client)
    later = iso(datetime.now(timezone.utc) + timedelta(hours=5))
    assert post(client, token, prepared_at=later).status_code == 422


# ---------------------------------------------------------------- matching through the API
def test_matches_endpoint_ranks_nearer_organization_first(client, session_factory):
    token, _ = register_donor(client)
    verified_org(client, session_factory, "near@ngo.dev", name="Near NGO", latitude=12.9400, longitude=77.6300)
    verified_org(client, session_factory, "far@ngo.dev", name="Far NGO", latitude=13.0300, longitude=77.7000)
    d = create_donation(client, token)
    body = client.get(f"/api/donations/{d['id']}/matches", headers=auth(token)).json()
    names = [m["organization"]["name"] for m in body["matches"]]
    assert names == ["Near NGO", "Far NGO"]
    assert body["matches"][0]["score"] > body["matches"][1]["score"]
    assert body["matches"][0]["rank"] == 1
    assert len(body["matches"][0]["score_breakdown"]["reasons"]) == 5


def test_matches_endpoint_lists_excluded_organizations_with_reasons(client, session_factory):
    token, _ = register_donor(client)
    verified_org(client, session_factory, "ok@ngo.dev", name="Good NGO")
    verified_org(client, session_factory, "small@ngo.dev", name="Tiny NGO", max_capacity_meals=20)
    d = create_donation(client, token)
    body = client.get(f"/api/donations/{d['id']}/matches", headers=auth(token)).json()
    assert [m["organization"]["name"] for m in body["matches"]] == ["Good NGO"]
    assert body["excluded"][0]["code"] == "INSUFFICIENT_CAPACITY"


def test_unverified_organizations_are_never_matched_or_revealed_to_donors(client):
    from tests.helpers import register_org
    token, _ = register_donor(client)
    register_org(client, "pending@ngo.dev", name="Pending NGO")
    d = create_donation(client, token)
    body = client.get(f"/api/donations/{d['id']}/matches", headers=auth(token)).json()
    assert body["matches"] == [] and body["excluded"] == []


# ---------------------------------------------------------------- editing & cancelling
def test_donor_can_edit_open_donation_and_matches_are_recomputed(client, session_factory):
    token, _ = register_donor(client)
    verified_org(client, session_factory, max_capacity_meals=150)
    d = create_donation(client, token, estimated_meals=100)
    assert d["match_count"] == 1
    resp = client.patch(f"/api/donations/{d['id']}", json={"estimated_meals": 400}, headers=auth(token))
    assert resp.status_code == 200 and resp.json()["estimated_meals"] == 400 and resp.json()["match_count"] == 0


def test_donor_can_cancel_and_cannot_cancel_twice(client):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    first = client.post(f"/api/donations/{d['id']}/cancel", headers=auth(token))
    assert first.status_code == 200 and first.json()["status"] == "CANCELLED"
    again = client.post(f"/api/donations/{d['id']}/cancel", headers=auth(token))
    assert again.status_code == 409 and again.json()["code"] == "invalid_transition"


def test_cancelled_donation_cannot_be_edited(client):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    client.post(f"/api/donations/{d['id']}/cancel", headers=auth(token))
    assert client.patch(f"/api/donations/{d['id']}", json={"title": "New title"}, headers=auth(token)).status_code == 409


def test_unknown_donation_returns_404(client):
    token, _ = register_donor(client)
    assert client.get("/api/donations/9999", headers=auth(token)).status_code == 404


def test_overdue_donation_is_listed_as_expired(client, session_factory):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    with session_factory() as s:
        row = s.get(Donation, d["id"])
        row.available_until = datetime.utcnow() - timedelta(minutes=1)
        s.commit()
    listed = client.get("/api/donations", headers=auth(token)).json()
    assert listed[0]["status"] == "EXPIRED"
