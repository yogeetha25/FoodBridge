from tests.helpers import (auth, create_donation, make_admin, register_donor, register_org,
                           verified_org)


def test_donor_cannot_use_admin_endpoints(client):
    token, _ = register_donor(client)
    for path in ("/api/admin/dashboard", "/api/admin/users", "/api/admin/organizations", "/api/admin/donations"):
        assert client.get(path, headers=auth(token)).status_code == 403, path


def test_anonymous_cannot_use_protected_endpoints(client):
    assert client.get("/api/donations").status_code == 401
    assert client.get("/api/admin/dashboard").status_code == 401


def test_organization_cannot_create_donation(client, session_factory):
    org_token, _ = verified_org(client, session_factory)
    from tests.helpers import donation_payload
    resp = client.post("/api/donations", json=donation_payload(), headers=auth(org_token))
    assert resp.status_code == 403


def test_donor_cannot_accept_donation(client, session_factory):
    donor_token, _ = register_donor(client)
    verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    assert client.post(f"/api/donations/{d['id']}/accept", headers=auth(donor_token)).status_code == 403


def test_donor_cannot_view_or_change_another_donors_donation(client):
    token_a, _ = register_donor(client, "a@test.dev")
    token_b, _ = register_donor(client, "b@test.dev", "Donor B")
    d = create_donation(client, token_a)
    assert client.get(f"/api/donations/{d['id']}", headers=auth(token_b)).status_code == 403
    assert client.patch(f"/api/donations/{d['id']}", json={"title": "Hacked title"}, headers=auth(token_b)).status_code == 403
    assert client.post(f"/api/donations/{d['id']}/cancel", headers=auth(token_b)).status_code == 403
    assert client.get(f"/api/donations/{d['id']}/matches", headers=auth(token_b)).status_code == 403
    # donor B's own list does not contain it
    assert client.get("/api/donations", headers=auth(token_b)).json() == []


def test_organization_cannot_edit_another_organization(client, session_factory):
    _, user_a = verified_org(client, session_factory, "a@ngo.dev", name="NGO A")
    token_b, _ = verified_org(client, session_factory, "b@ngo.dev", name="NGO B")
    resp = client.patch(f"/api/organizations/{user_a['organization']['id']}", json={"name": "Taken over"},
                        headers=auth(token_b))
    assert resp.status_code == 403


def test_organization_can_edit_its_own_profile(client, session_factory):
    token, user = verified_org(client, session_factory)
    resp = client.patch(f"/api/organizations/{user['organization']['id']}", json={"max_capacity_meals": 500},
                        headers=auth(token))
    assert resp.status_code == 200 and resp.json()["max_capacity_meals"] == 500


def test_unverified_organization_cannot_browse_or_accept(client):
    donor_token, _ = register_donor(client)
    org_token, _ = register_org(client)            # stays PENDING
    d = create_donation(client, donor_token)
    assert client.get("/api/donations?view=available", headers=auth(org_token)).status_code == 403
    assert client.post(f"/api/donations/{d['id']}/accept", headers=auth(org_token)).status_code == 403


def test_donor_contact_hidden_from_organization_until_accepted(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    before = client.get(f"/api/donations/{d['id']}", headers=auth(org_token)).json()
    assert before["contact_info"] is None
    client.post(f"/api/donations/{d['id']}/accept", headers=auth(org_token))
    after = client.get(f"/api/donations/{d['id']}", headers=auth(org_token)).json()
    assert after["contact_info"]


def test_admin_can_verify_and_reject_organizations(client, session_factory):
    admin_token = make_admin(client, session_factory)
    _, user = register_org(client)
    org_id = user["organization"]["id"]
    ok = client.post(f"/api/admin/organizations/{org_id}/verify", headers=auth(admin_token))
    assert ok.status_code == 200 and ok.json()["verification_status"] == "VERIFIED"
    rejected = client.post(f"/api/admin/organizations/{org_id}/reject", headers=auth(admin_token))
    assert rejected.json()["verification_status"] == "REJECTED"


def test_non_admin_cannot_verify_organization(client):
    donor_token, _ = register_donor(client)
    _, user = register_org(client)
    resp = client.post(f"/api/admin/organizations/{user['organization']['id']}/verify", headers=auth(donor_token))
    assert resp.status_code == 403
