from datetime import datetime

import pytest

from app.utils.geo import haversine_km, valid_coordinates
from app.utils.hours import is_open_at, is_valid_hours, parse_hours


def test_haversine_zero_distance():
    assert haversine_km(12.97, 77.59, 12.97, 77.59) == pytest.approx(0.0, abs=1e-9)


def test_haversine_known_distance():
    # Bengaluru -> Chennai is about 290 km in a straight line
    d = haversine_km(12.9716, 77.5946, 13.0827, 80.2707)
    assert 280 < d < 300


def test_haversine_is_symmetric():
    a = haversine_km(12.9, 77.6, 13.0, 77.7)
    b = haversine_km(13.0, 77.7, 12.9, 77.6)
    assert a == pytest.approx(b)


def test_valid_coordinates():
    assert valid_coordinates(12.9, 77.6)
    assert not valid_coordinates(95, 10)
    assert not valid_coordinates(10, 181)


def test_hours_parsing():
    assert parse_hours("09:00-18:00") == (540, 1080)
    assert is_valid_hours("24/7")
    assert not is_valid_hours("9am-6pm")
    assert not is_valid_hours("10:00-10:00")


def test_is_open_with_utc_offset():
    # 06:00 UTC is 11:30 in IST (UTC+5:30)
    when = datetime(2026, 1, 5, 6, 0)
    assert is_open_at("09:00-18:00", when, 330)
    assert not is_open_at("12:00-18:00", when, 330)


def test_overnight_window():
    # 20:00-02:00 crosses midnight. 21:00 UTC = 02:30 IST -> closed; 17:00 UTC = 22:30 IST -> open
    assert is_open_at("20:00-02:00", datetime(2026, 1, 5, 17, 0), 330)
    assert not is_open_at("20:00-02:00", datetime(2026, 1, 5, 21, 0), 330)
