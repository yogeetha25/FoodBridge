"""Shared pytest fixtures. Each test gets a brand-new temporary SQLite database."""
import os

# A fixed, long-enough key for tests, set BEFORE the app is imported so no key file is created in the project.
os.environ.setdefault("SECRET_KEY", "test-only-secret-key-for-the-automated-test-suite-0123456789")

from app.config import settings

settings.BCRYPT_ROUNDS = 4          # fast password hashing in tests (must be set before the app is imported)

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import app.models  # noqa: F401,E402  (register tables)
from app.database.session import Base, get_db
from app.main import app as fastapi_app


@pytest.fixture()
def session_factory(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'test.db'}",
                           connect_args={"check_same_thread": False, "timeout": 30})
    Base.metadata.create_all(engine)
    yield sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    engine.dispose()


@pytest.fixture()
def db(session_factory):
    session = session_factory()
    yield session
    session.close()


@pytest.fixture()
def client(session_factory):
    def override_get_db():
        session = session_factory()
        try:
            yield session
        finally:
            session.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    # No "with" block: the lifespan (and its background expiry task) is not started in tests.
    yield TestClient(fastapi_app)
    fastapi_app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def _reset_login_throttle():
    """The login throttle is process-wide state; every test starts with a clean slate."""
    from app.auth.throttle import login_throttle
    login_throttle.clear_all()
    yield
    login_throttle.clear_all()
