"""Regressions for status integrity, race conditions, efficiency and data-loss bugs."""
import threading
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import event, select

from app.errors import ConflictError
from app.matching import scoring
from app.models import Donation, ImpactRecord, Pickup, User
from app.schemas.donation import DonationUpdate
from app.services import donation_service
from app.services.expiry import expire_overdue
from tests.helpers import (auth, create_donation, iso, make_admin, register_donor, verified_org)


def accept(client, token, did):
    return client.post(f"/api/donations/{did}/accept", headers=auth(token))


def schedule(client, token, did, minutes=20, notes=None):
    return client.post(f"/api/donations/{did}/pickup", headers=auth(token), json={
        "scheduled_at": iso(datetime.now(timezone.utc) + timedelta(minutes=minutes)), "notes": notes})


def make_overdue(session_factory, donation_id):
    with session_factory() as s:
        s.get(Donation, donation_id).available_until = datetime.utcnow() - timedelta(minutes=5)
        s.commit()


# ------------------------------------------------------------------ expiry vs cancel / edit
def test_cancelling_an_overdue_donation_does_not_turn_it_into_cancelled(client, session_factory):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    make_overdue(session_factory, d["id"])
    resp = client.post(f"/api/donations/{d['id']}/cancel", headers=auth(token))
    assert resp.status_code == 409                        # already expired: cannot be cancelled
    assert client.get(f"/api/donations/{d['id']}", headers=auth(token)).json()["status"] == "EXPIRED"


def test_editing_an_overdue_donation_says_it_is_not_editable(client, session_factory):
    token, _ = register_donor(client)
    d = create_donation(client, token)
    make_overdue(session_factory, d["id"])
    resp = client.patch(f"/api/donations/{d['id']}", json={"title": "A new title"}, headers=auth(token))
    assert resp.status_code == 409 and resp.json()["code"] == "not_editable"


def test_expiry_check_does_not_write_when_nothing_is_overdue(client, session_factory):
    token, _ = register_donor(client)
    create_donation(client, token)
    writes = []
    with session_factory() as s:
        event.listen(s.get_bind(), "before_cursor_execute",
                     lambda c, cur, stmt, *a: writes.append(stmt) if stmt.lstrip().upper().startswith("UPDATE") else None)
        assert expire_overdue(s) == 0
    assert writes == []


# ------------------------------------------------------------------ status honesty
def test_status_returns_to_available_when_nobody_is_eligible_and_back(client, session_factory):
    token, _ = register_donor(client)
    verified_org(client, session_factory)
    d = create_donation(client, token)
    assert d["status"] == "MATCHED" and d["match_count"] == 1
    far = client.patch(f"/api/donations/{d['id']}", json={"latitude": 28.61, "longitude": 77.20}, headers=auth(token))
    assert far.status_code == 200
    assert far.json()["status"] == "AVAILABLE" and far.json()["match_count"] == 0
    near = client.patch(f"/api/donations/{d['id']}", json={"latitude": 12.9352, "longitude": 77.6245}, headers=auth(token))
    assert near.json()["status"] == "MATCHED" and near.json()["match_count"] == 1


# ------------------------------------------------------------------ races
def test_two_simultaneous_completions_produce_one_winner_and_one_impact_record(client, session_factory):
    dt, _ = register_donor(client)
    ot, ou = verified_org(client, session_factory)
    d = create_donation(client, dt)
    accept(client, ot, d["id"]); schedule(client, ot, d["id"])
    client.post(f"/api/donations/{d['id']}/collect", headers=auth(ot))

    outcomes, barrier = [], threading.Barrier(2)

    def go():
        s = session_factory()
        try:
            barrier.wait()
            donation_service.mark_completed(s, s.get(User, ou["id"]), d["id"], None)
            outcomes.append("won")
        except ConflictError as exc:
            outcomes.append(exc.code)
        except Exception as exc:                       # any other error type is a bug
            outcomes.append(type(exc).__name__)
        finally:
            s.close()

    threads = [threading.Thread(target=go) for _ in range(2)]
    [t.start() for t in threads]; [t.join() for t in threads]
    assert sorted(outcomes)[1] == "won" and sorted(outcomes)[0] in ("concurrent_update", "invalid_transition"), outcomes
    with session_factory() as s:
        assert len(s.scalars(select(ImpactRecord)).all()) == 1


def test_edit_cannot_be_applied_after_an_organization_accepted(client, session_factory):
    dt, _ = register_donor(client)
    ot, _ = verified_org(client, session_factory)
    d = create_donation(client, dt, estimated_meals=100, quantity=100)
    s = session_factory()
    try:
        stale = donation_service.get_donation_or_404(s, d["id"])           # the editor loaded it while still open
        assert accept(client, ot, d["id"]).status_code == 200              # ...then the organization accepted
        donor = s.scalar(select(User).where(User.email == "donor@test.dev"))
        original = donation_service.get_donation_or_404
        donation_service.get_donation_or_404 = lambda db, i: stale          # editor still sees the old status
        try:
            with pytest.raises(ConflictError) as err:
                donation_service.update_donation(s, donor, d["id"], DonationUpdate(estimated_meals=1))
            assert err.value.code == "concurrent_update"
        finally:
            donation_service.get_donation_or_404 = original
    finally:
        s.close()
    with session_factory() as check:
        row = check.get(Donation, d["id"])
        assert row.status == "ACCEPTED" and row.estimated_meals == 100     # terms the organization agreed to


def test_capacity_is_rechecked_inside_the_accept_transaction(client, session_factory, monkeypatch):
    """Two donations accepted at the same moment both pass the pre-check on a stale snapshot; the in-transaction
    re-check must still stop the second one."""
    dt, _ = register_donor(client)
    ot, ou = verified_org(client, session_factory, max_capacity_meals=150)
    first = create_donation(client, dt, estimated_meals=100, quantity=100)
    second = create_donation(client, dt, estimated_meals=100, quantity=100, title="Second batch of food")
    assert accept(client, ot, first["id"]).status_code == 200

    stale_ok = scoring.MatchResult(organization_id=ou["organization"]["id"], organization_name="x", score=90.0,
                                   distance_km=1.0, eta_minutes=10, time_left_minutes=100, routing="haversine")
    monkeypatch.setattr(donation_service, "evaluate_for_org", lambda *a, **k: stale_ok)   # stale pre-check says "fits"
    resp = accept(client, ot, second["id"])
    assert resp.status_code == 409 and resp.json()["code"] == "capacity_exceeded"
    with session_factory() as s:
        assert s.get(Donation, second["id"]).status == "MATCHED"
        assert s.scalar(select(Pickup).where(Pickup.donation_id == second["id"])) is None


# ------------------------------------------------------------------ data loss / duplicates
def test_notes_from_every_stage_are_kept(client, session_factory):
    dt, _ = register_donor(client)
    ot, _ = verified_org(client, session_factory)
    d = create_donation(client, dt)
    accept(client, ot, d["id"]); schedule(client, ot, d["id"], notes="Van KA01")
    client.post(f"/api/donations/{d['id']}/collect", json={"notes": "Collected 6 crates"}, headers=auth(ot))
    done = client.post(f"/api/donations/{d['id']}/complete", json={"notes": "Served at shelter"}, headers=auth(ot))
    notes = done.json()["pickup"]["notes"]
    assert "Van KA01" in notes and "Collected 6 crates" in notes and "Served at shelter" in notes


def test_duplicate_open_report_is_refused_but_a_different_reason_is_allowed(client, session_factory):
    dt, _ = register_donor(client)
    d = create_donation(client, dt)
    body = {"donation_id": d["id"], "reason": "INCORRECT_INFORMATION", "details": "x"}
    assert client.post("/api/reports", json=body, headers=auth(dt)).status_code == 201
    dup = client.post("/api/reports", json=body, headers=auth(dt))
    assert dup.status_code == 409 and dup.json()["code"] == "duplicate_report"
    assert client.post("/api/reports", json={**body, "reason": "PICKUP_PROBLEM"}, headers=auth(dt)).status_code == 201


# ------------------------------------------------------------------ efficiency guards
def _count_statements(session_factory, fn):
    engine = session_factory.kw["bind"]
    box = []
    listener = lambda c, cur, stmt, *a: box.append(stmt)
    event.listen(engine, "before_cursor_execute", listener)
    try:
        fn()
    finally:
        event.remove(engine, "before_cursor_execute", listener)
    return len(box)


def test_organization_listing_does_not_query_once_per_donation(client, session_factory):
    dt, _ = register_donor(client)
    ot, _ = verified_org(client, session_factory)
    for i in range(25):
        create_donation(client, dt, title=f"Donation number {i}", estimated_meals=5, quantity=5)
    n = _count_statements(session_factory, lambda: client.get("/api/donations?view=available", headers=auth(ot)))
    assert n <= 12, f"{n} SQL statements for 25 donations (was ~33 before the fix)"


def test_admin_user_list_does_not_query_once_per_user(client, session_factory):
    admin = make_admin(client, session_factory)
    for i in range(30):
        register_donor(client, f"u{i}@x.dev", f"Donor {i:02d}")
    n = _count_statements(session_factory, lambda: client.get("/api/admin/users", headers=auth(admin)))
    assert n <= 8, f"{n} SQL statements for 31 users"


def test_admin_user_search_treats_wildcards_literally(client, session_factory):
    admin = make_admin(client, session_factory)
    register_donor(client, "someone@x.dev", "Some One")
    assert client.get("/api/admin/users?search=%25", headers=auth(admin)).json() == []     # a lone "%"
    assert len(client.get("/api/admin/users?search=some", headers=auth(admin)).json()) == 1


# ------------------------------------------------------------------ matching through the real API
def test_matching_end_to_end_ranks_and_excludes_with_reasons(client, session_factory):
    """One donation, five organizations: near, far-but-in-range, wrong diet, wrong category, too small."""
    dt, du = register_donor(client)
    verified_org(client, session_factory, "near@o.dev", name="Near Kitchen", latitude=12.9400, longitude=77.6250)
    verified_org(client, session_factory, "mid@o.dev", name="Mid Kitchen", latitude=13.0100, longitude=77.6800)
    verified_org(client, session_factory, "nonveg@o.dev", name="Non Veg Only", food_preferences="NON_VEG_ONLY")
    verified_org(client, session_factory, "bakery@o.dev", name="Bakery Only", preferred_categories=["BAKERY"])
    verified_org(client, session_factory, "tiny@o.dev", name="Tiny Home", max_capacity_meals=20)
    d = create_donation(client, dt)                       # 100 vegetarian cooked meals at 12.9352, 77.6245
    res = client.get(f"/api/donations/{d['id']}/matches", headers=auth(dt)).json()

    ranked = [m["organization"]["name"] for m in res["matches"]]
    assert ranked == ["Near Kitchen", "Mid Kitchen"]                         # nearer scores higher
    assert res["matches"][0]["score"] > res["matches"][1]["score"]
    assert all(0 <= m["score"] <= 100 for m in res["matches"])
    assert [m["rank"] for m in res["matches"]] == [1, 2]
    reasons = {e["organization_name"]: e["code"] for e in res["excluded"]}
    assert reasons == {"Non Veg Only": "DIET_MISMATCH", "Bakery Only": "CATEGORY_UNSUPPORTED",
                       "Tiny Home": "INSUFFICIENT_CAPACITY"}
    pts = res["matches"][0]["score_breakdown"]
    assert abs(sum(f["points"] for f in pts["factors"].values()) - pts["total"]) < 0.2   # explanation adds up


def test_expired_donations_are_excluded_everywhere(client, session_factory):
    dt, _ = register_donor(client)
    ot, _ = verified_org(client, session_factory)
    d = create_donation(client, dt)
    make_overdue(session_factory, d["id"])
    assert client.get("/api/donations?view=available", headers=auth(ot)).json() == []
    assert client.get("/api/donations?view=recommended", headers=auth(ot)).json() == []
    assert accept(client, ot, d["id"]).status_code == 409
    assert client.get(f"/api/donations/{d['id']}/matches", headers=auth(dt)).json()["status"] == "EXPIRED"
