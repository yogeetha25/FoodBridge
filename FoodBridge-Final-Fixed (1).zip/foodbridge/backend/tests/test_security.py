"""Security regressions: secrets, JWT, brute-force throttling, input trimming, error shape."""
from datetime import datetime, timedelta, timezone

import jwt
import pytest
from fastapi.testclient import TestClient

from app import config
from app.auth.throttle import LoginThrottle, TooManyAttemptsError
from app.config import settings
from tests.helpers import PASSWORD, auth, donation_payload, org_details, register_donor


# ------------------------------------------------------------------ secret key / JWT
def test_placeholder_and_short_secrets_are_weak():
    assert config.is_weak_secret("")
    assert config.is_weak_secret("short")
    assert config.is_weak_secret("change-me-to-a-long-random-string")      # the text in .env.example
    assert config.is_weak_secret("dev-only-insecure-key-change-me")        # the old hardcoded default
    assert not config.is_weak_secret("k9" * 20)


def test_production_refuses_to_start_with_a_weak_secret(monkeypatch):
    monkeypatch.setenv("SECRET_KEY", "change-me-to-a-long-random-string")
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        config._resolve_secret_key("production")


def test_running_key_is_not_the_old_public_default():
    assert settings.SECRET_KEY != "dev-only-insecure-key-change-me"
    assert not config.is_weak_secret(settings.SECRET_KEY)


def _token(user_id, key, **extra):
    payload = {"sub": str(user_id), "role": "DONOR", "exp": datetime.now(timezone.utc) + timedelta(hours=1), **extra}
    return jwt.encode(payload, key, algorithm="HS256")


def test_token_forged_with_the_old_default_key_is_rejected(client):
    _, user = register_donor(client)
    forged = _token(user["id"], "dev-only-insecure-key-change-me")
    assert client.get("/api/auth/me", headers=auth(forged)).status_code == 401


def test_token_without_expiry_is_rejected(client):
    _, user = register_donor(client)
    no_exp = jwt.encode({"sub": str(user["id"])}, settings.SECRET_KEY, algorithm="HS256")
    assert client.get("/api/auth/me", headers=auth(no_exp)).status_code == 401


def test_unsigned_none_algorithm_token_is_rejected(client):
    _, user = register_donor(client)
    unsigned = jwt.encode({"sub": str(user["id"]), "exp": datetime.now(timezone.utc) + timedelta(hours=1)},
                          key=None, algorithm="none")
    assert client.get("/api/auth/me", headers=auth(unsigned)).status_code == 401


def test_expired_token_is_rejected_with_a_clear_code(client):
    _, user = register_donor(client)
    old = _token(user["id"], settings.SECRET_KEY, exp=datetime.now(timezone.utc) - timedelta(minutes=1))
    resp = client.get("/api/auth/me", headers=auth(old))
    assert resp.status_code == 401 and resp.json()["code"] == "token_expired"


# ------------------------------------------------------------------ brute force
def test_login_is_throttled_after_repeated_failures(client):
    register_donor(client)
    bad = {"email": "donor@test.dev", "password": "wrong-pass-1"}
    for _ in range(settings.LOGIN_MAX_ATTEMPTS):
        assert client.post("/api/auth/login", json=bad).status_code == 401
    blocked = client.post("/api/auth/login", json=bad)
    assert blocked.status_code == 429 and blocked.json()["code"] == "too_many_attempts"
    # even the CORRECT password is refused while locked out
    assert client.post("/api/auth/login", json={"email": "donor@test.dev", "password": PASSWORD}).status_code == 429


def test_throttle_is_per_email_and_a_success_resets_it(client):
    register_donor(client)
    register_donor(client, "other@test.dev", "Other Donor")
    for _ in range(settings.LOGIN_MAX_ATTEMPTS - 1):
        client.post("/api/auth/login", json={"email": "donor@test.dev", "password": "wrong-pass-1"})
    # a different account is unaffected
    assert client.post("/api/auth/login", json={"email": "other@test.dev", "password": PASSWORD}).status_code == 200
    # a success clears the counter for this account
    assert client.post("/api/auth/login", json={"email": "donor@test.dev", "password": PASSWORD}).status_code == 200
    for _ in range(settings.LOGIN_MAX_ATTEMPTS):
        assert client.post("/api/auth/login", json={"email": "donor@test.dev", "password": "wrong-pass-1"}).status_code == 401


def test_throttle_window_expires():
    now = [1000.0]
    t = LoginThrottle(clock=lambda: now[0])
    for _ in range(settings.LOGIN_MAX_ATTEMPTS):
        t.record_failure("1.2.3.4", "a@b.c")
    with pytest.raises(TooManyAttemptsError):
        t.check("1.2.3.4", "a@b.c")
    now[0] += settings.LOGIN_WINDOW_SECONDS + 1
    t.check("1.2.3.4", "a@b.c")          # no longer blocked


# ------------------------------------------------------------------ whitespace-only input
def test_whitespace_only_names_are_rejected_at_registration(client):
    r = client.post("/api/auth/register", json={"email": "ws@x.dev", "password": PASSWORD, "full_name": "   ",
                                                "role": "DONOR", "donor_type": "HOTEL"})
    assert r.status_code == 422
    r = client.post("/api/auth/register", json={
        "email": "ws2@x.dev", "password": PASSWORD, "full_name": "Okay Name", "role": "ORGANIZATION",
        "organization": org_details(name="   ", contact_person="  ", address="      ", phone="     ")})
    assert r.status_code == 422
    fields = {e["field"] for e in r.json()["errors"]}
    assert {"organization.name", "organization.contact_person", "organization.address", "organization.phone"} <= fields


def test_surrounding_whitespace_is_trimmed_and_length_rechecked(client):
    r = client.post("/api/auth/register", json={"email": "t@x.dev", "password": PASSWORD, "full_name": "  Asha  ",
                                                "role": "DONOR", "donor_type": "HOTEL"})
    assert r.status_code == 201 and r.json()["user"]["full_name"] == "Asha"
    r = client.post("/api/auth/register", json={"email": "t2@x.dev", "password": PASSWORD, "full_name": " a ",
                                                "role": "DONOR", "donor_type": "HOTEL"})
    assert r.status_code == 422          # one real character after trimming


def test_profile_update_rejects_blank_name_and_clears_blank_phone(client):
    token, _ = register_donor(client)
    assert client.patch("/api/auth/me", json={"full_name": "    "}, headers=auth(token)).status_code == 422
    ok = client.patch("/api/auth/me", json={"phone": "   "}, headers=auth(token))
    assert ok.status_code == 200 and ok.json()["phone"] is None


def test_donation_create_and_update_reject_blank_required_text(client):
    token, _ = register_donor(client)
    assert client.post("/api/donations", json=donation_payload(title="  ab  "), headers=auth(token)).status_code == 422
    assert client.post("/api/donations", json=donation_payload(pickup_address="      "), headers=auth(token)).status_code == 422
    d = client.post("/api/donations", json=donation_payload(), headers=auth(token)).json()
    for field in ("title", "pickup_address", "contact_info"):
        r = client.patch(f"/api/donations/{d['id']}", json={field: "       "}, headers=auth(token))
        assert r.status_code == 422, field


def test_organization_update_rejects_blank_values(client, session_factory):
    from tests.helpers import verified_org
    token, user = verified_org(client, session_factory)
    r = client.patch(f"/api/organizations/{user['organization']['id']}", json={"name": "     "}, headers=auth(token))
    assert r.status_code == 422


# ------------------------------------------------------------------ uniform errors / health
def test_unknown_route_and_wrong_method_use_the_standard_error_shape(client):
    r = client.get("/api/no-such-thing")
    assert r.status_code == 404 and r.json()["code"] == "not_found" and r.json()["detail"]
    r = client.delete("/api/health")
    assert r.status_code == 405 and r.json()["code"] == "method_not_allowed"


def test_health_checks_the_database(client):
    r = TestClient(client.app).get("/api/health")
    assert r.status_code == 200 and r.json()["database"] == "ok"
