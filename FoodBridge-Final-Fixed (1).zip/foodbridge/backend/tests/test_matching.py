"""Tests for the pure matching engine. No database needed."""
from dataclasses import replace
from datetime import datetime, timedelta

import pytest

from app.matching.config import MatchWeights
from app.matching.scoring import (CANNOT_ARRIVE_IN_TIME, CATEGORY_UNSUPPORTED, DIET_MISMATCH,
                                  INACTIVE, INSUFFICIENT_CAPACITY, NOT_VERIFIED, OUT_OF_RANGE,
                                  DonationInfo, Exclusion, MatchResult, OrganizationInfo,
                                  capacity_score, distance_score, evaluate_organization,
                                  rank_organizations, urgency_score)

# 06:30 UTC = 12:00 noon in IST, so "09:00-18:00" organizations are open.
NOW = datetime(2026, 3, 10, 6, 30)

DONATION = DonationInfo(id=1, category="COOKED_MEALS", is_vegetarian=True, estimated_meals=100,
                        latitude=12.9352, longitude=77.6245,
                        available_until=NOW + timedelta(hours=3))


def make_org(**overrides) -> OrganizationInfo:
    base = dict(id=1, name="Test NGO", is_verified=True, is_active=True,
                latitude=12.9352, longitude=77.6245,          # same spot as the donor
                service_radius_km=15, max_capacity_meals=300, current_load_meals=0,
                preferred_categories=("COOKED_MEALS",), food_preferences="BOTH",
                operating_hours="09:00-18:00")
    base.update(overrides)
    return OrganizationInfo(**base)


def eval_(org, donation=DONATION, **kw):
    return evaluate_organization(donation, org, NOW, **kw)


# ---------------------------------------------------------------- weights
def test_default_weights_sum_to_one():
    from app.matching.config import DEFAULT_WEIGHTS
    assert sum(DEFAULT_WEIGHTS.as_dict().values()) == pytest.approx(1.0)


def test_invalid_weights_are_rejected():
    with pytest.raises(ValueError):
        MatchWeights(distance=0.5, capacity=0.5, urgency=0.5, food=0.5, availability=0.5)


# ---------------------------------------------------------------- 1. near vs far
def test_nearby_organization_scores_higher_than_distant_one():
    near = eval_(make_org(id=1, latitude=12.9400, longitude=77.6300))   # ~0.8 km
    far = eval_(make_org(id=2, latitude=13.0300, longitude=77.7000))    # ~13 km
    assert isinstance(near, MatchResult) and isinstance(far, MatchResult)
    assert near.score > far.score
    assert near.factors["distance"]["score"] > far.factors["distance"]["score"]


def test_organization_outside_service_radius_is_excluded():
    result = eval_(make_org(latitude=13.2, longitude=77.9, service_radius_km=5))
    assert isinstance(result, Exclusion) and result.code == OUT_OF_RANGE


def test_distance_score_formula():
    assert distance_score(0, 10) == 1.0
    assert distance_score(5, 10) == pytest.approx(0.5)
    assert distance_score(12, 10) == 0.0   # clamped, never negative


# ---------------------------------------------------------------- 2. capacity
def test_insufficient_capacity_is_excluded():
    result = eval_(make_org(max_capacity_meals=80))
    assert isinstance(result, Exclusion) and result.code == INSUFFICIENT_CAPACITY


def test_already_committed_load_reduces_capacity():
    # 300 capacity but 250 already promised -> only 50 free, 100 needed
    result = eval_(make_org(max_capacity_meals=300, current_load_meals=250))
    assert isinstance(result, Exclusion) and result.code == INSUFFICIENT_CAPACITY


def test_capacity_score_does_not_favour_huge_organizations():
    comfortable = capacity_score(100, 150)    # fill 0.67 -> 1.0
    huge = capacity_score(100, 5000)          # fill 0.02 -> low
    assert comfortable == 1.0
    assert huge < comfortable
    assert capacity_score(100, 100) == 0.9    # fits exactly but no spare room


# ---------------------------------------------------------------- 3. verification
def test_unverified_organization_is_never_matched():
    result = eval_(make_org(is_verified=False))
    assert isinstance(result, Exclusion) and result.code == NOT_VERIFIED


def test_inactive_organization_is_excluded():
    result = eval_(make_org(is_active=False))
    assert isinstance(result, Exclusion) and result.code == INACTIVE


# ---------------------------------------------------------------- 4. food compatibility
def test_veg_only_organization_rejects_non_veg_food():
    non_veg = replace(DONATION, is_vegetarian=False)
    result = eval_(make_org(food_preferences="VEG_ONLY"), donation=non_veg)
    assert isinstance(result, Exclusion) and result.code == DIET_MISMATCH


def test_non_veg_only_organization_rejects_veg_food():
    result = eval_(make_org(food_preferences="NON_VEG_ONLY"))
    assert isinstance(result, Exclusion) and result.code == DIET_MISMATCH


def test_unsupported_category_is_excluded():
    bakery = replace(DONATION, category="BAKERY")
    result = eval_(make_org(preferred_categories=("COOKED_MEALS",)), donation=bakery)
    assert isinstance(result, Exclusion) and result.code == CATEGORY_UNSUPPORTED


def test_specialist_scores_higher_food_fit_than_generalist():
    specialist = eval_(make_org(food_preferences="VEG_ONLY"))
    generalist = eval_(make_org(food_preferences="BOTH", preferred_categories=()))
    assert specialist.factors["food"]["score"] > generalist.factors["food"]["score"]


# ---------------------------------------------------------------- 5. urgency
def test_urgency_score_formula():
    assert urgency_score(120, 0) == 1.0
    assert urgency_score(120, 60) == pytest.approx(0.5)
    assert urgency_score(120, 120) == 0.0
    assert urgency_score(0, 10) == 0.0


def test_close_to_expiry_excludes_organizations_that_cannot_arrive():
    urgent = replace(DONATION, available_until=NOW + timedelta(minutes=20))
    far = make_org(latitude=13.0300, longitude=77.7000)       # ~13 km -> needs >50 min
    result = eval_(far, donation=urgent)
    assert isinstance(result, Exclusion) and result.code == CANNOT_ARRIVE_IN_TIME


def test_urgent_donation_still_matches_a_very_close_organization():
    urgent = replace(DONATION, available_until=NOW + timedelta(minutes=40))
    result = eval_(make_org(), donation=urgent)               # same location, arrives in ~15 min
    assert isinstance(result, MatchResult)
    relaxed = eval_(make_org())
    assert result.factors["urgency"]["score"] < relaxed.factors["urgency"]["score"]


def test_expired_donation_matches_nobody():
    expired = replace(DONATION, available_until=NOW - timedelta(minutes=1))
    result = eval_(make_org(), donation=expired)
    assert isinstance(result, Exclusion) and result.code == "EXPIRED"


# ---------------------------------------------------------------- availability
def test_open_organization_beats_closed_one():
    open_org = eval_(make_org(operating_hours="09:00-18:00"))
    closed_org = eval_(make_org(operating_hours="19:00-23:00"))
    assert open_org.factors["availability"]["score"] == 1.0
    assert closed_org.factors["availability"]["score"] < 1.0
    assert open_org.score > closed_org.score


# ---------------------------------------------------------------- explanation & ranking
def test_score_is_between_0_and_100_and_breakdown_adds_up():
    result = eval_(make_org())
    assert 0 <= result.score <= 100
    points = sum(f["points"] for f in result.factors.values())
    assert points == pytest.approx(result.score, abs=0.6)   # rounding of each factor


def test_breakdown_contains_human_readable_reasons():
    b = eval_(make_org()).breakdown()
    assert set(b["factors"]) == {"distance", "capacity", "urgency", "food", "availability"}
    assert len(b["reasons"]) == 5
    assert all(isinstance(r["text"], str) and r["text"] for r in b["reasons"])
    assert b["routing"] == "haversine"


def test_ranking_orders_best_first_and_lists_exclusions():
    orgs = [
        make_org(id=1, name="Near", latitude=12.9400, longitude=77.6300),
        make_org(id=2, name="Far", latitude=13.0300, longitude=77.7000),
        make_org(id=3, name="Unverified", is_verified=False),
        make_org(id=4, name="Small", max_capacity_meals=20),
    ]
    matches, exclusions = rank_organizations(DONATION, orgs, NOW)
    assert [m.organization_name for m in matches] == ["Near", "Far"]
    assert {e.organization_name: e.code for e in exclusions} == {
        "Unverified": NOT_VERIFIED, "Small": INSUFFICIENT_CAPACITY}


# ---------------------------------------------------------------- 6. nobody eligible
def test_no_eligible_organization():
    orgs = [make_org(id=1, is_verified=False), make_org(id=2, max_capacity_meals=10),
            make_org(id=3, food_preferences="NON_VEG_ONLY")]
    matches, exclusions = rank_organizations(DONATION, orgs, NOW)
    assert matches == []
    assert len(exclusions) == 3


def test_custom_weights_change_the_ranking():
    near_but_closed = make_org(id=1, operating_hours="19:00-23:00", latitude=12.9400, longitude=77.6300)
    far_but_open = make_org(id=2, latitude=12.9900, longitude=77.6700)   # ~7 km
    default_order, _ = rank_organizations(DONATION, [near_but_closed, far_but_open], NOW)
    availability_heavy = MatchWeights(distance=0.05, capacity=0.05, urgency=0.05, food=0.05, availability=0.80)
    heavy_order, _ = rank_organizations(DONATION, [near_but_closed, far_but_open], NOW, weights=availability_heavy)
    assert heavy_order[0].organization_id == 2
    assert default_order[0].organization_id == 1


def test_custom_travel_estimator_is_used():
    fake = lambda donation, org: (1.0, 5.0, "osrm")
    result = eval_(make_org(latitude=13.5, longitude=78.0), travel=fake)  # truly far, but "road" says 1 km
    assert isinstance(result, MatchResult) and result.routing == "osrm"
