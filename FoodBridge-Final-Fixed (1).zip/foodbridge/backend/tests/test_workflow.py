"""End-to-end donation lifecycle, status transitions, acceptance rules and concurrency."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import pytest

from app.errors import ConflictError
from app.models import Donation, User
from app.services import donation_service
from app.services.expiry import expire_overdue
from tests.helpers import (auth, create_donation, iso, register_donor, register_org, verified_org)


def accept(client, token, donation_id):
    return client.post(f"/api/donations/{donation_id}/accept", headers=auth(token))


def schedule(client, token, donation_id, minutes=30):
    when = iso(datetime.now(timezone.utc) + timedelta(minutes=minutes))
    return client.post(f"/api/donations/{donation_id}/pickup", json={"scheduled_at": when, "notes": "Van KA01"},
                       headers=auth(token))


def test_full_lifecycle_updates_impact(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token, estimated_meals=120, quantity=120)
    assert d["status"] == "MATCHED"

    acc = accept(client, org_token, d["id"])
    assert acc.status_code == 200 and acc.json()["status"] == "ACCEPTED" and acc.json()["accepted_by"]

    sch = schedule(client, org_token, d["id"])
    assert sch.status_code == 200 and sch.json()["status"] == "PICKUP_PENDING"

    col = client.post(f"/api/donations/{d['id']}/collect", headers=auth(org_token))
    assert col.status_code == 200 and col.json()["status"] == "COLLECTED"

    done = client.post(f"/api/donations/{d['id']}/complete", json={"notes": "Served at the shelter"},
                       headers=auth(org_token))
    assert done.status_code == 200 and done.json()["status"] == "COMPLETED"
    assert done.json()["impact"]["meals_redistributed"] == 120

    platform = client.get("/api/impact").json()
    assert platform["totals"]["completed_donations"] == 1
    assert platform["totals"]["meals_redistributed"] == 120
    assert platform["totals"]["verified_organizations"] == 1
    assert platform["is_estimate"] is True and platform["assumptions"]
    assert client.get("/api/impact/donor", headers=auth(donor_token)).json()["totals"]["meals_redistributed"] == 120
    assert client.get("/api/impact/organization", headers=auth(org_token)).json()["totals"]["completed_donations"] == 1


def test_invalid_transitions_are_rejected(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    # cannot collect or complete before accepting
    assert client.post(f"/api/donations/{d['id']}/collect", headers=auth(org_token)).status_code == 403  # not its donation yet
    accept(client, org_token, d["id"])
    # ACCEPTED -> COLLECTED is not allowed (must schedule pickup first)
    resp = client.post(f"/api/donations/{d['id']}/collect", headers=auth(org_token))
    assert resp.status_code == 409 and resp.json()["code"] == "invalid_transition"
    # ACCEPTED -> COMPLETED is not allowed either
    assert client.post(f"/api/donations/{d['id']}/complete", headers=auth(org_token)).status_code == 409


def test_donor_cannot_cancel_after_pickup_is_pending(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    accept(client, org_token, d["id"])
    schedule(client, org_token, d["id"])
    resp = client.post(f"/api/donations/{d['id']}/cancel", headers=auth(donor_token))
    assert resp.status_code == 409 and resp.json()["code"] == "pickup_started"


def test_donor_can_cancel_after_acceptance_before_pickup(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    accept(client, org_token, d["id"])
    assert client.post(f"/api/donations/{d['id']}/cancel", headers=auth(donor_token)).json()["status"] == "CANCELLED"


def test_second_organization_cannot_accept_an_already_accepted_donation(client, session_factory):
    donor_token, _ = register_donor(client)
    token_a, _ = verified_org(client, session_factory, "a@ngo.dev", name="Org A")
    token_b, _ = verified_org(client, session_factory, "b@ngo.dev", name="Org B")
    d = create_donation(client, donor_token)
    assert accept(client, token_a, d["id"]).status_code == 200
    lost = accept(client, token_b, d["id"])
    assert lost.status_code == 409 and lost.json()["code"] == "already_accepted"


def test_only_the_accepting_organization_can_continue_the_workflow(client, session_factory):
    donor_token, _ = register_donor(client)
    token_a, _ = verified_org(client, session_factory, "a@ngo.dev", name="Org A")
    token_b, _ = verified_org(client, session_factory, "b@ngo.dev", name="Org B")
    d = create_donation(client, donor_token)
    accept(client, token_a, d["id"])
    assert schedule(client, token_b, d["id"]).status_code == 403


def test_organization_without_enough_capacity_cannot_accept(client, session_factory):
    donor_token, _ = register_donor(client)
    small_token, _ = verified_org(client, session_factory, max_capacity_meals=50)
    d = create_donation(client, donor_token, estimated_meals=100)
    resp = accept(client, small_token, d["id"])
    assert resp.status_code == 409 and resp.json()["code"] == "capacity_exceeded"


def test_capacity_accounts_for_meals_already_committed(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory, max_capacity_meals=150)
    first = create_donation(client, donor_token, title="First batch", estimated_meals=100)
    second = create_donation(client, donor_token, title="Second batch", estimated_meals=100)
    assert accept(client, org_token, first["id"]).status_code == 200
    resp = accept(client, org_token, second["id"])      # only 50 meals of capacity left
    assert resp.status_code == 409 and resp.json()["code"] == "capacity_exceeded"


def test_expired_donation_cannot_be_accepted(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    with session_factory() as s:
        s.get(Donation, d["id"]).available_until = datetime.utcnow() - timedelta(minutes=1)
        s.commit()
    resp = accept(client, org_token, d["id"])
    assert resp.status_code == 409 and resp.json()["code"] == "donation_expired"


def test_pickup_must_be_before_expiry(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    accept(client, org_token, d["id"])
    resp = schedule(client, org_token, d["id"], minutes=60 * 10)   # donation expires in 3 hours
    assert resp.status_code == 422


def test_organization_lists_reflect_its_workflow(client, session_factory):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    d = create_donation(client, donor_token)
    assert [x["id"] for x in client.get("/api/donations?view=recommended", headers=auth(org_token)).json()] == [d["id"]]
    assert client.get("/api/donations?view=recommended", headers=auth(org_token)).json()[0]["my_match"]["score"] > 0
    accept(client, org_token, d["id"])
    assert client.get("/api/donations?view=available", headers=auth(org_token)).json() == []
    assert len(client.get("/api/donations?view=accepted", headers=auth(org_token)).json()) == 1
    schedule(client, org_token, d["id"])
    assert len(client.get("/api/donations?view=pickups", headers=auth(org_token)).json()) == 1


# ---------------------------------------------------------------- expiry service
def test_expire_overdue_only_touches_expirable_statuses(client, session_factory, db):
    donor_token, _ = register_donor(client)
    org_token, _ = verified_org(client, session_factory)
    open_one = create_donation(client, donor_token, title="Open one")
    scheduled = create_donation(client, donor_token, title="Scheduled one")
    accept(client, org_token, scheduled["id"])
    schedule(client, org_token, scheduled["id"])
    with session_factory() as s:
        for did in (open_one["id"], scheduled["id"]):
            s.get(Donation, did).available_until = datetime.utcnow() - timedelta(minutes=1)
        s.commit()
    assert expire_overdue(db) == 1
    db.expire_all()
    assert db.get(Donation, open_one["id"]).status == "EXPIRED"
    assert db.get(Donation, scheduled["id"]).status == "PICKUP_PENDING"   # PICKUP_PENDING never auto-expires


# ---------------------------------------------------------------- concurrency
def test_atomic_claim_rejects_a_stale_second_acceptance(client, session_factory, monkeypatch):
    """Both organizations have already read the donation as MATCHED. Only the atomic UPDATE
    inside accept_donation() stops the second one."""
    donor_token, _ = register_donor(client)
    _, user_a = verified_org(client, session_factory, "a@ngo.dev", name="Org A")
    _, user_b = verified_org(client, session_factory, "b@ngo.dev", name="Org B")
    d = create_donation(client, donor_token)

    session_a, session_b = session_factory(), session_factory()
    try:
        stale_copy = donation_service.get_donation_or_404(session_b, d["id"])     # B read it first
        assert stale_copy.status == "MATCHED"
        donation_service.accept_donation(session_a, session_a.get(User, user_a["id"]), d["id"])   # A wins

        monkeypatch.setattr(donation_service, "get_donation_or_404", lambda db, i: stale_copy)    # B still sees "MATCHED"
        with pytest.raises(ConflictError) as err:
            donation_service.accept_donation(session_b, session_b.get(User, user_b["id"]), d["id"])
        assert err.value.code == "already_accepted"
    finally:
        session_a.close()
        session_b.close()

    with session_factory() as s:
        assert s.get(Donation, d["id"]).pickup.organization.name == "Org A"


def test_two_simultaneous_acceptances_produce_exactly_one_winner(client, session_factory):
    donor_token, _ = register_donor(client)
    _, user_a = verified_org(client, session_factory, "a@ngo.dev", name="Org A")
    _, user_b = verified_org(client, session_factory, "b@ngo.dev", name="Org B")
    d = create_donation(client, donor_token)

    def attempt(user_id):
        session = session_factory()
        try:
            donation_service.accept_donation(session, session.get(User, user_id), d["id"])
            return "won"
        except ConflictError as exc:
            return exc.code
        finally:
            session.close()

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(attempt, [user_a["id"], user_b["id"]]))
    assert sorted(results) == ["already_accepted", "won"]
    with session_factory() as s:
        assert s.get(Donation, d["id"]).status == "ACCEPTED"
