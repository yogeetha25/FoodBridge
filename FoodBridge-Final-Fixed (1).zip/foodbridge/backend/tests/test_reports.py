from tests.helpers import auth, create_donation, make_admin, register_donor, verified_org


def test_donor_can_report_and_admin_can_resolve(client, session_factory):
    donor_token, _ = register_donor(client)
    admin_token = make_admin(client, session_factory)
    d = create_donation(client, donor_token)
    created = client.post("/api/reports", json={"donation_id": d["id"], "reason": "INCORRECT_QUANTITY",
                                                "details": "Less food than listed"}, headers=auth(donor_token))
    assert created.status_code == 201 and created.json()["status"] == "OPEN"
    rid = created.json()["id"]

    assert len(client.get("/api/reports", headers=auth(admin_token)).json()) == 1
    assert len(client.get("/api/reports", headers=auth(donor_token)).json()) == 1

    resolved = client.patch(f"/api/reports/{rid}", json={"status": "RESOLVED", "resolution_notes": "Checked with NGO"},
                            headers=auth(admin_token))
    assert resolved.status_code == 200 and resolved.json()["status"] == "RESOLVED"
    assert resolved.json()["resolved_by"] is not None


def test_cannot_report_a_donation_you_are_not_involved_in(client, session_factory):
    donor_token, _ = register_donor(client)
    other_token, _ = register_donor(client, "other@test.dev", "Other")
    d = create_donation(client, donor_token)
    resp = client.post("/api/reports", json={"donation_id": d["id"], "reason": "PICKUP_PROBLEM"}, headers=auth(other_token))
    assert resp.status_code == 403


def test_non_admin_cannot_update_reports(client):
    donor_token, _ = register_donor(client)
    d = create_donation(client, donor_token)
    rid = client.post("/api/reports", json={"donation_id": d["id"], "reason": "PICKUP_PROBLEM"},
                      headers=auth(donor_token)).json()["id"]
    assert client.patch(f"/api/reports/{rid}", json={"status": "RESOLVED"}, headers=auth(donor_token)).status_code == 403


def test_reason_other_requires_details(client):
    donor_token, _ = register_donor(client)
    d = create_donation(client, donor_token)
    resp = client.post("/api/reports", json={"donation_id": d["id"], "reason": "OTHER"}, headers=auth(donor_token))
    assert resp.status_code == 422
