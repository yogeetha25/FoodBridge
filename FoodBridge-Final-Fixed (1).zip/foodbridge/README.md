# FoodBridge

> Connecting surplus food with people who need it.

FoodBridge is a full-stack web application that redistributes surplus edible food from donors (restaurants, hotels,
caterers, college events) to **verified** NGOs and community kitchens. A donor posts food; a transparent, rule-based
algorithm finds and ranks suitable organizations and **explains every score**; an organization accepts; and the donation
moves through a strict status lifecycle to completion, feeding an impact dashboard.

**FoodBridge facilitates redistribution. It does not inspect food, guarantee food safety, or guarantee that a donation
will be collected.** Donors are responsible for accurate information and for following local food-safety rules.

---------------------------------------------------------------------------------------------------

## Problem statement

Restaurants, hotels, caterers and events regularly have edible leftovers, while organizations serving people in need
look for food. Prepared food is perishable, so the window is a few hours, and donors rarely know which nearby
organization can take that quantity and kind of food in time. The gap is **coordination**.

## Proposed solution

A web platform that (1) lets donors post surplus food with validated details, (2) filters and scores verified
organizations by distance, capacity, time feasibility, food compatibility and availability, (3) shows *why* each
organization ranked where it did, (4) enforces a strict donation lifecycle, and (5) records impact as clearly-labelled
estimates.

## Features

| Area | What works |
|---|---|
| Accounts | Register / login (JWT, bcrypt, brute-force throttling), 3 roles: Donor, Organization, Admin, role-based authorization, ownership checks |
| Donor | Dashboard, create donation (server-validated), my donations, **edit a donation until an organization accepts it (matches are recalculated)**, donation detail with map, ranked organizations with explanations, cancel (before pickup), report a problem, personal impact |
| Organization | Profile (location on map, capacity, radius, categories, diet, hours), recommended and nearby donations, accept (first valid acceptance wins), schedule pickup, mark collected, mark completed, history, impact |
| Admin | Dashboard stats, users (deactivate), organization verification (verify / reject), all donations, reports (status + resolution notes), platform analytics |
| Matching | Hard eligibility filters + weighted 0-100 score + human-readable reasons, weights configurable |
| Status machine | 8 states, illegal transitions rejected with HTTP 409; every change is an atomic compare-and-set, so simultaneous requests cannot corrupt a donation |
| Expiry | Overdue donations become EXPIRED automatically (background task + on every read) |
| Impact | Totals and weekly/monthly trends with Recharts; all figures are **estimates** with listed assumptions |
| Maps | Leaflet + OpenStreetMap; Haversine distance; optional OSRM road routing with automatic fallback |

## Architecture

```
React + TypeScript + Tailwind (browser)  --JSON/REST + JWT-->  FastAPI backend  -->  SQLite (SQLAlchemy)
                                                                  |
          app/api        thin HTTP routes (validation, auth dependencies)
          app/services   business logic (donation workflow, impact, expiry, auth)
          app/matching   scoring.py = PURE functions (no DB); engine.py = DB glue
          app/models     SQLAlchemy tables      app/schemas   Pydantic validation
```

## Tech stack

Frontend: React 18, TypeScript, Vite, Tailwind CSS 3, React Router 6, Recharts, Leaflet + React-Leaflet, lucide-react icons.
Backend: Python 3.10+, FastAPI, Pydantic v2, SQLAlchemy 2, SQLite, bcrypt, PyJWT. Tests: pytest.

## Folder structure

```
foodbridge/
├── backend/
│   ├── app/
│   │   ├── main.py  config.py  constants.py  errors.py
│   │   ├── api/          auth, donations, organizations, reports, admin, impact, serializers
│   │   ├── auth/         security.py (bcrypt, JWT), dependencies.py (roles)
│   │   ├── database/     session.py
│   │   ├── matching/     config.py (weights), scoring.py (pure), engine.py
│   │   ├── models/       entities.py
│   │   ├── schemas/      Pydantic request/response models
│   │   ├── services/     donation_service, auth_service, organization_service, report_service,
│   │   │                 impact_service, impact_calc (pure), status_machine (pure), transitions (atomic), expiry
│   │   └── utils/        geo.py, hours.py, routing.py (OSRM), time.py
│   ├── tests/            131 tests   (frontend: 28 Vitest tests in frontend/src/**/*.test.ts[x])
│   ├── seed.py  requirements.txt  pytest.ini
├── frontend/src/         components/ pages/ layouts/ services/ hooks/ types/ utils/
├── docs/                 college documentation
├── .env.example  .gitignore  README.md
```

## Database overview

Seven tables: `users`, `organizations` (1:1 with an organization user), `donations`, `matches` (stored ranking with a JSON
`score_breakdown`), `pickups` (unique per donation), `impact_records` (unique per donation), `reports`.
Foreign keys are enforced (SQLite `PRAGMA foreign_keys=ON`). See `docs/database-design.md` for the ER diagram.

## Matching algorithm (summary)

1. **Hard filters**: organization verified and active; donation not expired; diet accepted; category accepted; enough free
   capacity (capacity minus meals already committed); inside the organization's service radius; able to arrive before expiry.
2. **Score** = 100 x (0.30 distance + 0.20 capacity fit + 0.25 time feasibility + 0.15 food fit + 0.10 availability),
   each factor between 0 and 1. Weights live in `backend/app/matching/config.py` (or env variables) and must sum to 1.
3. **Explanation**: every factor returns a number and a sentence, stored in `matches.score_breakdown`.

Full detail and worked examples: `docs/matching-algorithm.md`.

---------------------------------------------------------------------------------------------------

## Installation

Prerequisites: **Python 3.10+** and **Node.js 18+** (check with `python --version` and `node --version`).
On Windows use `python`; on macOS/Linux use `python3`. Commands below show both where they differ.

### 1. Backend

```bash
cd backend

# create and activate a virtual environment
python3 -m venv .venv            # Windows: python -m venv .venv
source .venv/bin/activate        # Windows (PowerShell): .venv\Scripts\Activate.ps1   (cmd: .venv\Scripts\activate.bat)

pip install -r requirements.txt

# configuration (recommended)
cp .env.example .env             # Windows: copy .env.example .env
# then edit .env and set SECRET_KEY to a long random string (32+ characters):
python -c "import secrets; print(secrets.token_urlsafe(48))"
# (If you skip this, a random development key is generated into backend/.dev_secret_key. That is fine for a local
#  demo, but set your own SECRET_KEY for anything else. With ENVIRONMENT=production the app refuses to start without one.)

# create the database tables and demo data
python seed.py                   # asks for confirmation if the database already has data; add --yes to skip

# run the API on http://localhost:8000
uvicorn app.main:app --reload
```

Interactive API docs (Swagger): <http://localhost:8000/docs>. Health check: <http://localhost:8000/api/health>.

The database file is created automatically at `backend/foodbridge.db`. Tables are also created on server start, so
`python seed.py` is only needed for demo data. **`python seed.py` deletes all existing data** (it asks first; `--yes` skips the question).

### 2. Frontend (new terminal)

```bash
cd frontend
npm install
npm run dev
```

Open <http://localhost:5173>. The dev server proxies `/api` to `http://localhost:8000`, so no CORS setup is needed.
Production build: `npm run build` (type-checks, then bundles to `frontend/dist`). To try the production build locally
(also proxies `/api`): `npm run build && npm run preview`, then open <http://localhost:4173>.
`frontend/.env.example` documents the one optional frontend variable (`VITE_API_URL`).

### Environment variables (`backend/.env`)

| Variable | Default | Purpose |
|---|---|---|
| `SECRET_KEY` | generated dev key | Signs JWTs. **Set your own** (32+ chars). A missing/placeholder value is replaced by a random key saved in `backend/.dev_secret_key`; in production the app refuses to start. |
| `ENVIRONMENT` | `development` | `production` enforces a strong `SECRET_KEY` and explicit CORS origins |
| `DATABASE_URL` | `sqlite:///<backend folder>/foodbridge.db` | Database location |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | 480 | Login session length |
| `CORS_ORIGINS` | `http://localhost:5173,...` | Allowed browser origins (explicit list; never `*`) |
| `LOGIN_MAX_ATTEMPTS` / `LOGIN_WINDOW_SECONDS` | 5 / 900 | After this many wrong passwords for the same IP + email, login returns HTTP 429 until the window passes |
| `USE_OSRM` | `false` | Use OSRM road distance (falls back to Haversine on failure) |
| `LOCAL_UTC_OFFSET_MINUTES` | 330 | Timezone used for organizations' operating hours (330 = IST) |
| `MATCH_WEIGHT_*` | 0.30 / 0.20 / 0.25 / 0.15 / 0.10 | Matching weights (must sum to 1) |

## Demo accounts (created by `python seed.py`)

| Role | Email | Password |
|---|---|---|
| Admin | `admin@foodbridge.demo` | `Admin@FoodBridge1` |
| Donor: Green Leaf Restaurant | `restaurant@foodbridge.demo` | `Donor@FoodBridge1` |
| Donor: ABC College | `college@foodbridge.demo` | `Donor@FoodBridge1` |
| Donor: Lakeview Hotel | `hotel@foodbridge.demo` | `Donor@FoodBridge1` |
| NGO: Annapurna Community Kitchen (verified) | `ngo1@foodbridge.demo` | `Ngo@FoodBridge1` |
| NGO: Hope Shelter Home (verified, vegetarian only) | `ngo2@foodbridge.demo` | `Ngo@FoodBridge1` |
| NGO: Seva Food Bank (verified, large) | `ngo3@foodbridge.demo` | `Ngo@FoodBridge1` |
| NGO: Little Hands Children's Home (verified, small capacity) | `ngo4@foodbridge.demo` | `Ngo@FoodBridge1` |
| NGO: New Dawn Trust (**unverified**) | `ngo5@foodbridge.demo` | `Ngo@FoodBridge1` |

These are demo-only credentials for local use. On the development login page there are buttons that fill them in.

**Re-run `python seed.py` before each demo**: all times are relative to "now", so donations that were open earlier will
have expired by the next day.

### Suggested demo flow (about 5 minutes)

1. Sign in as `college@foodbridge.demo`. Open **Annual fest: vegetarian meals** (120 meals). Show the three ranked
   organizations (about 93%, 75% and 59% at midday), expand "How this score was calculated", and the "not eligible" list
   (Little Hands: not enough capacity). Unverified organizations are never shown to donors.
2. Sign in as `restaurant@foodbridge.demo`. Open **Chicken biryani** (45 portions, under an hour left): Hope Shelter is
   excluded (vegetarian only), Seva Food Bank cannot arrive in time. Urgency matters.
3. Sign in as `ngo1@foodbridge.demo` > **Recommended** > open the college donation > **Accept**.
4. Same organization: **Schedule pickup**, **Mark as collected**, **Mark distribution completed**.
5. Sign in as `ngo2@foodbridge.demo` and try to accept the same donation: it is refused (first valid acceptance wins).
6. Sign in as `ngo5@foodbridge.demo` (unverified): no matches or acceptance. Then as admin: **Verification** > verify it.
7. As admin: **Reports** (resolve one) and **Impact analytics**.

## Testing

```bash
# backend (131 tests)
cd backend
pytest
pytest tests/test_matching.py -v

# frontend (28 tests) + type-check + production build
cd frontend
npm test
npm run typecheck
npm run build
```

See `docs/testing.md` for what each test file covers and for the verification that was actually run.

## Troubleshooting

* **"Cannot reach the server"** in the browser: the backend is not running on port 8000 (start `uvicorn app.main:app --reload`).
* **Everyone was signed out after restarting the backend**: only happens if `SECRET_KEY` changed. Set a fixed `SECRET_KEY` in `backend/.env`.
* **HTTP 429 "Too many failed sign-in attempts"**: wait for the window (default 15 minutes) or restart the backend.
* **Demo donations show as expired**: all times are relative to when `python seed.py` ran; run it again before a demo.
* **Map shows grey tiles**: OpenStreetMap tiles need an internet connection; markers and everything else still work.
* **Phone on the same Wi-Fi**: run `npm run dev -- --host`, open `http://<your-PC-IP>:5173`, and add that origin to `CORS_ORIGINS` only if you bypass the proxy. The browser's "use my location" button needs HTTPS or `localhost`.
* **Windows PowerShell blocks the venv activation script**: run `Set-ExecutionPolicy -Scope Process RemoteSigned` first, or use `cmd` with `.venv\Scripts\activate.bat`.

## API documentation

Run the backend and open <http://localhost:8000/docs> (Swagger UI) or `/redoc`. In Swagger, click **Authorize** and paste
the `access_token` returned by `POST /api/auth/login`.

| Group | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET/PATCH /api/auth/me` |
| Donations | `POST/GET /api/donations`, `GET/PATCH /api/donations/{id}`, `POST .../cancel`, `GET .../matches` |
| Workflow | `POST /api/donations/{id}/accept`, `/pickup`, `/collect`, `/complete` |
| Organizations | `GET /api/organizations`, `GET /api/organizations/me`, `GET/PATCH /api/organizations/{id}` |
| Reports | `POST/GET /api/reports`, `PATCH /api/reports/{id}` |
| Admin | `GET /api/admin/dashboard`, `/users`, `/organizations`, `/donations`; `POST /api/admin/organizations/{id}/verify`, `/reject`; `POST /api/admin/users/{id}/toggle-active` |
| Impact | `GET /api/impact` (public aggregates), `/impact/donor`, `/impact/organization` |

All errors have the shape `{"detail": "<friendly message>", "code": "<machine code>"}`; validation errors add an `errors` list.

## Known limitations

* **No food-safety checking.** FoodBridge cannot verify what donors say about food. This is a coordination tool.
* Pickup is not guaranteed; there is no delivery-volunteer matching (organizations collect the food themselves).
* Distance is straight-line (Haversine) by default; travel time uses an assumed average speed of 25 km/h with a 1.3
  road-detour factor and a 15-minute preparation buffer. Optional OSRM improves this but needs internet.
* An organization's committed capacity is checked when accepting. Two *different* donations accepted at the same instant
  by the same organization could together slightly exceed its capacity.
* The first valid acceptance wins; partial acceptance (splitting a donation between organizations) is not supported.
* Impact numbers (meals, kg, people served) are **estimates** based on documented assumptions; no CO2 figures are produced.
* No email/SMS notifications, no image upload, no database migrations (tables are created with `create_all`).
* JWT is kept in the browser's `localStorage`, which is acceptable for a college project but exposed to XSS in a real deployment.
* SQLite is for development; use PostgreSQL and Alembic for production.
* Operating hours use one fixed UTC offset (default IST).

## Future enhancements

OSRM routing as default, image upload, notifications (email/SMS/push), delivery-volunteer matching, partial acceptance,
ratings, recurring donors, Alembic + PostgreSQL, deployment, multilingual UI, and learning weights from historical data
(only once there is real data to learn from).
