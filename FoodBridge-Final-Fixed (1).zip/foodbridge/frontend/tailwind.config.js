/** Design tokens. Palette: banana-leaf green + turmeric + chilli, on a pale sage page. */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12261F',
        paper: '#F3F6F1',
        leaf: { 50: '#EEF6F0', 100: '#D9EBDD', 200: '#B5D8BE', 300: '#86BE96', 400: '#55A06C', 500: '#2F8450', 600: '#1F6F4A', 700: '#195A3C', 800: '#154832', 900: '#10372A' },
        turmeric: { 50: '#FFF8E1', 100: '#FFEDB0', 300: '#FFD04A', 400: '#F7BC1B', 500: '#E8A800', 600: '#B88400' },
        chilli: { 50: '#FDECE8', 100: '#F9CFC6', 500: '#D2452B', 600: '#B3351F' },
        mist: { 50: '#F8FAF7', 100: '#E9EFE8', 200: '#D3DCD3', 300: '#B5C2B8', 400: '#8A9A90', 500: '#66766C', 600: '#4A5A50' },
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        body: ['"Public Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
