import type {
  AdminDashboard, AuthResponse, Donation, ImpactData, MatchesResponse, Organization, Report, User,
} from '../types'

const BASE = ((import.meta.env.VITE_API_URL as string | undefined) ?? '') + '/api'
const TOKEN_KEY = 'foodbridge_token'

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t: string) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
}

/** Error thrown for every failed request, with a message that is safe to show to users. */
export class ApiError extends Error {
  status: number
  code?: string
  fieldErrors: Record<string, string>
  constructor(message: string, status: number, code?: string, fieldErrors: Record<string, string> = {}) {
    super(message)
    this.status = status
    this.code = code
    this.fieldErrors = fieldErrors
  }
}

type Query = Record<string, string | number | undefined | null>

async function request<T>(method: string, path: string, body?: unknown, query?: Query): Promise<T> {
  let url = BASE + path
  if (query) {
    const qs = new URLSearchParams()
    Object.entries(query).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') qs.set(k, String(v)) })
    const s = qs.toString()
    if (s) url += '?' + s
  }
  const headers: Record<string, string> = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  const token = tokenStore.get()
  if (token) headers['Authorization'] = `Bearer ${token}`

  let res: Response
  try {
    res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined })
  } catch {
    throw new ApiError('Cannot reach the FoodBridge server. Check that the backend is running and try again.', 0, 'network_error')
  }

  if (res.status === 204) return undefined as T
  let data: any = null
  try { data = await res.json() } catch { /* non-JSON error body */ }

  if (!res.ok) {
    const fieldErrors: Record<string, string> = {}
    if (Array.isArray(data?.errors)) {
      data.errors.forEach((e: { field: string; message: string }) => { if (e.field && !fieldErrors[e.field]) fieldErrors[e.field] = e.message })
    }
    const err = new ApiError(data?.detail ?? `Request failed (${res.status}).`, res.status, data?.code, fieldErrors)
    // Session is over (expired/invalid token) or the account was deactivated while signed in.
    if (token && ((res.status === 401 && ['token_expired', 'invalid_token', 'not_authenticated'].includes(err.code ?? ''))
      || (res.status === 403 && err.code === 'account_inactive'))) {
      window.dispatchEvent(new Event('fb:unauthorized'))
    }
    throw err
  }
  return data as T
}

const get = <T,>(p: string, q?: Query) => request<T>('GET', p, undefined, q)
const post = <T,>(p: string, b?: unknown) => request<T>('POST', p, b ?? {})
const patch = <T,>(p: string, b: unknown) => request<T>('PATCH', p, b)

export const authApi = {
  login: (email: string, password: string) => post<AuthResponse>('/auth/login', { email, password }),
  register: (payload: unknown) => post<AuthResponse>('/auth/register', payload),
  me: () => get<User>('/auth/me'),
  updateMe: (payload: unknown) => patch<User>('/auth/me', payload),
}

export const donationApi = {
  create: (payload: unknown) => post<Donation>('/donations', payload),
  list: (q?: { view?: string; status?: string }) => get<Donation[]>('/donations', q),
  get: (id: number | string) => get<Donation>(`/donations/${id}`),
  update: (id: number, payload: unknown) => patch<Donation>(`/donations/${id}`, payload),
  cancel: (id: number) => post<Donation>(`/donations/${id}/cancel`),
  matches: (id: number | string) => get<MatchesResponse>(`/donations/${id}/matches`),
  accept: (id: number) => post<Donation>(`/donations/${id}/accept`),
  schedulePickup: (id: number, scheduled_at: string, notes?: string) =>
    post<Donation>(`/donations/${id}/pickup`, { scheduled_at, notes: notes || null }),
  collect: (id: number) => post<Donation>(`/donations/${id}/collect`),
  complete: (id: number, notes?: string) => post<Donation>(`/donations/${id}/complete`, { notes: notes || null }),
}

export const orgApi = {
  me: () => get<Organization>('/organizations/me'),
  list: () => get<Organization[]>('/organizations'),
  update: (id: number, payload: unknown) => patch<Organization>(`/organizations/${id}`, payload),
}

export const reportApi = {
  create: (payload: { donation_id: number; reason: string; details?: string }) => post<Report>('/reports', payload),
  list: (status?: string) => get<Report[]>('/reports', { status }),
  update: (id: number, payload: { status?: string; resolution_notes?: string }) => patch<Report>(`/reports/${id}`, payload),
}

export const impactApi = {
  platform: () => get<ImpactData>('/impact'),
  donor: () => get<ImpactData>('/impact/donor'),
  organization: () => get<ImpactData>('/impact/organization'),
}

export const adminApi = {
  dashboard: () => get<AdminDashboard>('/admin/dashboard'),
  users: (q?: { role?: string; search?: string }) => get<User[]>('/admin/users', q),
  toggleUser: (id: number) => post<User>(`/admin/users/${id}/toggle-active`),
  organizations: (status?: string) => get<Organization[]>('/admin/organizations', { status }),
  verify: (id: number) => post<Organization>(`/admin/organizations/${id}/verify`),
  reject: (id: number) => post<Organization>(`/admin/organizations/${id}/reject`),
  donations: (status?: string) => get<Donation[]>('/admin/donations', { status }),
}
