import { ApiError, authApi, donationApi, tokenStore } from './api'

const mockFetch = (status: number, body: unknown) =>
  vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } }))

afterEach(() => vi.restoreAllMocks())

describe('api client', () => {
  it('sends the bearer token and JSON body', async () => {
    tokenStore.set('abc')
    const spy = mockFetch(200, { id: 1 })
    await donationApi.update(5, { title: 'New' })
    const [url, init] = spy.mock.calls[0]
    expect(url).toBe('/api/donations/5')
    expect((init as RequestInit).method).toBe('PATCH')
    expect((init as RequestInit).headers).toMatchObject({ Authorization: 'Bearer abc', 'Content-Type': 'application/json' })
  })

  it('turns validation errors into per-field messages', async () => {
    mockFetch(422, { detail: 'Some fields need your attention.', code: 'validation_error',
      errors: [{ field: 'organization.name', message: 'This field is required' }, { field: 'email', message: 'Enter a valid email address' }] })
    const err = await authApi.register({}).catch((e) => e)
    expect(err).toBeInstanceOf(ApiError)
    expect(err.status).toBe(422)
    expect(err.fieldErrors).toEqual({ 'organization.name': 'This field is required', email: 'Enter a valid email address' })
  })

  it('gives a friendly message when the server cannot be reached', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'))
    const err = await authApi.me().catch((e) => e)
    expect(err.code).toBe('network_error')
    expect(err.message).toMatch(/Cannot reach/)
  })

  it.each([
    [401, 'token_expired'], [401, 'invalid_token'], [403, 'account_inactive'],
  ])('signals the app to sign out on %i %s while signed in', async (status, code) => {
    tokenStore.set('abc')
    const listener = vi.fn()
    window.addEventListener('fb:unauthorized', listener)
    mockFetch(status, { detail: 'x', code })
    await authApi.me().catch(() => {})
    window.removeEventListener('fb:unauthorized', listener)
    expect(listener).toHaveBeenCalledTimes(1)
  })

  it('does NOT sign out on a wrong password (login has no token yet) or a plain 403', async () => {
    const listener = vi.fn()
    window.addEventListener('fb:unauthorized', listener)
    mockFetch(401, { detail: 'Incorrect email or password.', code: 'invalid_credentials' })
    await authApi.login('a@b.c', 'x').catch(() => {})
    tokenStore.set('abc')
    mockFetch(403, { detail: 'nope', code: 'wrong_role' })
    await authApi.me().catch(() => {})
    window.removeEventListener('fb:unauthorized', listener)
    expect(listener).not.toHaveBeenCalled()
  })
})
