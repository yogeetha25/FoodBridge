import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import { ApiError, authApi, tokenStore } from '../services/api'
import type { User } from '../types'

interface AuthState {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<User>
  register: (payload: unknown) => Promise<User>
  logout: () => void
  refresh: () => Promise<void>
  setUser: (u: User) => void
}

const AuthContext = createContext<AuthState | null>(null)
const FOCUS_REFRESH_MIN_MS = 30_000

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState<boolean>(!!tokenStore.get())
  const lastRefresh = useRef(0)

  const logout = useCallback(() => { tokenStore.clear(); setUser(null) }, [])

  const refresh = useCallback(async () => {
    if (!tokenStore.get()) { setUser(null); return }
    try {
      setUser(await authApi.me())
      lastRefresh.current = Date.now()
    } catch (e) {
      // Only end the session when the server says the credentials are no good. A network blip or a 5xx must
      // not sign people out: keep the token and the current user, and let them retry.
      if (e instanceof ApiError && (e.status === 401 || e.status === 403)) logout()
    }
  }, [logout])

  // Restore the session when the page loads
  useEffect(() => { refresh().finally(() => setLoading(false)) }, [refresh])

  // The API client fires this when the server says our token is invalid/expired (or the account was deactivated)
  useEffect(() => {
    window.addEventListener('fb:unauthorized', logout)
    return () => window.removeEventListener('fb:unauthorized', logout)
  }, [logout])

  // Pick up changes made elsewhere (e.g. an administrator verified this organization) when the tab regains focus.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible' && tokenStore.get() && Date.now() - lastRefresh.current > FOCUS_REFRESH_MIN_MS) {
        refresh()
      }
    }
    document.addEventListener('visibilitychange', onVisible)
    window.addEventListener('focus', onVisible)
    return () => { document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('focus', onVisible) }
  }, [refresh])

  const startSession = (res: { access_token: string; user: User }) => {
    tokenStore.set(res.access_token)
    lastRefresh.current = Date.now()
    setUser(res.user)
    return res.user
  }
  const login = async (email: string, password: string) => startSession(await authApi.login(email, password))
  const register = async (payload: unknown) => startSession(await authApi.register(payload))

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refresh, setUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}

export const homePathFor = (role: User['role']) =>
  role === 'ADMIN' ? '/admin' : role === 'ORGANIZATION' ? '/org' : '/donor'
