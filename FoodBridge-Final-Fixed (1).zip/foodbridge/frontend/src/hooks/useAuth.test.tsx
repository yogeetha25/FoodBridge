import { act, renderHook, waitFor } from '@testing-library/react'
import type { ReactNode } from 'react'
import { AuthProvider, useAuth } from './useAuth'
import { ApiError, authApi, tokenStore } from '../services/api'
import type { User } from '../types'

const user: User = { id: 1, email: 'a@b.c', role: 'DONOR', full_name: 'Asha', phone: null, donor_type: 'HOTEL', is_active: true, created_at: '', organization: null }
const wrapper = ({ children }: { children: ReactNode }) => <AuthProvider>{children}</AuthProvider>

afterEach(() => vi.restoreAllMocks())

describe('AuthProvider', () => {
  it('restores the session from a stored token', async () => {
    tokenStore.set('t')
    vi.spyOn(authApi, 'me').mockResolvedValue(user)
    const { result } = renderHook(() => useAuth(), { wrapper })
    await waitFor(() => expect(result.current.loading).toBe(false))
    expect(result.current.user?.email).toBe('a@b.c')
  })

  it('signs out when the server rejects the token (401)', async () => {
    tokenStore.set('bad')
    vi.spyOn(authApi, 'me').mockRejectedValue(new ApiError('expired', 401, 'token_expired'))
    const { result } = renderHook(() => useAuth(), { wrapper })
    await waitFor(() => expect(result.current.loading).toBe(false))
    expect(result.current.user).toBeNull()
    expect(tokenStore.get()).toBeNull()
  })

  it('keeps the token when the server is merely unreachable (network error / 500)', async () => {
    tokenStore.set('good')
    vi.spyOn(authApi, 'me').mockRejectedValue(new ApiError('Cannot reach', 0, 'network_error'))
    const { result } = renderHook(() => useAuth(), { wrapper })
    await waitFor(() => expect(result.current.loading).toBe(false))
    expect(tokenStore.get()).toBe('good')          // used to be wiped, logging the user out on any hiccup
  })

  it('login stores the token and user; logout clears them', async () => {
    vi.spyOn(authApi, 'login').mockResolvedValue({ access_token: 'tok', token_type: 'bearer', user })
    const { result } = renderHook(() => useAuth(), { wrapper })
    await waitFor(() => expect(result.current.loading).toBe(false))
    await act(async () => { await result.current.login('a@b.c', 'pw') })
    expect(tokenStore.get()).toBe('tok')
    expect(result.current.user?.full_name).toBe('Asha')
    act(() => result.current.logout())
    expect(tokenStore.get()).toBeNull()
    expect(result.current.user).toBeNull()
  })

  it('signs out when the api client reports an unauthorized session', async () => {
    tokenStore.set('t')
    vi.spyOn(authApi, 'me').mockResolvedValue(user)
    const { result } = renderHook(() => useAuth(), { wrapper })
    await waitFor(() => expect(result.current.user).not.toBeNull())
    act(() => { window.dispatchEvent(new Event('fb:unauthorized')) })
    expect(result.current.user).toBeNull()
  })
})
