import { act, renderHook, waitFor } from '@testing-library/react'
import { useFetch } from './useFetch'

function deferred<T>() {
  let resolve!: (v: T) => void
  const promise = new Promise<T>((r) => { resolve = r })
  return { promise, resolve }
}

describe('useFetch', () => {
  it('loads data and exposes loading/error state', async () => {
    const { result } = renderHook(() => useFetch(async () => 'hello', []))
    expect(result.current.loading).toBe(true)
    await waitFor(() => expect(result.current.data).toBe('hello'))
    expect(result.current.loading).toBe(false)
    expect(result.current.error).toBeNull()
  })

  it('reports the error message when the loader fails', async () => {
    const { result } = renderHook(() => useFetch(async () => { throw new Error('boom') }, []))
    await waitFor(() => expect(result.current.error).toBe('boom'))
    expect(result.current.loading).toBe(false)
  })

  it('ignores an OLDER response that arrives after a NEWER one (stale response bug)', async () => {
    const slow = deferred<string>()
    const fast = deferred<string>()
    const calls = [slow, fast]
    let i = 0
    const { result, rerender } = renderHook(({ q }) => useFetch(() => calls[i++].promise, [q]), { initialProps: { q: 'a' } })
    rerender({ q: 'ab' })                         // second request starts while the first is still pending
    await act(async () => { fast.resolve('result for ab') })
    await waitFor(() => expect(result.current.data).toBe('result for ab'))
    await act(async () => { slow.resolve('STALE result for a') })   // the slow, older one finally arrives
    expect(result.current.data).toBe('result for ab')                // ...and must not overwrite the newer data
    expect(result.current.loading).toBe(false)
  })

  it('does not update state after unmount', async () => {
    const d = deferred<string>()
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {})
    const { unmount } = renderHook(() => useFetch(() => d.promise, []))
    unmount()
    await act(async () => { d.resolve('late') })
    expect(spy).not.toHaveBeenCalled()
    spy.mockRestore()
  })

  it('reload() fetches again', async () => {
    let n = 0
    const { result } = renderHook(() => useFetch(async () => ++n, []))
    await waitFor(() => expect(result.current.data).toBe(1))
    await act(async () => { await result.current.reload() })
    expect(result.current.data).toBe(2)
  })
})
