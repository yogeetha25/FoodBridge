import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * Run an async loader on mount (and whenever `deps` change). Returns data/loading/error + reload().
 * Only the LATEST request may update the state: if an older, slower response arrives after a newer one
 * (fast typing in a search box, quick filter changes) it is ignored, and nothing is set after unmount.
 */
export function useFetch<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const loaderRef = useRef(loader)
  loaderRef.current = loader
  const latest = useRef(0)
  const mounted = useRef(true)
  useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])

  const load = useCallback(async () => {
    const ticket = ++latest.current
    setLoading(true)
    setError(null)
    try {
      const result = await loaderRef.current()
      if (mounted.current && ticket === latest.current) setData(result)
    } catch (e) {
      if (mounted.current && ticket === latest.current) setError(e instanceof Error ? e.message : 'Something went wrong.')
    } finally {
      if (mounted.current && ticket === latest.current) setLoading(false)
    }
  }, [])

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { load() }, deps)
  return { data, loading, error, reload: load, setData }
}
