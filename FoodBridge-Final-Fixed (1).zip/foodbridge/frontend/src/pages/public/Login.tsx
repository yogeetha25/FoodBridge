import { useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { homePathFor, useAuth } from '../../hooks/useAuth'
import { Alert, Field, Logo } from '../../components/ui'

// Shown ONLY on the development server (tree-shaken from production builds). Demo data only.
const DEMO = import.meta.env.DEV ? [
  { label: 'Admin', email: 'admin@foodbridge.demo', password: 'Admin@FoodBridge1' },
  { label: 'Donor: ABC College', email: 'college@foodbridge.demo', password: 'Donor@FoodBridge1' },
  { label: 'Donor: Green Leaf', email: 'restaurant@foodbridge.demo', password: 'Donor@FoodBridge1' },
  { label: 'NGO: Annapurna', email: 'ngo1@foodbridge.demo', password: 'Ngo@FoodBridge1' },
  { label: 'NGO: Hope Shelter', email: 'ngo2@foodbridge.demo', password: 'Ngo@FoodBridge1' },
  { label: 'NGO: Unverified', email: 'ngo5@foodbridge.demo', password: 'Ngo@FoodBridge1' },
] : []

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    setBusy(true); setError(null)
    try {
      const user = await login(email, password)
      const from = (location.state as { from?: string } | null)?.from
      navigate(from && from.startsWith('/' + homePathFor(user.role).slice(1)) ? from : homePathFor(user.role), { replace: true })
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not sign in.') }
    finally { setBusy(false) }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-4 py-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-6 flex justify-center" aria-label="FoodBridge home"><Logo /></Link>
        <form onSubmit={submit} className="card space-y-4 p-6" noValidate>
          <h1 className="text-2xl font-bold">Sign in</h1>
          {error && <Alert kind="error">{error}</Alert>}
          <Field label="Email" htmlFor="email">
            <input id="email" type="email" autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label="Password" htmlFor="password">
            <input id="password" type="password" autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </Field>
          <button className="btn btn-primary w-full" disabled={busy}>{busy ? 'Signing in...' : 'Sign in'}</button>
          <p className="text-center text-sm text-mist-500">New to FoodBridge? <Link className="font-semibold text-leaf-700" to="/register">Create an account</Link></p>
        </form>
        {DEMO.length > 0 && (
          <div className="card mt-4 p-4">
            <p className="mb-2 text-sm font-semibold">Demo accounts (development only)</p>
            <div className="flex flex-wrap gap-2">
              {DEMO.map((d) => (
                <button key={d.email} type="button" className="btn btn-secondary px-3 py-1.5 text-xs"
                  onClick={() => { setEmail(d.email); setPassword(d.password) }}>{d.label}</button>
              ))}
            </div>
            <p className="mt-2 text-xs text-mist-500">Run <code>python seed.py</code> in the backend first. Click a button to fill the form, then Sign in.</p>
          </div>
        )}
      </div>
    </div>
  )
}
