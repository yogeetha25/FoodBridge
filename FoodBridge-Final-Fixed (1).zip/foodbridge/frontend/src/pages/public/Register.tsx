import { useState, type FormEvent, type ReactNode } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Building2, HeartHandshake } from 'lucide-react'
import { ApiError } from '../../services/api'
import { homePathFor, useAuth } from '../../hooks/useAuth'
import { Alert, Field, Logo } from '../../components/ui'
import OrgForm, { emptyOrgForm, formToPayload, type OrgFormState } from '../../components/OrgForm'
import Disclaimer from '../../components/Disclaimer'
import { DONOR_TYPE_LABELS } from '../../utils/format'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [role, setRole] = useState<'DONOR' | 'ORGANIZATION'>('DONOR')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [donorType, setDonorType] = useState('RESTAURANT')
  const [org, setOrg] = useState<OrgFormState>(emptyOrgForm)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)

  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    setBusy(true); setError(null); setFieldErrors({})
    try {
      const payload: Record<string, unknown> = { email, password, full_name: fullName, phone: phone || null, role }
      if (role === 'DONOR') payload.donor_type = donorType
      else payload.organization = formToPayload(org)
      const user = await register(payload)
      navigate(homePathFor(user.role), { replace: true })
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not create your account.')
      if (e instanceof ApiError) setFieldErrors(e.fieldErrors)
    } finally { setBusy(false) }
  }

  const roleBtn = (value: 'DONOR' | 'ORGANIZATION', title: string, text: string, icon: ReactNode) => (
    <button type="button" onClick={() => setRole(value)} aria-pressed={role === value}
      className={`flex-1 rounded-xl border-2 p-4 text-left transition-colors ${role === value ? 'border-leaf-600 bg-leaf-50' : 'border-mist-200 bg-white hover:border-leaf-300'}`}>
      <span className="mb-1 flex items-center gap-2 font-bold text-leaf-700">{icon}{title}</span>
      <span className="text-sm text-mist-500">{text}</span>
    </button>
  )

  return (
    <div className="min-h-screen bg-paper px-4 py-10">
      <div className="mx-auto max-w-2xl">
        <Link to="/" className="mb-6 flex justify-center" aria-label="FoodBridge home"><Logo /></Link>
        <form onSubmit={submit} className="card space-y-5 p-6" noValidate>
          <h1 className="text-2xl font-bold">Create your account</h1>
          <div className="flex flex-col gap-3 sm:flex-row">
            {roleBtn('DONOR', 'I have food to donate', 'Restaurants, hotels, caterers, event organizers.', <HeartHandshake size={20} />)}
            {roleBtn('ORGANIZATION', 'I receive food', 'NGOs, community kitchens, distribution groups.', <Building2 size={20} />)}
          </div>
          {error && <Alert kind="error">{error}</Alert>}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label={role === 'DONOR' ? 'Name of person or business' : 'Your name'} htmlFor="full-name" error={fieldErrors.full_name}>
              <input id="full-name" className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
            </Field>
            <Field label="Phone" htmlFor="phone" error={fieldErrors.phone}>
              <input id="phone" className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </Field>
            <Field label="Email" htmlFor="reg-email" error={fieldErrors.email}>
              <input id="reg-email" type="email" autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Field>
            <Field label="Password" htmlFor="reg-password" error={fieldErrors.password} hint="At least 8 characters, with a letter and a number.">
              <input id="reg-password" type="password" autoComplete="new-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </Field>
          </div>

          {role === 'DONOR' ? (
            <>
              <Field label="You are a" htmlFor="donor-type" error={fieldErrors.donor_type}>
                <select id="donor-type" className="input" value={donorType} onChange={(e) => setDonorType(e.target.value)}>
                  {Object.entries(DONOR_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </Field>
              <Disclaimer />
            </>
          ) : (
            <>
              <h2 className="border-t border-mist-200 pt-4 text-lg font-bold">Organization details</h2>
              <Alert kind="info">New organizations are reviewed by an administrator. You can sign in straight away, but you will only receive matches and be able to accept donations after you are verified.</Alert>
              <OrgForm value={org} onChange={setOrg} errors={fieldErrors} prefix="organization." />
            </>
          )}
          <button className="btn btn-primary w-full" disabled={busy}>{busy ? 'Creating account...' : 'Create account'}</button>
          <p className="text-center text-sm text-mist-500">Already registered? <Link className="font-semibold text-leaf-700" to="/login">Sign in</Link></p>
        </form>
      </div>
    </div>
  )
}
