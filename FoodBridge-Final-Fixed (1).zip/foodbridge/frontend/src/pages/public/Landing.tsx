import { Link } from 'react-router-dom'
import { Building2, Clock, Eye, HeartHandshake, MapPinned, ShieldCheck, Sparkles } from 'lucide-react'
import { impactApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { ScoreTicket } from '../../components/MatchCard'
import Disclaimer from '../../components/Disclaimer'
import type { ScoreBreakdown } from '../../types'

// Illustrative example for the hero. It is labelled as an example on the page and is not live data.
const EXAMPLE: ScoreBreakdown = {
  total: 93, distance_km: 0.9, eta_minutes: 17, time_left_minutes: 120, routing: 'haversine', weights: {}, factors: {},
  reasons: [
    { text: 'Only 0.9 km away', positive: true },
    { text: 'Capacity is sufficient (120 meals needed, 195 free)', positive: true },
    { text: 'Accepts vegetarian meals', positive: true },
    { text: 'Open now and still open on arrival', positive: true },
    { text: 'Can arrive in about 17 min, with 1 h 43 min to spare', positive: true },
  ],
}

const STEPS = [
  { icon: <HeartHandshake />, title: 'Post surplus food', text: 'Tell us what you have, how much, where, and until when.' },
  { icon: <Sparkles />, title: 'See ranked matches', text: 'Verified organizations that can really take it are scored and explained.' },
  { icon: <Building2 />, title: 'An organization accepts', text: 'The first valid acceptance wins; pickup is scheduled.' },
  { icon: <MapPinned />, title: 'Collected and served', text: 'Status updates until distribution is complete and impact is recorded.' },
]

export default function Landing() {
  const { data } = useFetch(() => impactApi.platform(), [])
  const t = data?.totals
  return (
    <div>
      <section className="bg-leaf-900 text-white">
        <div className="mx-auto grid grid-cols-1 max-w-6xl items-center gap-10 px-4 py-14 lg:grid-cols-2 lg:py-20">
          <div>
            <p className="mb-3 inline-block rounded-full bg-turmeric-400 px-3 py-1 text-sm font-semibold text-ink">Surplus food, matched in minutes</p>
            <h1 className="text-4xl font-bold leading-tight sm:text-5xl">Good food should reach people before it goes to waste.</h1>
            <p className="mt-5 max-w-xl text-lg text-leaf-100">
              Leftover food is perishable, and the right organization is usually nearby. FoodBridge connects surplus-food donors with
              verified NGOs and community kitchens, and shows exactly why each one is a good match.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/register" className="btn btn-accent px-6 py-3 text-base">Donate surplus food</Link>
              <Link to="/register" className="btn border border-leaf-300 px-6 py-3 text-base text-white hover:bg-leaf-800">Join as an organization</Link>
            </div>
          </div>
          <div className="relative">
            <p className="mb-2 text-sm text-leaf-200">Example: 120 vegetarian meals, 2 hours left</p>
            <div className="text-ink"><ScoreTicket score={EXAMPLE.total} breakdown={EXAMPLE} title="Annapurna Community Kitchen" subtitle="Example match with its explanation" rank={1} showFactors={false} /></div>
          </div>
        </div>
      </section>

      <section className="border-b border-mist-200 bg-white">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-8 text-center md:grid-cols-4">
          {[
            [t ? t.meals_redistributed.toLocaleString('en-IN') : '-', 'meals redistributed (estimate)'],
            [t ? t.completed_donations : '-', 'completed donations'],
            [t ? t.verified_organizations ?? 0 : '-', 'verified organizations'],
            [t ? t.people_served_est.toLocaleString('en-IN') : '-', 'people served (estimate)'],
          ].map(([v, l]) => (
            <div key={String(l)}><p className="font-display text-4xl font-bold text-leaf-700">{v}</p><p className="text-sm text-mist-500">{l}</p></div>
          ))}
        </div>
      </section>

      <section className="mx-auto grid grid-cols-1 max-w-6xl gap-10 px-4 py-16 md:grid-cols-2">
        <div>
          <h2 className="text-3xl font-bold">The problem</h2>
          <p className="mt-3 text-lg text-mist-600">Good food is often wasted while organizations serving communities need food. Donors have hours, not days, and rarely know who nearby can take it.</p>
        </div>
        <div>
          <h2 className="text-3xl font-bold">The solution</h2>
          <p className="mt-3 text-lg text-mist-600">FoodBridge connects surplus-food donors with verified receiving organizations, ranks them with a transparent scoring rule, and tracks each donation to completion.</p>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-3xl font-bold">How it works</h2>
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <div key={s.title} className="rounded-xl border border-mist-200 p-5">
                <div className="mb-3 flex items-center gap-3 text-leaf-600">{s.icon}<span className="font-display text-2xl font-bold text-mist-300">{i + 1}</span></div>
                <h3 className="font-bold">{s.title}</h3>
                <p className="mt-1 text-sm text-mist-600">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid grid-cols-1 max-w-6xl gap-6 px-4 py-16 md:grid-cols-2">
        <div className="card p-6">
          <h3 className="text-xl font-bold">For donors</h3>
          <ul className="mt-3 space-y-2 text-mist-600">
            <li className="flex gap-2"><Clock size={18} className="mt-1 shrink-0 text-leaf-600" />Post in a minute and see who can reach it in time</li>
            <li className="flex gap-2"><Eye size={18} className="mt-1 shrink-0 text-leaf-600" />Track every donation from posting to completion</li>
            <li className="flex gap-2"><Sparkles size={18} className="mt-1 shrink-0 text-leaf-600" />See your own impact history</li>
          </ul>
        </div>
        <div className="card p-6">
          <h3 className="text-xl font-bold">For organizations</h3>
          <ul className="mt-3 space-y-2 text-mist-600">
            <li className="flex gap-2"><ShieldCheck size={18} className="mt-1 shrink-0 text-leaf-600" />Verified status builds trust with donors</li>
            <li className="flex gap-2"><MapPinned size={18} className="mt-1 shrink-0 text-leaf-600" />Recommended donations ranked by fit for you</li>
            <li className="flex gap-2"><Building2 size={18} className="mt-1 shrink-0 text-leaf-600" />Your capacity and hours are respected automatically</li>
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <Disclaimer />
        <div className="mt-10 rounded-2xl bg-leaf-700 px-6 py-10 text-center text-white">
          <h2 className="text-3xl font-bold">Ready to bridge the gap?</h2>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <Link to="/register" className="btn btn-accent px-6 py-3">Create an account</Link>
            <Link to="/how-it-works" className="btn border border-leaf-300 px-6 py-3 text-white hover:bg-leaf-800">See how it works</Link>
          </div>
        </div>
      </section>
    </div>
  )
}
