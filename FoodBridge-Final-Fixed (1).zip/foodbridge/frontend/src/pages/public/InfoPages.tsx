import { Link } from 'react-router-dom'
import Disclaimer from '../../components/Disclaimer'

const STEPS = [
  ['A donor posts surplus food', 'Food type, quantity, vegetarian or not, pickup location and the time until which it is available. The server validates every field.'],
  ['FoodBridge filters organizations', 'Only verified organizations qualify. Anyone too far away, out of capacity, unable to take that kind of food, or unable to arrive before expiry is excluded, with the reason recorded.'],
  ['Eligible organizations are scored', 'Distance 30%, capacity fit 20%, time feasibility 25%, food compatibility 15% and availability 10% combine into a 0 to 100 score.'],
  ['The ranking explains itself', 'Each organization shows why it scored what it did, for example how far away it is and whether it is open on arrival.'],
  ['One organization accepts', 'The first valid acceptance wins. Everyone else is told the donation is taken.'],
  ['Pickup, collection, distribution', 'The organization schedules a pickup, marks the food collected, then marks distribution complete. Each step follows a strict status order.'],
  ['Impact is recorded', 'Completed donations feed the impact dashboard. Meals, kilograms and people served are labelled as estimates.'],
]

export function About() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-4xl font-bold">About FoodBridge</h1>
      <div className="mt-6 space-y-4 text-lg leading-relaxed text-mist-600">
        <p>Restaurants, hotels, caterers and college events regularly end up with edible food they cannot use. At the same time, NGOs and community kitchens in the same city look for food to serve.</p>
        <p>The gap is mostly coordination. Prepared food is perishable, so a donor may have only a few hours, and does not know which nearby organization can take that quantity of that kind of food in time.</p>
        <p>FoodBridge is a web platform that closes that gap. It does not only record waste; it actively finds and ranks suitable verified organizations and walks the donation through to completion.</p>
      </div>
      <h2 className="mt-10 text-2xl font-bold">What FoodBridge does not do</h2>
      <ul className="mt-3 list-disc space-y-2 pl-5 text-mist-600">
        <li>It does not inspect food or guarantee that it is safe. Donors are responsible for accurate information and for following local food-safety rules.</li>
        <li>It does not guarantee that every donation will be collected or reach beneficiaries.</li>
        <li>It does not replace government or NGO food-safety processes.</li>
        <li>Its impact numbers are estimates based on stated assumptions, not measurements.</li>
      </ul>
      <div className="mt-8"><Disclaimer /></div>
    </div>
  )
}

export function HowItWorks() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-4xl font-bold">How it works</h1>
      <ol className="mt-8 space-y-6">
        {STEPS.map(([title, text], i) => (
          <li key={title} className="flex gap-4">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-leaf-600 font-display font-bold text-white">{i + 1}</span>
            <div><h2 className="text-lg font-bold">{title}</h2><p className="text-mist-600">{text}</p></div>
          </li>
        ))}
      </ol>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link className="btn btn-primary" to="/register">Create an account</Link>
        <Link className="btn btn-secondary" to="/about">Read the problem statement</Link>
      </div>
    </div>
  )
}
