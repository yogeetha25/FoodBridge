import { useState, type FormEvent } from 'react'
import { ApiError, authApi, orgApi } from '../services/api'
import { useAuth } from '../hooks/useAuth'
import { Alert, Field, PageHeader } from '../components/ui'
import StatusBadge from '../components/StatusBadge'
import OrgForm, { formToPayload, orgToForm, type OrgFormState } from '../components/OrgForm'
import { useToast } from '../components/Toast'
import { DONOR_TYPE_LABELS } from '../utils/format'

export default function Profile() {
  const { user, setUser, refresh } = useAuth()
  const toast = useToast()
  const [name, setName] = useState(user!.full_name)
  const [phone, setPhone] = useState(user!.phone ?? '')
  const [donorType, setDonorType] = useState(user!.donor_type ?? 'OTHER')
  const [org, setOrg] = useState<OrgFormState | null>(user!.organization ? orgToForm(user!.organization) : null)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    setBusy(true); setError(null); setErrors({})
    try {
      const payload: Record<string, unknown> = { full_name: name, phone }
      if (user!.role === 'DONOR') payload.donor_type = donorType
      setUser(await authApi.updateMe(payload))
      if (org && user!.organization) { await orgApi.update(user!.organization.id, formToPayload(org)); await refresh() }
      toast('success', 'Profile saved.')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save your profile.')
      if (e instanceof ApiError) setErrors(e.fieldErrors)
    } finally { setBusy(false) }
  }

  const o = user!.organization
  return (
    <form onSubmit={submit} noValidate>
      <PageHeader title="Profile" subtitle={user!.email} />
      <div className="mx-auto max-w-3xl space-y-6">
        {error && <Alert kind="error">{error}</Alert>}
        {o && (
          <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
            <div><p className="text-sm text-mist-500">Verification status</p><StatusBadge status={o.verification_status} /></div>
            <p className="max-w-md text-sm text-mist-600">
              {o.verification_status === 'VERIFIED' ? `You are verified. Meals currently committed: ${o.current_load_meals ?? 0} of ${o.max_capacity_meals}.`
                : o.verification_status === 'PENDING' ? 'An administrator will review your organization. Until then you will not receive matches or be able to accept donations.'
                : 'Your organization was not verified. Contact an administrator.'}
            </p>
          </div>
        )}
        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-bold">Account</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Name" htmlFor="p-name" error={errors.full_name}><input id="p-name" className="input" value={name} onChange={(e) => setName(e.target.value)} required /></Field>
            <Field label="Phone" htmlFor="p-phone" error={errors.phone}><input id="p-phone" className="input" value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
            {user!.role === 'DONOR' && (
              <Field label="Donor type" htmlFor="p-type" error={errors.donor_type}>
                <select id="p-type" className="input" value={donorType} onChange={(e) => setDonorType(e.target.value)}>
                  {Object.entries(DONOR_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </Field>
            )}
          </div>
        </section>
        {org && (
          <section className="card space-y-4 p-5">
            <h2 className="text-lg font-bold">Organization details</h2>
            <OrgForm value={org} onChange={setOrg} errors={errors} />
          </section>
        )}
        <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save changes'}</button>
      </div>
    </form>
  )
}
