import { useState } from 'react'
import { Link } from 'react-router-dom'
import { reportApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, Field, PageHeader, Spinner } from '../../components/ui'
import StatusBadge from '../../components/StatusBadge'
import Modal from '../../components/Modal'
import { useToast } from '../../components/Toast'
import type { Report } from '../../types'
import { formatDateTime, label, REPORT_REASON_LABELS, REPORT_STATUS_LABELS } from '../../utils/format'

export default function AdminReports() {
  const toast = useToast()
  const [status, setStatus] = useState('')
  const [editing, setEditing] = useState<Report | null>(null)
  const [newStatus, setNewStatus] = useState('IN_REVIEW')
  const [notes, setNotes] = useState('')
  const { data, loading, error, reload } = useFetch(() => reportApi.list(status), [status])

  const open = (r: Report) => { setEditing(r); setNewStatus(r.status === 'OPEN' ? 'IN_REVIEW' : r.status); setNotes(r.resolution_notes ?? '') }
  const save = async () => {
    if (!editing) return
    try { await reportApi.update(editing.id, { status: newStatus, resolution_notes: notes }); toast('success', 'Report updated.'); setEditing(null); reload() }
    catch (e) { toast('error', e instanceof Error ? e.message : 'Could not update the report.') }
  }

  return (
    <div>
      <PageHeader title="Reports" subtitle="Problems raised by donors and organizations." />
      <select aria-label="Filter by status" className="input mb-4 max-w-[220px]" value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">All reports</option>
        {Object.entries(REPORT_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </select>
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> : !data || data.length === 0 ? <EmptyState title="No reports" text="Nothing to review." /> : (
        <div className="space-y-3">
          {data.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold">{label(REPORT_REASON_LABELS, r.reason)}</h3>
                  <p className="text-sm text-mist-500">By {r.reporter_name} on {formatDateTime(r.created_at)}. Donation: <Link className="font-medium text-leaf-700" to={`/admin/donations/${r.donation_id}`}>{r.donation_title}</Link></p>
                </div>
                <StatusBadge status={r.status} />
              </div>
              {r.details && <p className="mt-2 text-sm">{r.details}</p>}
              {r.resolution_notes && <p className="mt-2 rounded-lg bg-leaf-50 p-2 text-sm"><strong>Resolution notes:</strong> {r.resolution_notes}</p>}
              <button className="btn btn-secondary mt-3 px-3 py-1.5 text-xs" onClick={() => open(r)}>Update status</button>
            </div>
          ))}
        </div>
      )}
      {editing && (
        <Modal title="Update report" onClose={() => setEditing(null)}
          footer={<><button className="btn btn-secondary" onClick={() => setEditing(null)}>Cancel</button><button className="btn btn-primary" onClick={save}>Save</button></>}>
          <div className="space-y-4">
            <Field label="Status" htmlFor="rs">
              <select id="rs" className="input" value={newStatus} onChange={(e) => setNewStatus(e.target.value)}>
                {Object.entries(REPORT_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
            <Field label="Resolution notes" htmlFor="rn" hint="Visible to the person who filed the report."><textarea id="rn" className="input min-h-[96px]" value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={2000} /></Field>
          </div>
        </Modal>
      )}
    </div>
  )
}
