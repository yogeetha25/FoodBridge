import { useEffect, useState } from 'react'
import { adminApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import { useToast } from '../../components/Toast'
import { useAuth } from '../../hooks/useAuth'
import { DONOR_TYPE_LABELS, formatDate, label } from '../../utils/format'

export default function AdminUsers() {
  const toast = useToast()
  const { user: me } = useAuth()
  const [role, setRole] = useState('')
  const [search, setSearch] = useState('')
  const [debounced, setDebounced] = useState('')
  // Wait for a pause in typing before asking the server (one request per keystroke before).
  useEffect(() => { const t = setTimeout(() => setDebounced(search.trim()), 300); return () => clearTimeout(t) }, [search])
  const { data, loading, error, reload } = useFetch(() => adminApi.users({ role, search: debounced }), [role, debounced])

  const toggle = async (id: number) => {
    try { await adminApi.toggleUser(id); toast('success', 'User updated.'); reload() }
    catch (e) { toast('error', e instanceof Error ? e.message : 'Could not update the user.') }
  }
  return (
    <div>
      <PageHeader title="Users" subtitle="Donors, organizations and administrators." />
      <div className="mb-4 flex flex-wrap gap-3">
        <input aria-label="Search users" className="input max-w-xs" placeholder="Search name or email" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select aria-label="Filter by role" className="input max-w-[200px]" value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="">All roles</option><option value="DONOR">Donors</option><option value="ORGANIZATION">Organizations</option><option value="ADMIN">Admins</option>
        </select>
      </div>
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> : !data || data.length === 0 ? <EmptyState title="No users found" /> : (
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-mist-200 bg-mist-50"><tr><th className="th">Name</th><th className="th">Email</th><th className="th">Role</th><th className="th">Joined</th><th className="th">Status</th><th className="th"></th></tr></thead>
            <tbody className="divide-y divide-mist-100">
              {data.map((u) => (
                <tr key={u.id}>
                  <td className="td font-medium">{u.organization?.name ?? u.full_name}{u.donor_type && <span className="block text-xs font-normal text-mist-500">{label(DONOR_TYPE_LABELS, u.donor_type)}</span>}</td>
                  <td className="td">{u.email}</td>
                  <td className="td">{u.role === 'ORGANIZATION' ? 'Organization' : u.role === 'DONOR' ? 'Donor' : 'Admin'}</td>
                  <td className="td">{formatDate(u.created_at)}</td>
                  <td className="td">{u.is_active ? 'Active' : <span className="font-semibold text-chilli-600">Deactivated</span>}</td>
                  <td className="td text-right">{u.id !== me?.id && <button className="btn btn-secondary px-3 py-1 text-xs" onClick={() => toggle(u.id)}>{u.is_active ? 'Deactivate' : 'Reactivate'}</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
