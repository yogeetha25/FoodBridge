import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts'
import { impactApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { ErrorState, PageHeader, Spinner } from '../../components/ui'
import ImpactPanel from '../../components/ImpactPanel'

export default function AdminAnalytics() {
  const { data, loading, error, reload } = useFetch(() => impactApi.platform(), [])
  if (loading) return <Spinner />
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={reload} />
  const t = data.totals
  const outcomes = [
    { name: 'Completed', value: t.completed_donations, color: '#1F6F4A' },
    { name: 'In progress', value: t.active_donations, color: '#E8A800' },
    { name: 'Cancelled', value: t.cancelled_donations, color: '#8A9A90' },
    { name: 'Expired', value: t.expired_donations, color: '#D2452B' },
  ].filter((o) => o.value > 0)
  return (
    <div>
      <PageHeader title="Impact analytics" subtitle="Platform-wide results. All meal, weight and people figures are estimates." />
      <ImpactPanel data={data} platform />
      {outcomes.length > 0 && (
        <div className="card mt-6 p-4">
          <h3 className="mb-2 font-bold">Donation outcomes</h3>
          <div style={{ height: 260 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={outcomes} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                  {outcomes.map((o) => <Cell key={o.name} fill={o.color} />)}
                </Pie>
                <Tooltip /><Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  )
}
