import { Link } from 'react-router-dom'
import { Building2, CheckCircle2, Clock, FileWarning, Inbox, ShieldCheck, Users, Utensils, XCircle } from 'lucide-react'
import { adminApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { ErrorState, PageHeader, Spinner, StatCard } from '../../components/ui'
import { DonationCard } from '../../components/DonationList'

export default function AdminDashboard() {
  const { data: s, loading, error, reload } = useFetch(() => adminApi.dashboard(), [])
  if (loading) return <Spinner />
  if (error || !s) return <ErrorState message={error ?? 'No data'} onRetry={reload} />
  return (
    <div>
      <PageHeader title="Admin dashboard" subtitle="Platform health at a glance." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total users" value={s.users_total} icon={<Users size={18} />} />
        <StatCard label="Donors" value={s.donors_total} icon={<Users size={18} />} />
        <StatCard label="Organizations" value={s.organizations_total} icon={<Building2 size={18} />} />
        <StatCard label="Verified organizations" value={s.organizations_verified} icon={<ShieldCheck size={18} />} />
        <StatCard label="Pending verification" value={s.organizations_pending} hint={s.organizations_pending ? 'Needs your review' : 'All caught up'} icon={<Clock size={18} />} />
        <StatCard label="Open reports" value={s.open_reports} icon={<FileWarning size={18} />} />
        <StatCard label="Meals redistributed (est.)" value={s.meals_redistributed.toLocaleString('en-IN')} icon={<Utensils size={18} />} />
        <StatCard label="Total donations" value={s.donations_total} icon={<Inbox size={18} />} />
        <StatCard label="Active" value={s.donations_active} icon={<Clock size={18} />} />
        <StatCard label="Completed" value={s.donations_completed} icon={<CheckCircle2 size={18} />} />
        <StatCard label="Expired" value={s.donations_expired} icon={<XCircle size={18} />} />
        <StatCard label="Cancelled" value={s.donations_cancelled} icon={<XCircle size={18} />} />
      </div>
      {s.organizations_pending > 0 && (
        <div className="mt-6"><Link to="/admin/verification" className="btn btn-accent">Review {s.organizations_pending} pending organization{s.organizations_pending === 1 ? '' : 's'}</Link></div>
      )}
      <h2 className="mb-3 mt-8 text-xl font-bold">Latest donations</h2>
      <div className="space-y-3">{s.recent_donations.map((d) => <DonationCard key={d.id} donation={d} to={`/admin/donations/${d.id}`} showDonor />)}</div>
    </div>
  )
}
