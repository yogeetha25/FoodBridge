import { useState } from 'react'
import { adminApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import { DonationCard } from '../../components/DonationList'
import { STATUS_LABELS } from '../../utils/format'

export default function AdminDonations() {
  const [status, setStatus] = useState('')
  const { data, loading, error, reload } = useFetch(() => adminApi.donations(status), [status])
  return (
    <div>
      <PageHeader title="Donations" subtitle="Every donation on the platform. Open one to see matches or cancel it." />
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Filter by status">
        <button role="tab" aria-selected={status === ''} onClick={() => setStatus('')} className={`rounded-full px-3 py-1 text-sm ${status === '' ? 'bg-leaf-600 text-white' : 'border border-mist-200 bg-white'}`}>All</button>
        {Object.entries(STATUS_LABELS).map(([k, v]) => (
          <button key={k} role="tab" aria-selected={status === k} onClick={() => setStatus(k)} className={`rounded-full px-3 py-1 text-sm ${status === k ? 'bg-leaf-600 text-white' : 'border border-mist-200 bg-white'}`}>{v}</button>
        ))}
      </div>
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> : !data || data.length === 0 ? <EmptyState title="No donations" text="Nothing matches this filter." /> : (
        <div className="space-y-3">{data.map((d) => <DonationCard key={d.id} donation={d} to={`/admin/donations/${d.id}`} showDonor />)}</div>
      )}
    </div>
  )
}
