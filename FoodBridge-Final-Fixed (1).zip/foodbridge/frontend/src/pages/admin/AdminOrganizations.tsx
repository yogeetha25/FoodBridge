import { useState } from 'react'
import { adminApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import StatusBadge from '../../components/StatusBadge'
import MapView from '../../components/MapView'
import Modal from '../../components/Modal'
import { useToast } from '../../components/Toast'
import type { Organization } from '../../types'
import { CATEGORY_LABELS, FOOD_PREF_LABELS, label, ORG_TYPE_LABELS } from '../../utils/format'

/** Used for both /admin/organizations (all) and /admin/verification (starts on "pending"). */
export default function AdminOrganizations({ verification = false }: { verification?: boolean }) {
  const toast = useToast()
  const [status, setStatus] = useState(verification ? 'PENDING' : '')
  const [selected, setSelected] = useState<Organization | null>(null)
  const { data, loading, error, reload } = useFetch(() => adminApi.organizations(status), [status])

  const decide = async (org: Organization, approve: boolean) => {
    try {
      await (approve ? adminApi.verify(org.id) : adminApi.reject(org.id))
      toast('success', `${org.name} ${approve ? 'verified' : 'rejected'}.`)
      setSelected(null); reload()
    } catch (e) { toast('error', e instanceof Error ? e.message : 'Could not update the organization.') }
  }

  return (
    <div>
      <PageHeader title={verification ? 'Organization verification' : 'Organizations'}
        subtitle={verification ? 'Review organizations before they can be matched. Check the details and location, then verify or reject.' : 'Every receiving organization on the platform.'} />
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Filter by status">
        {[['', 'All'], ['PENDING', 'Pending'], ['VERIFIED', 'Verified'], ['REJECTED', 'Rejected']].map(([v, text]) => (
          <button key={v} role="tab" aria-selected={status === v} onClick={() => setStatus(v)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium ${status === v ? 'bg-leaf-600 text-white' : 'bg-white text-mist-600 border border-mist-200 hover:bg-mist-100'}`}>{text}</button>
        ))}
      </div>
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> : !data || data.length === 0 ? <EmptyState title="No organizations" text="Nothing matches this filter." /> : (
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-mist-200 bg-mist-50"><tr><th className="th">Organization</th><th className="th">Type</th><th className="th">Capacity</th><th className="th">Radius</th><th className="th">Status</th><th className="th"></th></tr></thead>
            <tbody className="divide-y divide-mist-100">
              {data.map((o) => (
                <tr key={o.id}>
                  <td className="td font-medium">{o.name}<span className="block text-xs font-normal text-mist-500">{o.email}</span></td>
                  <td className="td">{label(ORG_TYPE_LABELS, o.organization_type)}</td>
                  <td className="td">{o.max_capacity_meals} meals</td>
                  <td className="td">{o.service_radius_km} km</td>
                  <td className="td"><StatusBadge status={o.verification_status} /></td>
                  <td className="td text-right"><button className="btn btn-secondary px-3 py-1 text-xs" onClick={() => setSelected(o)}>Review</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <Modal title={selected.name} onClose={() => setSelected(null)}
          footer={<>
            {selected.verification_status !== 'REJECTED' && <button className="btn btn-danger" onClick={() => decide(selected, false)}>Reject</button>}
            {selected.verification_status !== 'VERIFIED' && <button className="btn btn-primary" onClick={() => decide(selected, true)}>Verify</button>}
          </>}>
          <div className="space-y-3 text-sm">
            <StatusBadge status={selected.verification_status} />
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2">
              <div><dt className="text-mist-500">Contact</dt><dd>{selected.contact_person}</dd></div>
              <div><dt className="text-mist-500">Phone</dt><dd>{selected.phone}</dd></div>
              <div className="col-span-2"><dt className="text-mist-500">Email</dt><dd>{selected.email}</dd></div>
              <div className="col-span-2"><dt className="text-mist-500">Address</dt><dd>{selected.address}</dd></div>
              <div><dt className="text-mist-500">Capacity</dt><dd>{selected.max_capacity_meals} meals ({selected.current_load_meals ?? 0} committed)</dd></div>
              <div><dt className="text-mist-500">Service radius</dt><dd>{selected.service_radius_km} km</dd></div>
              <div><dt className="text-mist-500">Hours</dt><dd>{selected.operating_hours}</dd></div>
              <div><dt className="text-mist-500">Food accepted</dt><dd>{label(FOOD_PREF_LABELS, selected.food_preferences)}</dd></div>
              <div className="col-span-2"><dt className="text-mist-500">Categories</dt><dd>{selected.preferred_categories.length ? selected.preferred_categories.map((c) => CATEGORY_LABELS[c] ?? c).join(', ') : 'All categories'}</dd></div>
            </dl>
            <MapView height={200} markers={[{ lat: selected.latitude, lng: selected.longitude, label: selected.name, kind: 'org', radiusKm: selected.service_radius_km }]} />
          </div>
        </Modal>
      )}
    </div>
  )
}
