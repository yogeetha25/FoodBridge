import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Check, Flag, Pencil } from 'lucide-react'
import { donationApi, reportApi } from '../services/api'
import { useFetch } from '../hooks/useFetch'
import { useAuth } from '../hooks/useAuth'
import { Alert, ErrorState, Field, Spinner } from '../components/ui'
import StatusBadge from '../components/StatusBadge'
import MapView, { type MapMarker } from '../components/MapView'
import MatchCard, { ScoreTicket } from '../components/MatchCard'
import Modal from '../components/Modal'
import ReportModal from '../components/ReportModal'
import EditDonationModal from '../components/EditDonationModal'
import { useToast } from '../components/Toast'
import type { Donation } from '../types'
import {
  CATEGORY_LABELS, formatDateTime, inputToIso, label, LIFECYCLE, quantityText, REPORT_REASON_LABELS, STATUS_LABELS,
  timeRemaining, toInputValue,
} from '../utils/format'

const OPEN = ['AVAILABLE', 'MATCHED']

function Stepper({ status }: { status: string }) {
  if (status === 'CANCELLED' || status === 'EXPIRED') {
    return <Alert kind={status === 'EXPIRED' ? 'warning' : 'info'}>This donation was {STATUS_LABELS[status].toLowerCase()}. No further steps are possible.</Alert>
  }
  const current = LIFECYCLE.indexOf(status as (typeof LIFECYCLE)[number])
  return (
    <ol className="flex flex-wrap gap-2" aria-label="Donation progress">
      {LIFECYCLE.map((s, i) => (
        <li key={s} aria-current={i === current ? 'step' : undefined}
          className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
            i < current ? 'bg-leaf-100 text-leaf-800' : i === current ? 'bg-leaf-600 text-white' : 'bg-mist-100 text-mist-500'}`}>
          {i < current && <Check size={12} />}{STATUS_LABELS[s]}
        </li>
      ))}
    </ol>
  )
}

export default function DonationDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const toast = useToast()
  const role = user!.role
  const base = role === 'ADMIN' ? '/admin' : role === 'ORGANIZATION' ? '/org' : '/donor'

  const { data: donation, loading, error, reload, setData } = useFetch(() => donationApi.get(id!), [id])
  // Donors and admins also see the ranked organizations
  // Wait until the donation itself has loaded (and re-run whenever its status changes), so this is one request, not two.
  const matches = useFetch(async () => (role === 'ORGANIZATION' || !donation ? null : donationApi.matches(id!)), [id, donation?.status])
  const myReports = useFetch(async () => (role === 'ADMIN' ? [] : (await reportApi.list()).filter((r) => String(r.donation_id) === id)), [id])

  const [busy, setBusy] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [confirmCancel, setConfirmCancel] = useState(false)
  const [reporting, setReporting] = useState(false)
  const [editing, setEditing] = useState(false)
  const [when, setWhen] = useState(toInputValue(new Date(Date.now() + 30 * 60000)))
  const [scheduleNotes, setScheduleNotes] = useState('')     // separate from the completion notes on purpose
  const [completeNotes, setCompleteNotes] = useState('')

  if (loading && !donation) return <Spinner />
  if (error || !donation) return <ErrorState message={error ?? 'Donation not found.'} onRetry={reload} />
  const d: Donation = donation

  const act = async (fn: () => Promise<Donation>, ok: string) => {
    setBusy(true); setActionError(null)
    try { const updated = await fn(); setData(updated); toast('success', ok) }   // a status change re-fetches the matches
    catch (e) {
      const msg = e instanceof Error ? e.message : 'That did not work.'
      setActionError(msg); toast('error', msg)
      reload() // the donation may have changed (e.g. another organization accepted it first)
    } finally { setBusy(false) }
  }

  const myOrg = user!.organization
  const isMine = role === 'ORGANIZATION' && !!myOrg && d.pickup?.organization_id === myOrg.id
  const isOwner = role === 'DONOR' && d.donor_id === user!.id
  const left = timeRemaining(d.available_until)

  const markers: MapMarker[] = [{ lat: d.latitude, lng: d.longitude, label: d.title, kind: 'donation', detail: d.pickup_address }]
  if (role === 'ORGANIZATION' && myOrg) markers.push({ lat: myOrg.latitude, lng: myOrg.longitude, label: myOrg.name, kind: 'org', radiusKm: myOrg.service_radius_km })
  else matches.data?.matches.forEach((m, i) => markers.push({
    lat: m.organization.latitude, lng: m.organization.longitude, label: `#${m.rank} ${m.organization.name}`,
    kind: i === 0 ? 'top' : 'org', detail: `${Math.round(m.score)}% match`,
  }))

  const canCancel = (role === 'DONOR' && isOwner && ['AVAILABLE', 'MATCHED', 'ACCEPTED'].includes(d.status))
    || (role === 'ADMIN' && ['AVAILABLE', 'MATCHED', 'ACCEPTED', 'PICKUP_PENDING'].includes(d.status))
  const canReport = isOwner || isMine
  const canEdit = isOwner && OPEN.includes(d.status)
  // "Back" returns to the list this donation belongs to, not always the "available" list.
  const backTo = role !== 'ORGANIZATION' ? `${base}/donations`
    : d.status === 'ACCEPTED' ? `${base}/accepted` : d.status === 'PICKUP_PENDING' || d.status === 'COLLECTED' ? `${base}/pickups`
    : d.status === 'COMPLETED' ? `${base}/completed` : `${base}/available`

  const confirmPickup = () => {
    if (!when || Number.isNaN(new Date(when).getTime())) { setActionError('Choose a valid pickup date and time.'); return }
    if (new Date(when).getTime() > new Date(d.available_until).getTime()) { setActionError('The pickup must be before the donation expires.'); return }
    return act(() => donationApi.schedulePickup(d.id, inputToIso(when), scheduleNotes), 'Pickup scheduled.')
  }

  return (
    <div>
      <Link to={backTo} className="mb-4 inline-flex items-center gap-1 text-sm font-medium text-leaf-700"><ArrowLeft size={16} /> Back</Link>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">{d.title}</h1>
          <p className="mt-1 text-sm text-mist-500">Posted by {d.donor_name} on {formatDateTime(d.created_at)}</p>
        </div>
        <StatusBadge status={d.status} />
      </div>
      <Stepper status={d.status} />
      {actionError && <div className="mt-4"><Alert kind="error">{actionError}</Alert></div>}

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-3">
          <section className="card p-5">
            <h2 className="mb-3 text-lg font-bold">Food details</h2>
            <dl className="grid grid-cols-1 gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              {[
                ['Quantity', `${quantityText(d.quantity, d.unit)} (about ${d.estimated_meals} meals)`],
                ['Category', label(CATEGORY_LABELS, d.category)],
                ['Diet', d.is_vegetarian ? 'Vegetarian' : 'Non-vegetarian'],
                ['Available until', `${formatDateTime(d.available_until)}${OPEN.includes(d.status) || d.status === 'ACCEPTED' ? ` (${left.text})` : ''}`],
                ['Prepared / available from', formatDateTime(d.prepared_at)],
                ['Pickup address', d.pickup_address],
              ].map(([k, v]) => <div key={k}><dt className="text-mist-500">{k}</dt><dd className="font-medium">{v}</dd></div>)}
            </dl>
            {d.description && <p className="mt-4 text-sm"><span className="text-mist-500">Description: </span>{d.description}</p>}
            {d.handling_notes && <p className="mt-2 text-sm"><span className="text-mist-500">Handling: </span>{d.handling_notes}</p>}
            <p className="mt-4 text-sm">
              <span className="text-mist-500">Donor contact: </span>
              {d.contact_info ?? <em className="text-mist-500">shown to the organization that accepts this donation</em>}
            </p>
            {d.distance_km != null && <p className="mt-2 text-sm"><span className="text-mist-500">Distance from your organization: </span>{d.distance_km} km</p>}
          </section>

          {d.pickup && (
            <section className="card p-5">
              <h2 className="mb-3 text-lg font-bold">Pickup</h2>
              <dl className="grid grid-cols-1 gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
                <div><dt className="text-mist-500">Organization</dt><dd className="font-medium">{d.pickup.organization_name}</dd></div>
                <div><dt className="text-mist-500">Scheduled for</dt><dd className="font-medium">{formatDateTime(d.pickup.scheduled_at)}</dd></div>
                <div><dt className="text-mist-500">Collected</dt><dd className="font-medium">{formatDateTime(d.pickup.collected_at)}</dd></div>
                <div><dt className="text-mist-500">Distribution completed</dt><dd className="font-medium">{formatDateTime(d.pickup.completed_at)}</dd></div>
              </dl>
              {d.pickup.notes && <p className="mt-3 whitespace-pre-line text-sm"><span className="text-mist-500">Notes: </span>{d.pickup.notes}</p>}
            </section>
          )}

          {d.impact && (
            <Alert kind="success" title="Impact recorded (estimates)">
              About {d.impact.meals_redistributed} meals, {d.impact.quantity_kg_est} kg of food and {d.impact.people_served_est} people served.
            </Alert>
          )}

          {/* ----- organization view: my match + workflow actions ----- */}
          {role === 'ORGANIZATION' && OPEN.includes(d.status) && (
            <section>
              <h2 className="mb-3 text-lg font-bold">Your match</h2>
              {d.my_match ? (
                <ScoreTicket score={d.my_match.score} breakdown={d.my_match.breakdown} title={myOrg?.name}
                  action={<button className="btn btn-primary" disabled={busy} onClick={() => act(() => donationApi.accept(d.id), 'You accepted this donation.')}>{busy ? 'Accepting...' : 'Accept this donation'}</button>} />
              ) : <Alert kind="warning" title="You cannot accept this donation">{d.ineligible_reason ?? 'It does not fit your organization.'}</Alert>}
            </section>
          )}
          {isMine && d.status === 'ACCEPTED' && (
            <section className="card space-y-4 p-5">
              <h2 className="text-lg font-bold">Schedule the pickup</h2>
              <Field label="Pickup time" htmlFor="when" hint="Must be before the donation expires.">
                <input id="when" type="datetime-local" className="input max-w-xs" value={when} max={toInputValue(new Date(d.available_until))} onChange={(e) => setWhen(e.target.value)} />
              </Field>
              <Field label="Notes for the donor (optional)" htmlFor="pnotes">
                <input id="pnotes" className="input" value={scheduleNotes} onChange={(e) => setScheduleNotes(e.target.value)} placeholder="Vehicle, who is coming..." />
              </Field>
              <button className="btn btn-primary" disabled={busy} onClick={confirmPickup}>Confirm pickup time</button>
            </section>
          )}
          {isMine && d.status === 'PICKUP_PENDING' && (
            <section className="card space-y-3 p-5">
              <h2 className="text-lg font-bold">Collect the food</h2>
              <p className="text-sm text-mist-600">Mark the food as collected once it is in your vehicle.</p>
              <button className="btn btn-primary" disabled={busy} onClick={() => act(() => donationApi.collect(d.id), 'Marked as collected.')}>Mark as collected</button>
            </section>
          )}
          {isMine && d.status === 'COLLECTED' && (
            <section className="card space-y-3 p-5">
              <h2 className="text-lg font-bold">Complete distribution</h2>
              <Field label="Notes (optional)" htmlFor="cnotes"><input id="cnotes" className="input" value={completeNotes} onChange={(e) => setCompleteNotes(e.target.value)} placeholder="Where and to how many people it was served" /></Field>
              <button className="btn btn-primary" disabled={busy} onClick={() => act(() => donationApi.complete(d.id, completeNotes), 'Distribution completed. Impact updated.')}>Mark distribution completed</button>
            </section>
          )}

          {myReports.data && myReports.data.length > 0 && (
            <section className="card p-5">
              <h2 className="mb-3 text-lg font-bold">Your reports on this donation</h2>
              <ul className="space-y-3 text-sm">
                {myReports.data.map((r) => (
                  <li key={r.id}>
                    <div className="flex flex-wrap items-center gap-2"><strong>{label(REPORT_REASON_LABELS, r.reason)}</strong><StatusBadge status={r.status} /><span className="text-mist-500">{formatDateTime(r.created_at)}</span></div>
                    {r.resolution_notes && <p className="mt-1 rounded-lg bg-leaf-50 p-2"><strong>Administrator's notes:</strong> {r.resolution_notes}</p>}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* ----- donor / admin view: ranked organizations ----- */}
          {role !== 'ORGANIZATION' && (
            <section>
              <h2 className="mb-1 text-lg font-bold">{OPEN.includes(d.status) ? 'Recommended organizations' : 'Organizations considered'}</h2>
              <p className="mb-3 text-sm text-mist-500">Ranked by the FoodBridge matching score. Open "How this score was calculated" to see each factor.</p>
              {!matches.data && !matches.error ? <Spinner /> : matches.error ? <ErrorState message={matches.error} onRetry={matches.reload} /> :
                matches.data && matches.data.matches.length > 0 ? (
                  <div className="space-y-3">{matches.data.matches.map((m) => <MatchCard key={m.id} match={m} />)}</div>
                ) : <Alert kind="warning" title="No eligible organization">{OPEN.includes(d.status) ? 'No verified organization can currently take this donation. Matches refresh whenever you open this page.' : 'No matches were stored for this donation.'}</Alert>}
              {matches.data && matches.data.excluded.length > 0 && (
                <details className="mt-4 text-sm">
                  <summary className="cursor-pointer font-medium text-leaf-700">{matches.data.excluded.length} organization(s) not eligible</summary>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-mist-600">{matches.data.excluded.map((e) => <li key={e.organization_id}><strong>{e.organization_name}:</strong> {e.message}</li>)}</ul>
                </details>
              )}
            </section>
          )}
        </div>

        <div className="space-y-4 lg:col-span-2">
          <MapView markers={markers} height={320} />
          <div className="flex flex-wrap gap-3 text-xs text-mist-500">
            <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-turmeric-500" />Donation</span>
            <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-leaf-600" />Organization</span>
            {role !== 'ORGANIZATION' && <span><i className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-ink" />Top match</span>}
          </div>
          <div className="flex flex-wrap gap-2">
            {canEdit && <button className="btn btn-secondary" onClick={() => setEditing(true)}><Pencil size={16} /> Edit donation</button>}
            {canCancel && <button className="btn btn-danger" onClick={() => setConfirmCancel(true)}>Cancel donation</button>}
            {canReport && <button className="btn btn-secondary" onClick={() => setReporting(true)}><Flag size={16} /> Report a problem</button>}
          </div>
        </div>
      </div>

      {confirmCancel && (
        <Modal title="Cancel this donation?" onClose={() => setConfirmCancel(false)}
          footer={<>
            <button className="btn btn-secondary" onClick={() => setConfirmCancel(false)}>Keep it</button>
            <button className="btn btn-danger" disabled={busy} onClick={async () => { setConfirmCancel(false); await act(() => donationApi.cancel(d.id), 'Donation cancelled.') }}>Yes, cancel</button>
          </>}>
          <p className="text-sm text-mist-600">The donation will be withdrawn and any accepted organization will no longer collect it. This cannot be undone.</p>
        </Modal>
      )}
      {reporting && <ReportModal donationId={d.id} onClose={() => { setReporting(false); myReports.reload() }} />}
      {editing && (
        <EditDonationModal donation={d} onClose={() => setEditing(false)}
          onSaved={(updated) => { setData(updated); setEditing(false); toast('success', 'Donation updated. Matches were recalculated.'); matches.reload() }} />
      )}
    </div>
  )
}
