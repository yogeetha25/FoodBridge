import { Link } from 'react-router-dom'
import { CheckCircle2, Clock, Package, PlusCircle, Utensils } from 'lucide-react'
import { donationApi, impactApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { useAuth } from '../../hooks/useAuth'
import { EmptyState, ErrorState, PageHeader, Spinner, StatCard } from '../../components/ui'
import { DonationCard } from '../../components/DonationList'
import ImpactPanel from '../../components/ImpactPanel'

export default function DonorDashboard() {
  const { user } = useAuth()
  const donations = useFetch(() => donationApi.list(), [])
  const impact = useFetch(() => impactApi.donor(), [])

  if (donations.loading || impact.loading) return <Spinner />
  if (donations.error) return <ErrorState message={donations.error} onRetry={donations.reload} />
  const list = donations.data ?? []
  const t = impact.data?.totals

  return (
    <div>
      <PageHeader title={`Welcome, ${user?.full_name}`} subtitle="Here is where your donations stand."
        actions={<Link to="/donor/donate" className="btn btn-primary"><PlusCircle size={18} /> Donate food</Link>} />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total donations" value={t?.total_donations ?? list.length} icon={<Package size={18} />} />
        <StatCard label="Active" value={t?.active_donations ?? 0} icon={<Clock size={18} />} />
        <StatCard label="Completed" value={t?.completed_donations ?? 0} icon={<CheckCircle2 size={18} />} />
        <StatCard label="Meals redistributed (est.)" value={t?.meals_redistributed ?? 0} icon={<Utensils size={18} />} />
      </div>

      <h2 className="mb-3 mt-8 text-xl font-bold">Recent donations</h2>
      {list.length === 0 ? (
        <EmptyState title="No donations yet" text="Post your first surplus-food donation and we will find organizations that can collect it."
          action={<Link to="/donor/donate" className="btn btn-primary">Donate food</Link>} />
      ) : (
        <div className="space-y-3">
          {list.slice(0, 4).map((d) => <DonationCard key={d.id} donation={d} to={`/donor/donations/${d.id}`} />)}
          {list.length > 4 && <Link className="btn btn-ghost" to="/donor/donations">View all {list.length} donations</Link>}
        </div>
      )}

      {impact.data && <><h2 className="mb-3 mt-10 text-xl font-bold">Your impact</h2><ImpactPanel data={impact.data} /></>}
    </div>
  )
}
