import { Link } from 'react-router-dom'
import { donationApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import MatchCard from '../../components/MatchCard'
import type { MatchesResponse } from '../../types'

/** For each of the donor's open donations, show the ranked organizations. */
export default function RecommendedOrgs() {
  const { data, loading, error, reload } = useFetch(async () => {
    const all = await donationApi.list()
    const open = all.filter((d) => d.status === 'AVAILABLE' || d.status === 'MATCHED')
    // In parallel: one slow donation no longer delays all the others (was one request after another).
    return Promise.all(open.map(async (d): Promise<{ id: number; title: string; res: MatchesResponse }> =>
      ({ id: d.id, title: d.title, res: await donationApi.matches(d.id) })))
  }, [])

  if (loading) return <Spinner label="Scoring organizations" />
  if (error) return <ErrorState message={error} onRetry={reload} />
  return (
    <div>
      <PageHeader title="Recommended organizations" subtitle="Ranked for each donation that is still waiting for an organization. Scores are recalculated each time you open this page." />
      {!data || data.length === 0 ? (
        <EmptyState title="No open donations" text="Post a donation to see which organizations fit it best." action={<Link to="/donor/donate" className="btn btn-primary">Donate food</Link>} />
      ) : data.map(({ id, title, res }) => (
        <section key={id} className="mb-10">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-xl font-bold">{title}</h2>
            <Link className="btn btn-ghost" to={`/donor/donations/${id}`}>Open donation</Link>
          </div>
          {res.matches.length === 0 ? (
            <div className="card p-4 text-sm text-mist-600">
              No eligible organization right now.
              {res.excluded.length > 0 && <ul className="mt-2 list-disc pl-5">{res.excluded.map((e) => <li key={e.organization_id}>{e.message}</li>)}</ul>}
            </div>
          ) : <div className="space-y-3">{res.matches.map((m) => <MatchCard key={m.id} match={m} />)}</div>}
        </section>
      ))}
    </div>
  )
}
