import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { ApiError, donationApi } from '../../services/api'
import { Alert, Field, PageHeader } from '../../components/ui'
import { LocationPicker } from '../../components/MapView'
import Disclaimer from '../../components/Disclaimer'
import { useToast } from '../../components/Toast'
import { CATEGORY_LABELS, coordOr, inputToIso, numOrNull, toInputValue, UNIT_LABELS } from '../../utils/format'
import { useAuth } from '../../hooks/useAuth'

export default function CreateDonation() {
  const navigate = useNavigate()
  const toast = useToast()
  const { user } = useAuth()
  const now = new Date()
  const [f, setF] = useState({
    title: '', category: 'COOKED_MEALS', is_vegetarian: true, quantity: '', unit: 'MEALS', estimated_meals: '',
    prepared_at: toInputValue(new Date(now.getTime() - 30 * 60000)),
    available_until: toInputValue(new Date(now.getTime() + 2 * 3600000)),
    pickup_address: '', latitude: '12.9716', longitude: '77.5946', description: '', handling_notes: '',
    contact_info: user ? `${user.full_name}${user.phone ? ': ' + user.phone : ''}` : '',
  })
  const [mealsTouched, setMealsTouched] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [confirmed, setConfirmed] = useState(false)

  const set = (k: string, v: string | boolean) => setF((p) => ({ ...p, [k]: v }))
  // For meals/portions the number of meals is usually the same as the quantity: suggest it.
  const onQuantity = (v: string) => setF((p) => ({
    ...p, quantity: v, estimated_meals: !mealsTouched && ['MEALS', 'PORTIONS'].includes(p.unit) ? v : p.estimated_meals,
  }))

  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    setBusy(true); setError(null); setErrors({})
    // Light client-side checks for quick feedback. The server validates everything again.
    const local: Record<string, string> = {}
    if (!(Number(f.quantity) > 0)) local.quantity = 'Enter a quantity above 0'
    if (!(Number(f.estimated_meals) > 0)) local.estimated_meals = 'Enter an estimated number of meals above 0'
    if (numOrNull(f.latitude) === null || !(Math.abs(Number(f.latitude)) <= 90)) local.latitude = 'Enter a latitude between -90 and 90'
    if (numOrNull(f.longitude) === null || !(Math.abs(Number(f.longitude)) <= 180)) local.longitude = 'Enter a longitude between -180 and 180'
    if (!f.prepared_at || !f.available_until) local.available_until = 'Choose both times'
    else if (new Date(f.available_until).getTime() <= Date.now()) local.available_until = 'Must be in the future'
    else if (new Date(f.prepared_at).getTime() >= new Date(f.available_until).getTime()) local.prepared_at = 'Must be before the available-until time'
    if (Object.keys(local).length) { setErrors(local); setBusy(false); return }
    try {
      const d = await donationApi.create({
        title: f.title, category: f.category, is_vegetarian: f.is_vegetarian, quantity: Number(f.quantity), unit: f.unit,
        estimated_meals: Math.round(Number(f.estimated_meals)), prepared_at: inputToIso(f.prepared_at),
        available_until: inputToIso(f.available_until), pickup_address: f.pickup_address,
        latitude: Number(f.latitude), longitude: Number(f.longitude),
        description: f.description || null, handling_notes: f.handling_notes || null, contact_info: f.contact_info,
      })
      toast('success', d.status === 'MATCHED' ? `Donation posted. ${d.match_count} organization(s) matched.` : 'Donation posted. No eligible organization yet; check back soon.')
      navigate(`/donor/donations/${d.id}`)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not post the donation.')
      if (e instanceof ApiError) setErrors(e.fieldErrors)
    } finally { setBusy(false) }
  }

  return (
    <form onSubmit={submit} noValidate>
      <PageHeader title="Donate surplus food" subtitle="After you post, FoodBridge finds and ranks verified organizations that can collect it in time." />
      <div className="mx-auto max-w-3xl space-y-6">
        {error && <Alert kind="error">{error}</Alert>}

        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-bold">What food is it?</h2>
          <Field label="Food name" htmlFor="title" error={errors.title}>
            <input id="title" className="input" placeholder="e.g. Vegetable biryani and raita" value={f.title} onChange={(e) => set('title', e.target.value)} required />
          </Field>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Category" htmlFor="category" error={errors.category}>
              <select id="category" className="input" value={f.category} onChange={(e) => set('category', e.target.value)}>
                {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
            <Field label="Diet">
              <div className="flex gap-2" role="radiogroup" aria-label="Diet">
                {[[true, 'Vegetarian'], [false, 'Non-vegetarian']].map(([v, text]) => (
                  <button type="button" key={String(v)} role="radio" aria-checked={f.is_vegetarian === v}
                    onClick={() => set('is_vegetarian', v as boolean)}
                    className={`flex-1 rounded-lg border px-3 py-2 text-sm font-medium ${f.is_vegetarian === v ? 'border-leaf-600 bg-leaf-100 text-leaf-800' : 'border-mist-200 bg-white'}`}>
                    {text as string}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Quantity" htmlFor="quantity" error={errors.quantity}>
              <input id="quantity" type="number" min="0" step="any" className="input" value={f.quantity} onChange={(e) => onQuantity(e.target.value)} required />
            </Field>
            <Field label="Unit" htmlFor="unit" error={errors.unit}>
              <select id="unit" className="input" value={f.unit} onChange={(e) => set('unit', e.target.value)}>
                {Object.entries(UNIT_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Estimated number of meals" htmlFor="meals" error={errors.estimated_meals} hint="Roughly how many people this could feed. Organizations use it to check their capacity.">
            <input id="meals" type="number" min="1" className="input max-w-[200px]" value={f.estimated_meals}
              onChange={(e) => { setMealsTouched(true); set('estimated_meals', e.target.value) }} required />
          </Field>
          <Field label="Description (optional)" htmlFor="desc" error={errors.description}>
            <textarea id="desc" className="input min-h-[80px]" value={f.description} onChange={(e) => set('description', e.target.value)} maxLength={1000} />
          </Field>
          <Field label="Special handling (optional)" htmlFor="notes" error={errors.handling_notes} hint="Allergens, storage temperature, containers needed...">
            <textarea id="notes" className="input min-h-[64px]" value={f.handling_notes} onChange={(e) => set('handling_notes', e.target.value)} maxLength={1000} />
          </Field>
        </section>

        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-bold">When is it available?</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Prepared / available from" htmlFor="prepared" error={errors.prepared_at}>
              <input id="prepared" type="datetime-local" className="input" value={f.prepared_at} onChange={(e) => set('prepared_at', e.target.value)} required />
            </Field>
            <Field label="Available until" htmlFor="until" error={errors.available_until} hint="After this time the donation expires automatically.">
              <input id="until" type="datetime-local" className="input" value={f.available_until} onChange={(e) => set('available_until', e.target.value)} required />
            </Field>
          </div>
        </section>

        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-bold">Where should it be collected?</h2>
          <Field label="Pickup address" htmlFor="address" error={errors.pickup_address}>
            <input id="address" className="input" value={f.pickup_address} onChange={(e) => set('pickup_address', e.target.value)} required />
          </Field>
          <LocationPicker lat={coordOr(f.latitude, NaN)} lng={coordOr(f.longitude, NaN)} onChange={(la, lo) => setF((p) => ({ ...p, latitude: String(la), longitude: String(lo) }))} />
          <div className="grid grid-cols-2 gap-4">
            <Field label="Latitude" htmlFor="lat" error={errors.latitude}>
              <input id="lat" type="number" step="any" className="input" value={f.latitude} onChange={(e) => set('latitude', e.target.value)} />
            </Field>
            <Field label="Longitude" htmlFor="lng" error={errors.longitude}>
              <input id="lng" type="number" step="any" className="input" value={f.longitude} onChange={(e) => set('longitude', e.target.value)} />
            </Field>
          </div>
          <Field label="Contact for pickup" htmlFor="contact" error={errors.contact_info} hint="Shared only with the organization that accepts the donation.">
            <input id="contact" className="input" value={f.contact_info} onChange={(e) => set('contact_info', e.target.value)} required />
          </Field>
        </section>

        <Disclaimer />
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" className="mt-1" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
          I confirm the information is accurate and that this food is safe to eat and has been handled according to local food-safety rules.
        </label>
        <button className="btn btn-primary w-full py-3 sm:w-auto" disabled={busy || !confirmed}>{busy ? 'Posting and matching...' : 'Post donation'}</button>
      </div>
    </form>
  )
}
