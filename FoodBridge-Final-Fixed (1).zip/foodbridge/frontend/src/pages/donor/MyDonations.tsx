import { useState } from 'react'
import { Link } from 'react-router-dom'
import { PlusCircle } from 'lucide-react'
import { donationApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import { DonationCard } from '../../components/DonationList'
import { STATUS_LABELS } from '../../utils/format'

export default function MyDonations() {
  const [status, setStatus] = useState('')
  const { data, loading, error, reload } = useFetch(() => donationApi.list({ status }), [status])
  return (
    <div>
      <PageHeader title="My donations" actions={<Link to="/donor/donate" className="btn btn-primary"><PlusCircle size={18} /> Donate food</Link>} />
      <div className="mb-4 flex items-center gap-2">
        <label htmlFor="status-filter" className="text-sm text-mist-500">Status</label>
        <select id="status-filter" className="input max-w-[220px]" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> :
        !data || data.length === 0 ? <EmptyState title="Nothing here" text={status ? 'No donations with this status.' : 'You have not posted any donations yet.'} /> : (
          <div className="space-y-3">{data.map((d) => <DonationCard key={d.id} donation={d} to={`/donor/donations/${d.id}`} />)}</div>
        )}
    </div>
  )
}
