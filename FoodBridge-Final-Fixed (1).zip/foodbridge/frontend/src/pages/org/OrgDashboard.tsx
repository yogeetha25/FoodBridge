import { Link } from 'react-router-dom'
import { CheckCircle2, ClipboardList, Gift, Sparkles, Truck } from 'lucide-react'
import { donationApi, impactApi, orgApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { useAuth } from '../../hooks/useAuth'
import { Alert, ErrorState, PageHeader, Spinner, StatCard } from '../../components/ui'
import StatusBadge from '../../components/StatusBadge'
import { DonationCard } from '../../components/DonationList'
import ImpactPanel from '../../components/ImpactPanel'
import MapView from '../../components/MapView'

export default function OrgDashboard() {
  const { user, refresh } = useAuth()
  // Capacity and verification can change while this person is signed in (acceptances, an administrator's decision),
  // so ask the server for the current organization instead of trusting the copy fetched at login.
  const fresh = useFetch(async () => { const o = await orgApi.me(); await refresh(); return o }, [])
  const org = fresh.data ?? user!.organization!
  const verified = org.verification_status === 'VERIFIED'
  const stats = useFetch(async () => {
    if (!verified) return null
    const [available, recommended, accepted, pickups, completed] = await Promise.all(
      ['available', 'recommended', 'accepted', 'pickups', 'completed'].map((view) => donationApi.list({ view })))
    return { available, recommended, accepted, pickups, completed }
  }, [verified])
  const impact = useFetch(() => impactApi.organization(), [])

  if (!verified) {
    return (
      <div>
        <PageHeader title={org.name} subtitle="Organization dashboard" />
        <Alert kind={org.verification_status === 'REJECTED' ? 'error' : 'warning'} title={org.verification_status === 'REJECTED' ? 'Verification was not approved' : 'Waiting for verification'}>
          {org.verification_status === 'REJECTED'
            ? 'An administrator did not approve this organization. Please contact the FoodBridge administrators.'
            : 'An administrator needs to verify your organization before you can be matched with donations or accept them. You can review and update your details meanwhile.'}
          <div className="mt-3"><Link to="/org/profile" className="btn btn-secondary">Review my profile</Link></div>
        </Alert>
      </div>
    )
  }
  if (stats.loading) return <Spinner />
  if (stats.error) return <ErrorState message={stats.error} onRetry={stats.reload} />
  const s = stats.data!
  return (
    <div>
      <PageHeader title={org.name} subtitle="Organization dashboard" actions={<StatusBadge status={org.verification_status} />} />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Available nearby" value={s.available.length} icon={<Gift size={18} />} />
        <StatCard label="Recommended" value={s.recommended.length} icon={<Sparkles size={18} />} />
        <StatCard label="Accepted" value={s.accepted.length} icon={<ClipboardList size={18} />} />
        <StatCard label="Pickups in progress" value={s.pickups.length} icon={<Truck size={18} />} />
        <StatCard label="Completed" value={s.completed.length} icon={<CheckCircle2 size={18} />} />
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <div className="mb-3 flex items-center justify-between"><h2 className="text-xl font-bold">Top recommendations</h2><Link to="/org/recommended" className="btn btn-ghost">See all</Link></div>
          {s.recommended.length === 0 ? <Alert>No donations currently fit your organization. New ones appear here as donors post them.</Alert> : (
            <div className="space-y-3">{s.recommended.slice(0, 3).map((d) => <DonationCard key={d.id} donation={d} to={`/org/donations/${d.id}`} showDonor />)}</div>
          )}
        </div>
        <div className="lg:col-span-2">
          <h2 className="mb-3 text-xl font-bold">Your service area</h2>
          <MapView height={280} markers={[{ lat: org.latitude, lng: org.longitude, label: org.name, kind: 'org', radiusKm: org.service_radius_km, detail: `${org.service_radius_km} km radius` },
            ...s.available.map((d) => ({ lat: d.latitude, lng: d.longitude, label: d.title, kind: 'donation' as const, detail: `${d.distance_km} km away` }))]} />
          <p className="mt-2 text-sm text-mist-500">Committed capacity: {org.current_load_meals ?? 0} of {org.max_capacity_meals} meals.</p>
        </div>
      </div>

      {impact.data && <><h2 className="mb-3 mt-10 text-xl font-bold">Your impact</h2><ImpactPanel data={impact.data} /></>}
    </div>
  )
}
