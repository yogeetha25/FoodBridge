import { useState } from 'react'
import { Link } from 'react-router-dom'
import { donationApi } from '../../services/api'
import { useFetch } from '../../hooks/useFetch'
import { useAuth } from '../../hooks/useAuth'
import { Alert, EmptyState, ErrorState, PageHeader, Spinner } from '../../components/ui'
import { DonationCard } from '../../components/DonationList'
import { useToast } from '../../components/Toast'

export type OrgView = 'available' | 'recommended' | 'accepted' | 'pickups' | 'completed'

const COPY: Record<OrgView, { title: string; subtitle: string; empty: string }> = {
  recommended: { title: 'Recommended donations', subtitle: 'Donations your organization is eligible for, best match first.', empty: 'Nothing fits your organization right now. New donations appear as donors post them.' },
  available: { title: 'Available nearby', subtitle: 'Open donations inside your service area, nearest first. Ones you are not eligible for say why.', empty: 'No open donations inside your service area at the moment.' },
  accepted: { title: 'Accepted donations', subtitle: 'You accepted these. Schedule a pickup time to continue.', empty: 'You have no donations waiting for a pickup time.' },
  pickups: { title: 'Pickup management', subtitle: 'Donations with a scheduled pickup or already collected.', empty: 'No pickups in progress.' },
  completed: { title: 'Completed donations', subtitle: 'Your distribution history.', empty: 'No completed donations yet.' },
}

export default function OrgDonations({ view }: { view: OrgView }) {
  const { user } = useAuth()
  const toast = useToast()
  const verified = user!.organization?.verification_status === 'VERIFIED'
  const { data, loading, error, reload } = useFetch(() => (verified ? donationApi.list({ view }) : Promise.resolve([])), [view, verified])
  const [busyId, setBusyId] = useState<number | null>(null)
  const copy = COPY[view]

  if (!verified) return <Alert kind="warning" title="Verification required">You can see donations once an administrator verifies your organization.</Alert>

  const quickAccept = async (id: number) => {
    setBusyId(id)
    try { await donationApi.accept(id); toast('success', 'You accepted this donation. Schedule the pickup next.'); reload() }
    catch (e) { toast('error', e instanceof Error ? e.message : 'Could not accept.'); reload() }
    finally { setBusyId(null) }
  }

  return (
    <div>
      <PageHeader title={copy.title} subtitle={copy.subtitle} />
      {loading ? <Spinner /> : error ? <ErrorState message={error} onRetry={reload} /> :
        !data || data.length === 0 ? <EmptyState title="Nothing here" text={copy.empty} /> : (
          <div className="space-y-3">
            {data.map((d) => (
              <DonationCard key={d.id} donation={d} to={`/org/donations/${d.id}`} showDonor
                actions={<>
                  <Link className="btn btn-secondary" to={`/org/donations/${d.id}`}>{view === 'accepted' ? 'Schedule pickup' : view === 'pickups' ? 'Manage pickup' : 'View details'}</Link>
                  {d.my_match && ['available', 'recommended'].includes(view) && (
                    <button className="btn btn-primary" disabled={busyId === d.id} onClick={() => quickAccept(d.id)}>{busyId === d.id ? 'Accepting...' : 'Accept'}</button>
                  )}
                </>} />
            ))}
          </div>
        )}
    </div>
  )
}
