import { coordOr, inputToIso, numOrNull, quantityText, timeRemaining, toInputValue } from './format'
import { formToPayload, emptyOrgForm, orgToForm } from '../components/OrgForm'

describe('coordinate helpers', () => {
  it('blank text becomes null, never 0', () => {
    expect(numOrNull('')).toBeNull()
    expect(numOrNull('   ')).toBeNull()
    expect(numOrNull('12.5')).toBe(12.5)
    expect(numOrNull('0')).toBe(0)
  })
  it('coordOr falls back while the user is still typing', () => {
    expect(coordOr('', 7)).toBe(7)
    expect(coordOr('-', 7)).toBe(7)
    expect(coordOr('12.97', 7)).toBe(12.97)
  })
})

describe('organization form <-> payload', () => {
  it('a cleared latitude is sent as null (server reports an error) rather than 0', () => {
    expect(formToPayload({ ...emptyOrgForm, latitude: '' }).latitude).toBeNull()
  })
  it('round-trips an organization', () => {
    const form = orgToForm({ id: 1, name: 'Kitchen', organization_type: 'NGO', address: 'Somewhere road', latitude: 12.9, longitude: 77.6,
      service_radius_km: 12, max_capacity_meals: 300, preferred_categories: ['BAKERY'], food_preferences: 'VEG_ONLY',
      operating_hours: '08:00-22:00', verification_status: 'VERIFIED', contact_person: 'Lakshmi', phone: '99999' })
    const p = formToPayload(form)
    expect(p).toMatchObject({ latitude: 12.9, longitude: 77.6, service_radius_km: 12, max_capacity_meals: 300, operating_hours: '08:00-22:00' })
    expect(formToPayload({ ...form, always_open: true }).operating_hours).toBe('24/7')
  })
})

describe('time helpers', () => {
  it('timeRemaining formats minutes, hours and expiry', () => {
    const inMin = (m: number) => new Date(Date.now() + m * 60000 + 500).toISOString()
    expect(timeRemaining(inMin(-5)).text).toBe('Expired')
    expect(timeRemaining(inMin(30)).text).toBe('30 min left')
    expect(timeRemaining(inMin(125)).text).toBe('2 h 5 min left')
    expect(timeRemaining(inMin(60 * 26)).text).toBe('1 d 2 h left')
  })
  it('datetime-local value round-trips through ISO UTC', () => {
    const d = new Date(2026, 5, 15, 14, 30)
    expect(new Date(inputToIso(toInputValue(d))).getTime()).toBe(d.getTime())
  })
  it('quantityText uses unit labels', () => { expect(quantityText(45, 'PORTIONS')).toBe('45 portions') })
})
