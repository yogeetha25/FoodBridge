export const CATEGORY_LABELS: Record<string, string> = {
  COOKED_MEALS: 'Cooked meals', BAKERY: 'Bakery items', FRUITS_VEGETABLES: 'Fruits & vegetables',
  PACKAGED_FOOD: 'Packaged food', DAIRY: 'Dairy', BEVERAGES: 'Beverages', SNACKS: 'Snacks', OTHER: 'Other',
}
export const UNIT_LABELS: Record<string, string> = { MEALS: 'meals', KG: 'kg', PORTIONS: 'portions', PACKETS: 'packets', LITRES: 'litres' }
export const DONOR_TYPE_LABELS: Record<string, string> = {
  RESTAURANT: 'Restaurant', HOTEL: 'Hotel', CATERER: 'Caterer', COLLEGE_EVENT: 'College / event organizer',
  INDIVIDUAL: 'Individual', OTHER: 'Other organization',
}
export const ORG_TYPE_LABELS: Record<string, string> = {
  NGO: 'NGO', COMMUNITY_KITCHEN: 'Community kitchen', FOOD_DISTRIBUTION: 'Food-distribution group',
  SHELTER: 'Shelter', OTHER: 'Other',
}
export const FOOD_PREF_LABELS: Record<string, string> = {
  BOTH: 'Vegetarian and non-vegetarian', VEG_ONLY: 'Vegetarian only', NON_VEG_ONLY: 'Non-vegetarian only',
}
export const REPORT_REASON_LABELS: Record<string, string> = {
  FOOD_CONDITION: 'Food condition concern', INCORRECT_QUANTITY: 'Incorrect quantity',
  INCORRECT_INFORMATION: 'Incorrect information', PICKUP_PROBLEM: 'Pickup problem', OTHER: 'Other',
}
export const REPORT_STATUS_LABELS: Record<string, string> = {
  OPEN: 'Open', IN_REVIEW: 'In review', RESOLVED: 'Resolved', DISMISSED: 'Dismissed',
}
export const STATUS_LABELS: Record<string, string> = {
  AVAILABLE: 'Available', MATCHED: 'Matched', ACCEPTED: 'Accepted', PICKUP_PENDING: 'Pickup pending',
  COLLECTED: 'Collected', COMPLETED: 'Completed', CANCELLED: 'Cancelled', EXPIRED: 'Expired',
}
export const LIFECYCLE = ['AVAILABLE', 'MATCHED', 'ACCEPTED', 'PICKUP_PENDING', 'COLLECTED', 'COMPLETED'] as const

export const label = (map: Record<string, string>, key: string | null | undefined) => (key ? map[key] ?? key : '')

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return 'Not set'
  return new Date(iso).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })
}
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return 'Not set'
  return new Date(iso).toLocaleDateString('en-IN', { dateStyle: 'medium' })
}

/** Human readable "time left" plus the raw minutes (negative when already past). */
export function timeRemaining(iso: string): { text: string; minutes: number } {
  const minutes = Math.round((new Date(iso).getTime() - Date.now()) / 60000)
  if (minutes <= 0) return { text: 'Expired', minutes }
  if (minutes < 60) return { text: `${minutes} min left`, minutes }
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  if (h >= 24) return { text: `${Math.floor(h / 24)} d ${h % 24} h left`, minutes }
  return { text: m ? `${h} h ${m} min left` : `${h} h left`, minutes }
}

/** Value for <input type="datetime-local"> in the user's own timezone. */
export function toInputValue(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}
/** datetime-local string -> ISO UTC string for the API. */
export const inputToIso = (value: string) => new Date(value).toISOString()

export const quantityText = (qty: number, unit: string) => `${qty} ${UNIT_LABELS[unit] ?? unit.toLowerCase()}`

/** Text from a number input -> number for the API. Blank stays null (the server then reports a clear field error)
 *  instead of silently becoming 0, which would put the location in the Atlantic Ocean. */
export const numOrNull = (text: string): number | null => (text.trim() === '' ? null : Number(text))
/** Text from a coordinate input -> a usable number for the map, or a fallback while the user is still typing. */
export function coordOr(text: string, fallback: number): number {
  const n = Number(text)
  return text.trim() !== '' && Number.isFinite(n) ? n : fallback
}
