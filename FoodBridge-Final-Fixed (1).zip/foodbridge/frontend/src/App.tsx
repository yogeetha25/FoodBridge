import { lazy, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import PublicLayout from './layouts/PublicLayout'
import DashboardLayout from './layouts/DashboardLayout'
import ProtectedRoute from './components/ProtectedRoute'
import { Spinner } from './components/ui'
import Landing from './pages/public/Landing'

// Pages are loaded on demand so visitors only download the code for the screens they open.
const About = lazy(() => import('./pages/public/InfoPages').then((m) => ({ default: m.About })))
const HowItWorks = lazy(() => import('./pages/public/InfoPages').then((m) => ({ default: m.HowItWorks })))
const Login = lazy(() => import('./pages/public/Login'))
const Register = lazy(() => import('./pages/public/Register'))
const DonationDetail = lazy(() => import('./pages/DonationDetail'))
const Profile = lazy(() => import('./pages/Profile'))
const DonorDashboard = lazy(() => import('./pages/donor/DonorDashboard'))
const CreateDonation = lazy(() => import('./pages/donor/CreateDonation'))
const MyDonations = lazy(() => import('./pages/donor/MyDonations'))
const RecommendedOrgs = lazy(() => import('./pages/donor/RecommendedOrgs'))
const OrgDashboard = lazy(() => import('./pages/org/OrgDashboard'))
const OrgDonations = lazy(() => import('./pages/org/OrgDonations'))
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'))
const AdminUsers = lazy(() => import('./pages/admin/AdminUsers'))
const AdminOrganizations = lazy(() => import('./pages/admin/AdminOrganizations'))
const AdminDonations = lazy(() => import('./pages/admin/AdminDonations'))
const AdminReports = lazy(() => import('./pages/admin/AdminReports'))
const AdminAnalytics = lazy(() => import('./pages/admin/AdminAnalytics'))

export default function App() {
  return (
    <Suspense fallback={<Spinner />}>
    <Routes>
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/about" element={<About />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
      </Route>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route path="/donor" element={<ProtectedRoute role="DONOR" />}>
        <Route element={<DashboardLayout />}>
          <Route index element={<DonorDashboard />} />
          <Route path="donate" element={<CreateDonation />} />
          <Route path="donations" element={<MyDonations />} />
          <Route path="donations/:id" element={<DonationDetail />} />
          <Route path="matches" element={<RecommendedOrgs />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Route>

      <Route path="/org" element={<ProtectedRoute role="ORGANIZATION" />}>
        <Route element={<DashboardLayout />}>
          <Route index element={<OrgDashboard />} />
          <Route path="recommended" element={<OrgDonations view="recommended" />} />
          <Route path="available" element={<OrgDonations view="available" />} />
          <Route path="accepted" element={<OrgDonations view="accepted" />} />
          <Route path="pickups" element={<OrgDonations view="pickups" />} />
          <Route path="completed" element={<OrgDonations view="completed" />} />
          <Route path="donations/:id" element={<DonationDetail />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Route>

      <Route path="/admin" element={<ProtectedRoute role="ADMIN" />}>
        <Route element={<DashboardLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="organizations" element={<AdminOrganizations />} />
          <Route path="verification" element={<AdminOrganizations verification />} />
          <Route path="donations" element={<AdminDonations />} />
          <Route path="donations/:id" element={<DonationDetail />} />
          <Route path="reports" element={<AdminReports />} />
          <Route path="analytics" element={<AdminAnalytics />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    </Suspense>
  )
}
