export type Role = 'DONOR' | 'ORGANIZATION' | 'ADMIN'
export type DonationStatus =
  | 'AVAILABLE' | 'MATCHED' | 'ACCEPTED' | 'PICKUP_PENDING' | 'COLLECTED' | 'COMPLETED' | 'CANCELLED' | 'EXPIRED'
export type VerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED'

export interface Organization {
  id: number
  user_id?: number
  email?: string | null
  name: string
  organization_type: string
  contact_person?: string
  phone?: string
  address: string
  latitude: number
  longitude: number
  service_radius_km: number
  max_capacity_meals: number
  current_load_meals?: number
  preferred_categories: string[]
  food_preferences: string
  operating_hours: string
  verification_status: VerificationStatus
  created_at?: string
}

export interface User {
  id: number
  email: string
  role: Role
  full_name: string
  phone: string | null
  donor_type: string | null
  is_active: boolean
  created_at: string
  organization: Organization | null
}

export interface Reason { text: string; positive: boolean }
export interface Factor { label: string; score: number; weight: number; points: number; detail: string }
export interface ScoreBreakdown {
  total: number
  distance_km: number
  eta_minutes: number
  time_left_minutes: number
  routing: string
  weights: Record<string, number>
  factors: Record<string, Factor>
  reasons: Reason[]
}

export interface Pickup {
  id: number
  organization_id: number
  organization_name: string | null
  scheduled_at: string | null
  collected_at: string | null
  completed_at: string | null
  notes: string | null
}

export interface Donation {
  id: number
  donor_id: number
  donor_name: string | null
  title: string
  category: string
  is_vegetarian: boolean
  quantity: number
  unit: string
  estimated_meals: number
  prepared_at: string
  available_until: string
  pickup_address: string
  latitude: number
  longitude: number
  description: string | null
  handling_notes: string | null
  contact_info: string | null
  status: DonationStatus
  created_at: string
  accepted_by: { id: number; name: string } | null
  pickup: Pickup | null
  impact: { meals_redistributed: number; quantity_kg_est: number; people_served_est: number; created_at: string } | null
  match_count?: number | null
  top_match_score?: number | null
  distance_km?: number | null
  my_match?: { score: number; breakdown: ScoreBreakdown } | null
  ineligible_reason?: string | null
}

export interface Match {
  id: number
  donation_id: number
  organization_id: number
  organization: Organization
  score: number
  rank: number
  score_breakdown: ScoreBreakdown
  created_at: string
}

export interface ExcludedOrg { organization_id: number; organization_name: string; code: string; message: string }
export interface MatchesResponse {
  donation_id: number
  status: DonationStatus
  matches: Match[]
  excluded: ExcludedOrg[]
  weights: Record<string, number>
}

export interface Report {
  id: number
  donation_id: number
  donation_title: string | null
  reporter_id: number
  reporter_name: string | null
  reason: string
  details: string | null
  status: string
  resolved_by: number | null
  resolution_notes: string | null
  created_at: string
}

export interface TrendPoint { label: string; donations: number; completed: number; meals: number }
export interface ImpactTotals {
  total_donations: number
  active_donations: number
  completed_donations: number
  cancelled_donations: number
  expired_donations: number
  successful_matches: number
  meals_redistributed: number
  quantity_kg_est: number
  people_served_est: number
  active_donors?: number
  verified_organizations?: number
}
export interface ImpactData {
  totals: ImpactTotals
  weekly: TrendPoint[]
  monthly: TrendPoint[]
  assumptions: string[]
  is_estimate: boolean
}

export interface AdminDashboard {
  users_total: number
  donors_total: number
  organizations_total: number
  organizations_verified: number
  organizations_pending: number
  donations_total: number
  donations_active: number
  donations_completed: number
  donations_expired: number
  donations_cancelled: number
  meals_redistributed: number
  open_reports: number
  recent_donations: Donation[]
}

export interface AuthResponse { access_token: string; token_type: string; user: User }
