import { useState, type ReactNode } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  BarChart3, Building2, CheckCircle2, ClipboardList, FileWarning, Gift, Inbox, LayoutDashboard, ListChecks, LogOut,
  Menu, PlusCircle, ShieldCheck, Sparkles, Truck, User as UserIcon, Users, X,
} from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { Logo } from '../components/ui'
import StatusBadge from '../components/StatusBadge'

interface NavItem { to: string; text: string; icon: ReactNode; end?: boolean }

const NAV: Record<string, NavItem[]> = {
  DONOR: [
    { to: '/donor', text: 'Dashboard', icon: <LayoutDashboard size={18} />, end: true },
    { to: '/donor/donate', text: 'Donate food', icon: <PlusCircle size={18} /> },
    { to: '/donor/donations', text: 'My donations', icon: <ListChecks size={18} /> },
    { to: '/donor/matches', text: 'Recommended organizations', icon: <Sparkles size={18} /> },
    { to: '/donor/profile', text: 'Profile', icon: <UserIcon size={18} /> },
  ],
  ORGANIZATION: [
    { to: '/org', text: 'Dashboard', icon: <LayoutDashboard size={18} />, end: true },
    { to: '/org/recommended', text: 'Recommended', icon: <Sparkles size={18} /> },
    { to: '/org/available', text: 'Available nearby', icon: <Gift size={18} /> },
    { to: '/org/accepted', text: 'Accepted', icon: <ClipboardList size={18} /> },
    { to: '/org/pickups', text: 'Pickup management', icon: <Truck size={18} /> },
    { to: '/org/completed', text: 'Completed', icon: <CheckCircle2 size={18} /> },
    { to: '/org/profile', text: 'Organization profile', icon: <Building2 size={18} /> },
  ],
  ADMIN: [
    { to: '/admin', text: 'Dashboard', icon: <LayoutDashboard size={18} />, end: true },
    { to: '/admin/verification', text: 'Verification', icon: <ShieldCheck size={18} /> },
    { to: '/admin/organizations', text: 'Organizations', icon: <Building2 size={18} /> },
    { to: '/admin/users', text: 'Users', icon: <Users size={18} /> },
    { to: '/admin/donations', text: 'Donations', icon: <Inbox size={18} /> },
    { to: '/admin/reports', text: 'Reports', icon: <FileWarning size={18} /> },
    { to: '/admin/analytics', text: 'Impact analytics', icon: <BarChart3 size={18} /> },
  ],
}
const ROLE_NAME: Record<string, string> = { DONOR: 'Donor', ORGANIZATION: 'Organization', ADMIN: 'Administrator' }

export default function DashboardLayout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  if (!user) return null
  const items = NAV[user.role]

  const itemClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
      isActive ? 'bg-leaf-100 text-leaf-800' : 'text-mist-600 hover:bg-mist-100 hover:text-ink'}`

  const sidebar = (
    <div className="flex h-full flex-col">
      <Link to="/" className="px-5 py-5" aria-label="FoodBridge home"><Logo /></Link>
      <nav className="flex-1 space-y-1 overflow-y-auto px-3" onClick={() => setOpen(false)} aria-label="Main">
        {items.map((i) => <NavLink key={i.to} to={i.to} end={i.end} className={itemClass}>{i.icon}{i.text}</NavLink>)}
      </nav>
      <div className="border-t border-mist-200 p-4">
        <p className="truncate text-sm font-semibold">{user.organization?.name ?? user.full_name}</p>
        <p className="mb-2 text-xs text-mist-500">{ROLE_NAME[user.role]}</p>
        {user.organization && <div className="mb-3"><StatusBadge status={user.organization.verification_status} /></div>}
        <button className="btn btn-secondary w-full" onClick={() => { logout(); navigate('/') }}><LogOut size={16} /> Sign out</button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen lg:flex">
      <aside className="hidden w-64 shrink-0 border-r border-mist-200 bg-white lg:fixed lg:inset-y-0 lg:block">{sidebar}</aside>

      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-mist-200 bg-white px-4 py-3 lg:hidden">
        <Logo />
        <button aria-label="Open menu" className="rounded-md p-2 hover:bg-mist-100" onClick={() => setOpen(true)}><Menu /></button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl">
            <button aria-label="Close menu" className="absolute right-3 top-4 rounded-md p-1 hover:bg-mist-100" onClick={() => setOpen(false)}><X /></button>
            {sidebar}
          </aside>
        </div>
      )}

      <main className="min-w-0 flex-1 lg:pl-64">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:py-8"><Outlet /></div>
      </main>
    </div>
  )
}
