import { useState } from 'react'
import { Link, NavLink, Outlet } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import { homePathFor, useAuth } from '../hooks/useAuth'
import { Logo } from '../components/ui'

const links = [{ to: '/about', text: 'About' }, { to: '/how-it-works', text: 'How it works' }]

export default function PublicLayout() {
  const { user } = useAuth()
  const [open, setOpen] = useState(false)
  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-md px-3 py-2 text-sm font-medium ${isActive ? 'text-leaf-700' : 'text-mist-600 hover:text-ink'}`
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b border-mist-200 bg-paper/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to="/" aria-label="FoodBridge home"><Logo /></Link>
          <nav className="hidden items-center gap-1 md:flex">
            {links.map((l) => <NavLink key={l.to} to={l.to} className={linkClass}>{l.text}</NavLink>)}
            {user
              ? <Link className="btn btn-primary ml-2" to={homePathFor(user.role)}>Open dashboard</Link>
              : <>
                  <Link className="btn btn-ghost ml-2" to="/login">Sign in</Link>
                  <Link className="btn btn-primary" to="/register">Get started</Link>
                </>}
          </nav>
          <button className="rounded-md p-2 md:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
        </div>
        {open && (
          <div className="flex flex-col gap-1 border-t border-mist-200 bg-paper px-4 py-3 md:hidden" onClick={() => setOpen(false)}>
            {links.map((l) => <NavLink key={l.to} to={l.to} className={linkClass}>{l.text}</NavLink>)}
            {user
              ? <Link className="btn btn-primary" to={homePathFor(user.role)}>Open dashboard</Link>
              : <><Link className="btn btn-secondary" to="/login">Sign in</Link><Link className="btn btn-primary" to="/register">Get started</Link></>}
          </div>
        )}
      </header>
      <main className="flex-1"><Outlet /></main>
      <footer className="bg-leaf-900 text-leaf-100">
        <div className="mx-auto grid grid-cols-1 max-w-6xl gap-6 px-4 py-10 md:grid-cols-3">
          <div>
            <Logo light />
            <p className="mt-3 text-sm text-leaf-200">Connecting surplus food with people who need it.</p>
          </div>
          <p className="text-sm text-leaf-200 md:col-span-2">
            FoodBridge facilitates redistribution. It does not inspect food, guarantee food safety, or guarantee that every
            donation is collected. Donors are responsible for the accuracy of what they list and for following local food-safety rules.
            Impact figures are estimates based on documented assumptions.
          </p>
        </div>
      </footer>
    </div>
  )
}
