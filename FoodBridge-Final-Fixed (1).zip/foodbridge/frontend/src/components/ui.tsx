import type { ReactNode } from 'react'
import { AlertTriangle, CheckCircle2, Info, Loader2, ShieldAlert } from 'lucide-react'

export function Spinner({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-16 text-mist-500" role="status">
      <Loader2 className="animate-spin" size={20} /> <span className="text-sm">{label}...</span>
    </div>
  )
}

export function Alert({ kind = 'info', children, title }: { kind?: 'info' | 'error' | 'success' | 'warning'; children: ReactNode; title?: string }) {
  const styles = {
    info: 'border-leaf-200 bg-leaf-50 text-leaf-900',
    success: 'border-leaf-200 bg-leaf-50 text-leaf-900',
    warning: 'border-turmeric-300 bg-turmeric-50 text-ink',
    error: 'border-chilli-100 bg-chilli-50 text-chilli-600',
  }[kind]
  const Icon = kind === 'error' ? AlertTriangle : kind === 'success' ? CheckCircle2 : kind === 'warning' ? ShieldAlert : Info
  return (
    <div className={`flex gap-3 rounded-lg border px-4 py-3 text-sm ${styles}`} role={kind === 'error' ? 'alert' : undefined}>
      <Icon size={18} className="mt-0.5 shrink-0" />
      <div>{title && <p className="font-semibold">{title}</p>}<div>{children}</div></div>
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="space-y-3">
      <Alert kind="error" title="We could not load this">{message}</Alert>
      {onRetry && <button className="btn btn-secondary" onClick={onRetry}>Try again</button>}
    </div>
  )
}

export function EmptyState({ title, text, action, icon }: { title: string; text?: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      {icon && <div className="mb-3 text-leaf-600">{icon}</div>}
      <h3 className="text-lg font-bold">{title}</h3>
      {text && <p className="mt-1 max-w-md text-sm text-mist-500">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-mist-500">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  )
}

export function StatCard({ label, value, hint, icon }: { label: string; value: ReactNode; hint?: string; icon?: ReactNode }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between text-mist-500">
        <span className="text-sm">{label}</span>{icon}
      </div>
      <p className="mt-2 font-display text-3xl font-bold">{value}</p>
      {hint && <p className="mt-1 text-xs text-mist-500">{hint}</p>}
    </div>
  )
}

export function Field({ label, error, hint, children, htmlFor }: { label: string; error?: string; hint?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <div>
      <label className="label" htmlFor={htmlFor}>{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-mist-500">{hint}</p>}
      {error && <p className="mt-1 text-xs font-medium text-chilli-600" role="alert">{error}</p>}
    </div>
  )
}

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill={light ? '#F7BC1B' : '#1F6F4A'} />
        <path d="M5 21h22M8 21c0-6 3.6-10 8-10s8 4 8 10M16 11V7" stroke={light ? '#12261F' : '#fff'} strokeWidth="2.2" strokeLinecap="round" fill="none" />
      </svg>
      <span className={`font-display text-xl font-bold ${light ? 'text-white' : 'text-ink'}`}>FoodBridge</span>
    </span>
  )
}
