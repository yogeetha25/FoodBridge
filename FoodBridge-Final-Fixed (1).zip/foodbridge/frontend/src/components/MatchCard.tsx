import type { ReactNode } from 'react'
import { Check, Minus } from 'lucide-react'
import type { Match, ScoreBreakdown } from '../types'
import { FOOD_PREF_LABELS, label, ORG_TYPE_LABELS } from '../utils/format'

/** Score "ticket": big percentage on the stub, the reasons on the right. */
export function ScoreTicket({ score, breakdown, title, subtitle, rank, action, showFactors = true }: {
  score: number; breakdown: ScoreBreakdown; title?: string; subtitle?: string; rank?: number
  action?: ReactNode; showFactors?: boolean
}) {
  const tone = score >= 80 ? '#1F6F4A' : score >= 60 ? '#2F8450' : score >= 40 ? '#B88400' : '#B3351F'
  return (
    <div className="ticket">
      <div className="ticket-stub" style={{ background: tone }}>
        {rank !== undefined && <span className="mb-1 text-xs opacity-80">Rank {rank}</span>}
        <span className="font-display text-4xl font-bold leading-none">{Math.round(score)}%</span>
        <span className="mt-1 text-xs opacity-90">match</span>
      </div>
      <div className="ticket-perf" aria-hidden="true" />
      <div className="min-w-0 flex-1 p-4">
        {title && <h3 className="truncate text-lg font-bold">{title}</h3>}
        {subtitle && <p className="text-sm text-mist-500">{subtitle}</p>}
        <ul className={`${title ? 'mt-3' : ''} space-y-1.5 text-sm`}>
          {breakdown.reasons.map((r, i) => (
            <li key={i} className="flex items-start gap-2">
              {r.positive
                ? <Check size={16} className="mt-0.5 shrink-0 text-leaf-600" aria-label="Good" />
                : <Minus size={16} className="mt-0.5 shrink-0 text-turmeric-600" aria-label="Weaker" />}
              <span>{r.text}</span>
            </li>
          ))}
        </ul>
        {showFactors && (
          <details className="mt-3 text-sm">
            <summary className="cursor-pointer font-medium text-leaf-700">How this score was calculated</summary>
            <table className="mt-2 w-full text-xs">
              <thead><tr className="text-left text-mist-500"><th className="py-1">Factor</th><th>Score</th><th>Weight</th><th className="text-right">Points</th></tr></thead>
              <tbody>
                {Object.values(breakdown.factors).map((f) => (
                  <tr key={f.label} className="border-t border-mist-100">
                    <td className="py-1">{f.label}</td>
                    <td>{Math.round(f.score * 100)}%</td>
                    <td>{Math.round(f.weight * 100)}%</td>
                    <td className="text-right font-medium">{f.points}</td>
                  </tr>
                ))}
                <tr className="border-t border-mist-200 font-semibold"><td className="py-1" colSpan={3}>Total</td><td className="text-right">{breakdown.total}</td></tr>
              </tbody>
            </table>
            <p className="mt-1 text-xs text-mist-500">
              Distance by {breakdown.routing === 'osrm' ? 'road (OSRM)' : 'straight line (Haversine)'}; about {breakdown.eta_minutes} min
              to arrive, {breakdown.time_left_minutes} min left.
            </p>
          </details>
        )}
        {action && <div className="mt-3">{action}</div>}
      </div>
    </div>
  )
}

export default function MatchCard({ match, action }: { match: Match; action?: ReactNode }) {
  const o = match.organization
  return (
    <ScoreTicket
      score={match.score}
      breakdown={match.score_breakdown}
      rank={match.rank}
      title={o.name}
      subtitle={`${label(ORG_TYPE_LABELS, o.organization_type)}. ${label(FOOD_PREF_LABELS, o.food_preferences)}. Open ${o.operating_hours}`}
      action={action}
    />
  )
}
