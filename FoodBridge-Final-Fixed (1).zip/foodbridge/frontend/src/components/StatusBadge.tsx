import { STATUS_LABELS } from '../utils/format'

const STYLES: Record<string, string> = {
  AVAILABLE: 'bg-turmeric-100 text-turmeric-600',
  MATCHED: 'bg-sky-100 text-sky-800',
  ACCEPTED: 'bg-leaf-100 text-leaf-800',
  PICKUP_PENDING: 'bg-indigo-100 text-indigo-800',
  COLLECTED: 'bg-teal-100 text-teal-800',
  COMPLETED: 'bg-leaf-600 text-white',
  CANCELLED: 'bg-mist-100 text-mist-600',
  EXPIRED: 'bg-chilli-100 text-chilli-600',
  // organization verification
  PENDING: 'bg-turmeric-100 text-turmeric-600',
  VERIFIED: 'bg-leaf-600 text-white',
  REJECTED: 'bg-chilli-100 text-chilli-600',
  // reports
  OPEN: 'bg-chilli-100 text-chilli-600',
  IN_REVIEW: 'bg-turmeric-100 text-turmeric-600',
  RESOLVED: 'bg-leaf-100 text-leaf-800',
  DISMISSED: 'bg-mist-100 text-mist-600',
}
const EXTRA_LABELS: Record<string, string> = {
  PENDING: 'Pending verification', VERIFIED: 'Verified', REJECTED: 'Rejected',
  OPEN: 'Open', IN_REVIEW: 'In review', RESOLVED: 'Resolved', DISMISSED: 'Dismissed',
}

export default function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${STYLES[status] ?? 'bg-mist-100 text-mist-600'}`}>
      {STATUS_LABELS[status] ?? EXTRA_LABELS[status] ?? status}
    </span>
  )
}
