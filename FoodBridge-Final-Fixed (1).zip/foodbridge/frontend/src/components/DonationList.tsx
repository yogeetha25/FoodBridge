import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { Clock, MapPin, Leaf, Drumstick } from 'lucide-react'
import type { Donation } from '../types'
import StatusBadge from './StatusBadge'
import { CATEGORY_LABELS, formatDateTime, label, quantityText, timeRemaining } from '../utils/format'

const OPEN = ['AVAILABLE', 'MATCHED', 'ACCEPTED']

export function DonationCard({ donation, to, showDonor = false, actions }: {
  donation: Donation; to: string; showDonor?: boolean; actions?: ReactNode
}) {
  const left = timeRemaining(donation.available_until)
  const urgent = OPEN.includes(donation.status) && left.minutes > 0 && left.minutes <= 60
  return (
    <div className="card p-4 transition-shadow hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <Link to={to} className="min-w-0 flex-1">
          <h3 className="truncate text-lg font-bold hover:text-leaf-700">{donation.title}</h3>
          {showDonor && <p className="text-sm text-mist-500">from {donation.donor_name}</p>}
        </Link>
        <StatusBadge status={donation.status} />
      </div>
      <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 text-sm text-mist-600">
        <span className="font-semibold text-ink">{quantityText(donation.quantity, donation.unit)} ({donation.estimated_meals} meals)</span>
        <span>{label(CATEGORY_LABELS, donation.category)}</span>
        <span className="inline-flex items-center gap-1">
          {donation.is_vegetarian ? <Leaf size={14} className="text-leaf-600" /> : <Drumstick size={14} className="text-chilli-600" />}
          {donation.is_vegetarian ? 'Vegetarian' : 'Non-vegetarian'}
        </span>
        {donation.distance_km != null && <span className="inline-flex items-center gap-1"><MapPin size={14} />{donation.distance_km} km away</span>}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-1 text-sm">
        {OPEN.includes(donation.status) ? (
          <span className={`inline-flex items-center gap-1 font-medium ${urgent ? 'text-chilli-600' : 'text-mist-600'}`}>
            <Clock size={14} /> {left.text}
          </span>
        ) : <span className="text-mist-500">Posted {formatDateTime(donation.created_at)}</span>}
        {donation.my_match && (
          <span className="rounded-full bg-leaf-100 px-2.5 py-0.5 text-xs font-semibold text-leaf-800">{Math.round(donation.my_match.score)}% match</span>
        )}
        {donation.match_count != null && ['AVAILABLE', 'MATCHED'].includes(donation.status) && (
          <span className="text-mist-500">
            {donation.match_count > 0 ? `${donation.match_count} matching organization${donation.match_count === 1 ? '' : 's'}, best ${Math.round(donation.top_match_score ?? 0)}%` : 'No eligible organization yet'}
          </span>
        )}
        {donation.accepted_by && <span className="text-mist-600">Accepted by <strong>{donation.accepted_by.name}</strong></span>}
      </div>
      {donation.ineligible_reason && <p className="mt-2 text-xs text-mist-500">Not eligible for your organization: {donation.ineligible_reason}</p>}
      {actions && <div className="mt-3 flex flex-wrap gap-2">{actions}</div>}
    </div>
  )
}
