import { ShieldAlert } from 'lucide-react'

/** Food-safety responsibility notice. FoodBridge never claims to guarantee food safety. */
export default function Disclaimer({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex gap-3 rounded-lg border border-turmeric-300 bg-turmeric-50 px-4 py-3 text-sm">
      <ShieldAlert size={18} className="mt-0.5 shrink-0 text-turmeric-600" />
      <p>
        <strong>Donors are responsible for accurate information.</strong>{' '}
        {compact
          ? 'FoodBridge does not inspect food or guarantee its safety.'
          : 'FoodBridge connects donors and organizations but does not inspect food or guarantee that it is safe. Only donate food that is safe to eat and follow local food-safety rules for handling, storage and transport.'}
      </p>
    </div>
  )
}
