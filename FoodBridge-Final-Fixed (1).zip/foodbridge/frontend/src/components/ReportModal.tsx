import { useState } from 'react'
import Modal from './Modal'
import { Alert, Field } from './ui'
import { reportApi } from '../services/api'
import { REPORT_REASON_LABELS } from '../utils/format'
import { useToast } from './Toast'

export default function ReportModal({ donationId, onClose }: { donationId: number; onClose: () => void }) {
  const toast = useToast()
  const [reason, setReason] = useState('PICKUP_PROBLEM')
  const [details, setDetails] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async () => {
    setBusy(true); setError(null)
    try {
      await reportApi.create({ donation_id: donationId, reason, details: details || undefined })
      toast('success', 'Report sent to the administrators.')
      onClose()
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not send the report.') }
    finally { setBusy(false) }
  }

  return (
    <Modal title="Report a problem" onClose={onClose}
      footer={<>
        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={submit} disabled={busy}>{busy ? 'Sending...' : 'Send report'}</button>
      </>}>
      <div className="space-y-4">
        {error && <Alert kind="error">{error}</Alert>}
        <Field label="What went wrong?" htmlFor="reason">
          <select id="reason" className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
            {Object.entries(REPORT_REASON_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Details" htmlFor="details" hint={reason === 'OTHER' ? 'Required for "Other".' : 'Optional, but helpful.'}>
          <textarea id="details" className="input min-h-[96px]" value={details} onChange={(e) => setDetails(e.target.value)} maxLength={2000} />
        </Field>
      </div>
    </Modal>
  )
}
