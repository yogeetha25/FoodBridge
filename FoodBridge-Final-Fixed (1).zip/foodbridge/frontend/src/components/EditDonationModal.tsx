import { useState, type FormEvent } from 'react'
import Modal from './Modal'
import { Alert, Field } from './ui'
import { LocationPicker } from './MapView'
import { ApiError, donationApi } from '../services/api'
import type { Donation } from '../types'
import { CATEGORY_LABELS, coordOr, inputToIso, numOrNull, toInputValue, UNIT_LABELS } from '../utils/format'

/** Edit a donation that is still waiting for an organization (AVAILABLE / MATCHED). The server re-validates
 *  everything and re-runs the matching, so the ranked organizations update after saving. */
export default function EditDonationModal({ donation, onClose, onSaved }: {
  donation: Donation; onClose: () => void; onSaved: (d: Donation) => void
}) {
  const [f, setF] = useState({
    title: donation.title, category: donation.category, is_vegetarian: donation.is_vegetarian,
    quantity: String(donation.quantity), unit: donation.unit, estimated_meals: String(donation.estimated_meals),
    prepared_at: toInputValue(new Date(donation.prepared_at)), available_until: toInputValue(new Date(donation.available_until)),
    pickup_address: donation.pickup_address, latitude: String(donation.latitude), longitude: String(donation.longitude),
    description: donation.description ?? '', handling_notes: donation.handling_notes ?? '', contact_info: donation.contact_info ?? '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const set = (k: string, v: string | boolean) => setF((p) => ({ ...p, [k]: v }))

  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    const local: Record<string, string> = {}
    if (!(Number(f.quantity) > 0)) local.quantity = 'Enter a quantity above 0'
    if (!(Number(f.estimated_meals) >= 1)) local.estimated_meals = 'Enter at least 1 meal'
    if (numOrNull(f.latitude) === null || !(Math.abs(Number(f.latitude)) <= 90)) local.latitude = 'Enter a latitude between -90 and 90'
    if (numOrNull(f.longitude) === null || !(Math.abs(Number(f.longitude)) <= 180)) local.longitude = 'Enter a longitude between -180 and 180'
    if (!f.prepared_at || !f.available_until) local.available_until = 'Choose both times'
    else if (new Date(f.available_until).getTime() <= Date.now()) local.available_until = 'Must be in the future'
    else if (new Date(f.prepared_at).getTime() >= new Date(f.available_until).getTime()) local.prepared_at = 'Must be before the available-until time'
    setErrors(local); setError(null)
    if (Object.keys(local).length) return

    setBusy(true)
    try {
      const updated = await donationApi.update(donation.id, {
        title: f.title, category: f.category, is_vegetarian: f.is_vegetarian, quantity: Number(f.quantity), unit: f.unit,
        estimated_meals: Math.round(Number(f.estimated_meals)), prepared_at: inputToIso(f.prepared_at),
        available_until: inputToIso(f.available_until), pickup_address: f.pickup_address,
        latitude: Number(f.latitude), longitude: Number(f.longitude),
        description: f.description || null, handling_notes: f.handling_notes || null, contact_info: f.contact_info,
      })
      onSaved(updated)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save the changes.')
      if (e instanceof ApiError) setErrors(e.fieldErrors)
    } finally { setBusy(false) }
  }

  return (
    <Modal title="Edit donation" onClose={onClose}
      footer={<>
        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button type="submit" form="edit-donation-form" className="btn btn-primary" disabled={busy}>{busy ? 'Saving and re-matching...' : 'Save changes'}</button>
      </>}>
      <form id="edit-donation-form" onSubmit={submit} noValidate className="space-y-4">
        <p className="text-sm text-mist-600">You can edit a donation until an organization accepts it. Matches are recalculated when you save.</p>
        {error && <Alert kind="error">{error}</Alert>}
        <Field label="Food name" htmlFor="e-title" error={errors.title}>
          <input id="e-title" className="input" value={f.title} onChange={(e) => set('title', e.target.value)} />
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Category" htmlFor="e-category" error={errors.category}>
            <select id="e-category" className="input" value={f.category} onChange={(e) => set('category', e.target.value)}>
              {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Field>
          <Field label="Diet">
            <div className="flex gap-2" role="radiogroup" aria-label="Diet">
              {[[true, 'Vegetarian'], [false, 'Non-vegetarian']].map(([v, text]) => (
                <button type="button" key={String(v)} role="radio" aria-checked={f.is_vegetarian === v}
                  onClick={() => set('is_vegetarian', v as boolean)}
                  className={`flex-1 rounded-lg border px-3 py-2 text-sm font-medium ${f.is_vegetarian === v ? 'border-leaf-600 bg-leaf-100 text-leaf-800' : 'border-mist-200 bg-white'}`}>
                  {text as string}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Quantity" htmlFor="e-qty" error={errors.quantity}>
            <input id="e-qty" type="number" min="0" step="any" className="input" value={f.quantity} onChange={(e) => set('quantity', e.target.value)} />
          </Field>
          <Field label="Unit" htmlFor="e-unit" error={errors.unit}>
            <select id="e-unit" className="input" value={f.unit} onChange={(e) => set('unit', e.target.value)}>
              {Object.entries(UNIT_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Field>
        </div>
        <Field label="Estimated number of meals" htmlFor="e-meals" error={errors.estimated_meals}>
          <input id="e-meals" type="number" min="1" className="input max-w-[200px]" value={f.estimated_meals} onChange={(e) => set('estimated_meals', e.target.value)} />
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Prepared / available from" htmlFor="e-prep" error={errors.prepared_at}>
            <input id="e-prep" type="datetime-local" className="input" value={f.prepared_at} onChange={(e) => set('prepared_at', e.target.value)} />
          </Field>
          <Field label="Available until" htmlFor="e-until" error={errors.available_until}>
            <input id="e-until" type="datetime-local" className="input" value={f.available_until} onChange={(e) => set('available_until', e.target.value)} />
          </Field>
        </div>
        <Field label="Pickup address" htmlFor="e-address" error={errors.pickup_address}>
          <input id="e-address" className="input" value={f.pickup_address} onChange={(e) => set('pickup_address', e.target.value)} />
        </Field>
        <LocationPicker lat={coordOr(f.latitude, NaN)} lng={coordOr(f.longitude, NaN)}
          onChange={(la, lo) => setF((p) => ({ ...p, latitude: String(la), longitude: String(lo) }))} />
        <div className="grid grid-cols-2 gap-4">
          <Field label="Latitude" htmlFor="e-lat" error={errors.latitude}>
            <input id="e-lat" type="number" step="any" className="input" value={f.latitude} onChange={(e) => set('latitude', e.target.value)} />
          </Field>
          <Field label="Longitude" htmlFor="e-lng" error={errors.longitude}>
            <input id="e-lng" type="number" step="any" className="input" value={f.longitude} onChange={(e) => set('longitude', e.target.value)} />
          </Field>
        </div>
        <Field label="Contact for pickup" htmlFor="e-contact" error={errors.contact_info}>
          <input id="e-contact" className="input" value={f.contact_info} onChange={(e) => set('contact_info', e.target.value)} />
        </Field>
        <Field label="Description (optional)" htmlFor="e-desc" error={errors.description}>
          <textarea id="e-desc" className="input min-h-[72px]" value={f.description} maxLength={1000} onChange={(e) => set('description', e.target.value)} />
        </Field>
        <Field label="Special handling (optional)" htmlFor="e-notes" error={errors.handling_notes}>
          <textarea id="e-notes" className="input min-h-[56px]" value={f.handling_notes} maxLength={1000} onChange={(e) => set('handling_notes', e.target.value)} />
        </Field>
      </form>
    </Modal>
  )
}
