import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import EditDonationModal from './EditDonationModal'
import { ApiError, donationApi } from '../services/api'
import type { Donation } from '../types'

// Leaflet needs a real browser layout; the map is not what is under test here.
vi.mock('./MapView', () => ({ LocationPicker: () => <div data-testid="map" /> }))

const future = (h: number) => new Date(Date.now() + h * 3600000).toISOString()
const donation: Donation = {
  id: 7, donor_id: 1, donor_name: 'Asha', title: 'Veg biryani', category: 'COOKED_MEALS', is_vegetarian: true, quantity: 50, unit: 'MEALS',
  estimated_meals: 50, prepared_at: future(-0.5), available_until: future(3), pickup_address: 'ABC College, Koramangala',
  latitude: 12.9352, longitude: 77.6245, description: null, handling_notes: null, contact_info: 'Asha 99999', status: 'MATCHED',
  created_at: future(-1), accepted_by: null, pickup: null, impact: null,
}

afterEach(() => vi.restoreAllMocks())

describe('EditDonationModal', () => {
  it('is pre-filled with the donation and saves changed values through the API', async () => {
    const updated = { ...donation, title: 'Veg biryani and raita', estimated_meals: 60 }
    const spy = vi.spyOn(donationApi, 'update').mockResolvedValue(updated)
    const onSaved = vi.fn()
    render(<EditDonationModal donation={donation} onClose={() => {}} onSaved={onSaved} />)

    const title = screen.getByLabelText('Food name') as HTMLInputElement
    expect(title.value).toBe('Veg biryani')
    await userEvent.clear(title); await userEvent.type(title, 'Veg biryani and raita')
    const meals = screen.getByLabelText('Estimated number of meals')
    await userEvent.clear(meals); await userEvent.type(meals, '60')
    await userEvent.click(screen.getByRole('button', { name: /save changes/i }))

    await waitFor(() => expect(onSaved).toHaveBeenCalledWith(updated))
    const [id, payload] = spy.mock.calls[0] as [number, Record<string, unknown>]
    expect(id).toBe(7)
    expect(payload).toMatchObject({ title: 'Veg biryani and raita', estimated_meals: 60, quantity: 50, latitude: 12.9352, longitude: 77.6245 })
  })

  it('blocks a cleared latitude instead of silently sending 0', async () => {
    const spy = vi.spyOn(donationApi, 'update')
    render(<EditDonationModal donation={donation} onClose={() => {}} onSaved={() => {}} />)
    await userEvent.clear(screen.getByLabelText('Latitude'))
    await userEvent.click(screen.getByRole('button', { name: /save changes/i }))
    expect(await screen.findByText(/latitude between -90 and 90/i)).toBeTruthy()
    expect(spy).not.toHaveBeenCalled()
  })

  it('blocks an available-until time in the past', async () => {
    const spy = vi.spyOn(donationApi, 'update')
    render(<EditDonationModal donation={{ ...donation, available_until: future(-1) }} onClose={() => {}} onSaved={() => {}} />)
    await userEvent.click(screen.getByRole('button', { name: /save changes/i }))
    expect(await screen.findByText('Must be in the future')).toBeTruthy()
    expect(spy).not.toHaveBeenCalled()
  })

  it('shows the server message (e.g. donation was just accepted) and stays open', async () => {
    vi.spyOn(donationApi, 'update').mockRejectedValue(new ApiError('This donation can no longer be changed because its status just changed.', 409, 'concurrent_update'))
    const onSaved = vi.fn()
    render(<EditDonationModal donation={donation} onClose={() => {}} onSaved={onSaved} />)
    await userEvent.click(screen.getByRole('button', { name: /save changes/i }))
    expect(await screen.findByText(/can no longer be changed/i)).toBeTruthy()
    expect(onSaved).not.toHaveBeenCalled()
  })
})
