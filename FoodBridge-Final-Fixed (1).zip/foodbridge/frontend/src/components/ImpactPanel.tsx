import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Utensils, Package, Users, Scale, Handshake, HeartHandshake } from 'lucide-react'
import type { ImpactData } from '../types'
import { Alert, StatCard } from './ui'

/** Totals + trend charts. Every figure is an estimate, and the assumptions are listed. */
export default function ImpactPanel({ data, platform = false }: { data: ImpactData; platform?: boolean }) {
  const t = data.totals
  const empty = t.total_donations === 0
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <StatCard label="Total donations" value={t.total_donations} icon={<Package size={18} />} />
        <StatCard label="Completed" value={t.completed_donations} hint={`${t.successful_matches} accepted by an organization`} icon={<Handshake size={18} />} />
        <StatCard label="Meals redistributed (est.)" value={t.meals_redistributed.toLocaleString('en-IN')} icon={<Utensils size={18} />} />
        <StatCard label="Food quantity (est.)" value={`${t.quantity_kg_est.toLocaleString('en-IN')} kg`} icon={<Scale size={18} />} />
        <StatCard label="People served (est.)" value={t.people_served_est.toLocaleString('en-IN')} icon={<Users size={18} />} />
        {platform
          ? <StatCard label="Active donors (30 days)" value={t.active_donors ?? 0} hint={`${t.verified_organizations ?? 0} verified organizations`} icon={<HeartHandshake size={18} />} />
          : <StatCard label="Still active" value={t.active_donations} hint={`${t.cancelled_donations} cancelled, ${t.expired_donations} expired`} />}
      </div>

      {empty ? (
        <Alert>No donations yet, so there are no trends to show. Charts appear after the first donation.</Alert>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div className="card p-4">
            <h3 className="mb-3 font-bold">Meals redistributed per week (est.)</h3>
            <div style={{ height: 240 }}>
              <ResponsiveContainer>
                <BarChart data={data.weekly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E9EFE8" />
                  <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="meals" name="Meals" fill="#1F6F4A" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="card p-4">
            <h3 className="mb-3 font-bold">Donations per month</h3>
            <div style={{ height: 240 }}>
              <ResponsiveContainer>
                <LineChart data={data.monthly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E9EFE8" />
                  <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip /><Legend />
                  <Line type="monotone" dataKey="donations" name="Posted" stroke="#E8A800" strokeWidth={2} />
                  <Line type="monotone" dataKey="completed" name="Completed" stroke="#1F6F4A" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      <details className="card p-4 text-sm">
        <summary className="cursor-pointer font-semibold">How these estimates are calculated</summary>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-mist-600">
          {data.assumptions.map((a, i) => <li key={i}>{a}</li>)}
        </ul>
      </details>
    </div>
  )
}
