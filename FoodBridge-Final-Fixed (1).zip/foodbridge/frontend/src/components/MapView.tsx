import { Fragment, useEffect, useMemo, useState } from 'react'
import L from 'leaflet'
import { Circle, MapContainer, Marker, Popup, TileLayer, useMap, useMapEvents } from 'react-leaflet'

export interface MapMarker {
  lat: number
  lng: number
  label: string
  kind: 'donation' | 'org' | 'top'
  detail?: string
  radiusKm?: number
}

const COLORS = { donation: '#E8A800', org: '#1F6F4A', top: '#12261F' }

// Custom DOM icons avoid the classic bundler problem with Leaflet's default marker images.
function pin(kind: MapMarker['kind']) {
  return L.divIcon({
    className: '',
    html: `<span style="display:block;width:22px;height:22px;border-radius:50% 50% 50% 0;background:${COLORS[kind]};border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45);transform:rotate(-45deg)"></span>`,
    iconSize: [22, 22],
    iconAnchor: [11, 22],
    popupAnchor: [0, -22],
  })
}

const isCoord = (lat: number, lng: number) =>
  Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180

function FitBounds({ markers }: { markers: MapMarker[] }) {
  const map = useMap()
  // Parents rebuild the `markers` array on every render. Depend on the POSITIONS only, otherwise the map jumps
  // back (losing the user's pan/zoom) every time anything on the page re-renders, e.g. typing in a text box.
  const signature = markers.map((m) => `${m.lat},${m.lng}`).join('|')
  useEffect(() => {
    const points = signature ? signature.split('|').map((p) => p.split(',').map(Number) as [number, number]) : []
    if (points.length > 1) map.fitBounds(points, { padding: [40, 40], maxZoom: 15, animate: false })   // no animation: it could outlive an unmounted map
    else if (points.length === 1) map.setView(points[0], 14, { animate: false })
  }, [signature, map])
  return null
}

export default function MapView({ markers: all, height = 320 }: { markers: MapMarker[]; height?: number }) {
  const markers = all.filter((m) => isCoord(m.lat, m.lng))      // never hand Leaflet an invalid position
  const first = markers[0] ?? { lat: 12.9716, lng: 77.5946 }
  return (
    <div style={{ height }} className="overflow-hidden rounded-xl border border-mist-200">
      <MapContainer center={[first.lat, first.lng]} zoom={13} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <FitBounds markers={markers} />
        {markers.map((m, i) => (
          <Fragment key={`${m.lat},${m.lng},${i}`}>
            <Marker position={[m.lat, m.lng]} icon={pin(m.kind)}>
              <Popup><strong>{m.label}</strong>{m.detail && <><br />{m.detail}</>}</Popup>
            </Marker>
            {m.radiusKm ? <Circle center={[m.lat, m.lng]} radius={m.radiusKm * 1000} pathOptions={{ color: COLORS.org, weight: 1, fillOpacity: 0.05 }} /> : null}
          </Fragment>
        ))}
      </MapContainer>
    </div>
  )
}

function ClickHandler({ onPick }: { onPick: (lat: number, lng: number) => void }) {
  useMapEvents({ click: (e) => onPick(Number(e.latlng.lat.toFixed(5)), Number(e.latlng.lng.toFixed(5))) })
  return null
}

function Recenter({ lat, lng }: { lat: number; lng: number }) {
  const map = useMap()
  useEffect(() => { map.setView([lat, lng], map.getZoom(), { animate: false }) }, [lat, lng, map])
  return null
}

/** Click on the map (or use the device location) to choose latitude/longitude. */
export function LocationPicker({ lat, lng, onChange, kind = 'donation' }: {
  lat: number; lng: number; onChange: (lat: number, lng: number) => void; kind?: MapMarker['kind']
}) {
  const [locateError, setLocateError] = useState<string | null>(null)
  const valid = isCoord(lat, lng)
  const center = useMemo<[number, number]>(() => (valid ? [lat, lng] : [12.9716, 77.5946]), [valid, lat, lng])
  const locate = () => {
    setLocateError(null)
    if (!navigator.geolocation) { setLocateError('This browser cannot share its location. Click the map instead.'); return }
    navigator.geolocation.getCurrentPosition(
      (p) => onChange(Number(p.coords.latitude.toFixed(5)), Number(p.coords.longitude.toFixed(5))),
      (err) => setLocateError(err.code === err.PERMISSION_DENIED
        ? 'Location access was blocked. Allow it in your browser settings, or click the map instead.'
        : 'Could not get your location. Click the map instead.'),
      { enableHighAccuracy: false, timeout: 10_000 })
  }
  return (
    <div>
      <div style={{ height: 240 }} className="overflow-hidden rounded-xl border border-mist-200">
        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
          <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <ClickHandler onPick={onChange} />
          {valid && <Recenter lat={lat} lng={lng} />}
          {valid && <Marker position={[lat, lng]} icon={pin(kind)} />}
        </MapContainer>
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-mist-500">
        <span>Click the map to set the location, or type the coordinates below.</span>
        <button type="button" className="btn btn-ghost px-2 py-1 text-xs" onClick={locate}>Use my current location</button>
      </div>
      {locateError && <p className="mt-1 text-xs font-medium text-chilli-600" role="alert">{locateError}</p>}
    </div>
  )
}
