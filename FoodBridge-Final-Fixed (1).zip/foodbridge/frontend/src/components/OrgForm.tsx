import type { Organization } from '../types'
import { CATEGORY_LABELS, coordOr, FOOD_PREF_LABELS, numOrNull, ORG_TYPE_LABELS } from '../utils/format'
import { Field } from './ui'
import { LocationPicker } from './MapView'

/** Form state for organization details. Used by Register and by the organization Profile page. */
export interface OrgFormState {
  name: string; organization_type: string; contact_person: string; phone: string; address: string
  latitude: string; longitude: string; service_radius_km: string; max_capacity_meals: string
  preferred_categories: string[]; food_preferences: string
  always_open: boolean; open_time: string; close_time: string
}

export const emptyOrgForm: OrgFormState = {
  name: '', organization_type: 'NGO', contact_person: '', phone: '', address: '',
  latitude: '12.9716', longitude: '77.5946', service_radius_km: '10', max_capacity_meals: '200',
  preferred_categories: [], food_preferences: 'BOTH', always_open: false, open_time: '09:00', close_time: '18:00',
}

export function orgToForm(o: Organization): OrgFormState {
  const m = /^(\d\d:\d\d)-(\d\d:\d\d)$/.exec(o.operating_hours)
  return {
    name: o.name, organization_type: o.organization_type, contact_person: o.contact_person ?? '', phone: o.phone ?? '',
    address: o.address, latitude: String(o.latitude), longitude: String(o.longitude),
    service_radius_km: String(o.service_radius_km), max_capacity_meals: String(o.max_capacity_meals),
    preferred_categories: o.preferred_categories, food_preferences: o.food_preferences,
    always_open: !m, open_time: m ? m[1] : '09:00', close_time: m ? m[2] : '18:00',
  }
}

export function formToPayload(f: OrgFormState) {
  return {
    name: f.name, organization_type: f.organization_type, contact_person: f.contact_person, phone: f.phone,
    address: f.address, latitude: numOrNull(f.latitude), longitude: numOrNull(f.longitude),
    service_radius_km: Number(f.service_radius_km), max_capacity_meals: Number(f.max_capacity_meals),
    preferred_categories: f.preferred_categories, food_preferences: f.food_preferences,
    operating_hours: f.always_open ? '24/7' : `${f.open_time}-${f.close_time}`,
  }
}

export default function OrgForm({ value, onChange, errors = {}, prefix = '' }: {
  value: OrgFormState; onChange: (v: OrgFormState) => void; errors?: Record<string, string>; prefix?: string
}) {
  const set = <K extends keyof OrgFormState>(k: K, v: OrgFormState[K]) => onChange({ ...value, [k]: v })
  const e = (k: string) => errors[prefix + k]
  const toggleCategory = (c: string) =>
    set('preferred_categories', value.preferred_categories.includes(c)
      ? value.preferred_categories.filter((x) => x !== c) : [...value.preferred_categories, c])

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Organization name" htmlFor="org-name" error={e('name')}>
          <input id="org-name" className="input" value={value.name} onChange={(ev) => set('name', ev.target.value)} required />
        </Field>
        <Field label="Organization type" htmlFor="org-type" error={e('organization_type')}>
          <select id="org-type" className="input" value={value.organization_type} onChange={(ev) => set('organization_type', ev.target.value)}>
            {Object.entries(ORG_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Contact person" htmlFor="org-contact" error={e('contact_person')}>
          <input id="org-contact" className="input" value={value.contact_person} onChange={(ev) => set('contact_person', ev.target.value)} required />
        </Field>
        <Field label="Organization phone" htmlFor="org-phone" error={e('phone')}>
          <input id="org-phone" className="input" value={value.phone} onChange={(ev) => set('phone', ev.target.value)} required />
        </Field>
      </div>
      <Field label="Address" htmlFor="org-address" error={e('address')}>
        <input id="org-address" className="input" value={value.address} onChange={(ev) => set('address', ev.target.value)} required />
      </Field>

      <div>
        <p className="label">Location</p>
        <LocationPicker lat={coordOr(value.latitude, NaN)} lng={coordOr(value.longitude, NaN)} kind="org" onChange={(la, lo) => onChange({ ...value, latitude: String(la), longitude: String(lo) })} />
        <div className="mt-3 grid grid-cols-2 gap-4">
          <Field label="Latitude" htmlFor="org-lat" error={e('latitude')}>
            <input id="org-lat" type="number" step="any" className="input" value={value.latitude} onChange={(ev) => set('latitude', ev.target.value)} />
          </Field>
          <Field label="Longitude" htmlFor="org-lng" error={e('longitude')}>
            <input id="org-lng" type="number" step="any" className="input" value={value.longitude} onChange={(ev) => set('longitude', ev.target.value)} />
          </Field>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Service radius (km)" htmlFor="org-radius" error={e('service_radius_km')} hint="How far you can travel to collect food.">
          <input id="org-radius" type="number" min="1" step="any" className="input" value={value.service_radius_km} onChange={(ev) => set('service_radius_km', ev.target.value)} />
        </Field>
        <Field label="Maximum capacity (meals)" htmlFor="org-cap" error={e('max_capacity_meals')} hint="Meals you can take on at one time.">
          <input id="org-cap" type="number" min="1" className="input" value={value.max_capacity_meals} onChange={(ev) => set('max_capacity_meals', ev.target.value)} />
        </Field>
      </div>

      <Field label="Food you can accept" error={e('food_preferences')}>
        <select className="input" aria-label="Food preference" value={value.food_preferences} onChange={(ev) => set('food_preferences', ev.target.value)}>
          {Object.entries(FOOD_PREF_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </Field>

      <fieldset className="min-w-0">
        <legend className="label">Accepted food categories</legend>
        <p className="mb-2 text-xs text-mist-500">Leave all unchecked to accept every category.</p>
        <div className="flex flex-wrap gap-2">
          {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
            <label key={k} className={`cursor-pointer rounded-full border px-3 py-1 text-sm ${value.preferred_categories.includes(k) ? 'border-leaf-600 bg-leaf-100 text-leaf-800' : 'border-mist-200 bg-white'}`}>
              <input type="checkbox" className="sr-only" checked={value.preferred_categories.includes(k)} onChange={() => toggleCategory(k)} />
              {v}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="min-w-0">
        <legend className="label">Operating hours (local time)</legend>
        <label className="mb-2 flex items-center gap-2 text-sm">
          <input type="checkbox" checked={value.always_open} onChange={(ev) => set('always_open', ev.target.checked)} /> Open 24/7
        </label>
        {!value.always_open && (
          <div className="flex flex-wrap items-center gap-2">
            <input aria-label="Opening time" type="time" className="input max-w-[150px]" value={value.open_time} onChange={(ev) => set('open_time', ev.target.value)} />
            <span>to</span>
            <input aria-label="Closing time" type="time" className="input max-w-[150px]" value={value.close_time} onChange={(ev) => set('close_time', ev.target.value)} />
          </div>
        )}
        {e('operating_hours') && <p className="mt-1 text-xs font-medium text-chilli-600">{e('operating_hours')}</p>}
      </fieldset>
    </div>
  )
}
