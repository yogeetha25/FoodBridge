# FoodBridge frontend

React + TypeScript + Vite + Tailwind. Run the backend first (see the [top-level README](../README.md)), then:

```bash
npm install
npm run dev        # http://localhost:5173  (proxies /api to http://localhost:8000)
npm run build      # type-check + production bundle
npm test           # 28 unit/component tests (Vitest + Testing Library)
npm run typecheck  # tsc --noEmit
```

Structure: `pages/` (public, donor, org, admin plus shared DonationDetail and Profile), `components/` (UI pieces such as
the match "ticket" and Leaflet maps), `layouts/` (public and dashboard shells), `services/api.ts` (every backend call),
`hooks/` (auth, data fetching), `types/` (API shapes), `utils/` (formatting).
