# Matching algorithm

Code: `backend/app/matching/scoring.py` (pure), `config.py` (weights and assumptions), `engine.py` (database glue).
No machine learning is used.

## Step 1: hard eligibility filters (organization is excluded, with a recorded reason)
| Code | Rule |
|---|---|
| `NOT_VERIFIED` | verification status is not VERIFIED |
| `INACTIVE` | the organization's user account is deactivated |
| `EXPIRED` | donation's available-until time has passed |
| `DIET_MISMATCH` | VEG_ONLY organization and non-veg food, or NON_VEG_ONLY and veg food |
| `CATEGORY_UNSUPPORTED` | the organization lists accepted categories and this one is not among them (empty list = accepts all) |
| `INSUFFICIENT_CAPACITY` | donation meals > (max capacity - meals already committed) |
| `OUT_OF_RANGE` | distance > organization's service radius |
| `CANNOT_ARRIVE_IN_TIME` | estimated arrival time >= time remaining |

## Step 2: weighted score
```
score = 100 x ( 0.30 x distance + 0.20 x capacity + 0.25 x urgency + 0.15 x food + 0.10 x availability )
```
Weights are in `matching/config.py` and can be overridden with `MATCH_WEIGHT_*` environment variables. They must add up to 1,
otherwise the application refuses to start.

| Factor | Sub-score (0 to 1) |
|---|---|
| Distance | `1 - distance / service_radius`, clamped to [0, 1]. |
| Capacity fit | `fill = meals / free capacity`. If fill <= 0.5: `0.4 + 1.2 x fill`. If 0.5 < fill <= 0.95: `1.0`. If fill > 0.95: `0.9`. This rewards sufficient capacity without favouring unnecessarily huge organizations. |
| Time feasibility (urgency) | `(time_left - ETA) / time_left`, clamped. ETA = driving time + 15 min preparation. Near organizations leave a large unused margin. |
| Food compatibility | `0.6 x category + 0.4 x diet`. Category: 1.0 if listed, 0.7 if the organization has no category restriction. Diet: 1.0 for a specialist match, 0.8 for an organization that accepts both. |
| Availability | 1.0 open now and on arrival; 0.8 closed now but open on arrival; 0.4 opens later inside the window; 0.1 closed for the whole window. |

**Assumptions** (constants in `config.py`): average speed 25 km/h, road-detour factor 1.3 on straight-line distance,
15-minute preparation buffer, local timezone UTC+5:30 for operating hours. With `USE_OSRM=true` the road distance and
duration come from OSRM and fall back to Haversine if the service fails.

## Step 3: explanation
Every factor returns `{label, score, weight, points, detail}` and `reasons` lists the same sentences with a good/weak flag.
This JSON is stored in `matches.score_breakdown` and rendered as the "match ticket" in the interface.

## Worked example (seed data, midday)
Donation: ABC College, 120 vegetarian cooked meals, 2 hours left. Annapurna already has 105 meals committed.

| Organization | Distance | ETA | Distance | Capacity | Urgency | Food | Avail. | **Score** |
|---|---|---|---|---|---|---|---|---|
| Annapurna Community Kitchen | 0.9 km | 18 min | 0.93 | 1.00 | 0.85 | 0.92 | 1.00 | **93.0%** |
| Hope Shelter Home | 6.0 km | 34 min | 0.40 | 1.00 | 0.72 | 1.00 | 1.00 | **75.1%** |
| Seva Food Bank | 14.1 km | 59 min | 0.43 | 0.60 | 0.51 | 0.74 | 1.00 | **58.9%** |
| Little Hands Children's Home | - | - | excluded: capacity 60 < 120 | | | | | - |
| New Dawn Trust | - | - | not verified (never matched) | | | | | - |

Check for Annapurna: 0.30x0.93 + 0.20x1.00 + 0.25x0.85 + 0.15x0.92 + 0.10x1.00 = 0.930, i.e. 93.0%.

Urgent example: Green Leaf Restaurant, 45 non-vegetarian portions, 50 minutes left. Hope Shelter is excluded (vegetarian only),
Seva Food Bank is excluded (needs about 52 minutes), leaving Annapurna 61.3% and Little Hands 51.7%.

## Ranking
Descending score; ties are broken by shorter distance, then organization id, so results are deterministic.
