# Problem statement

## Existing problem
Restaurants, hotels, caterers and events often have surplus edible food. NGOs and community kitchens need food for the
people they serve. Today the connection is informal: phone calls, messaging groups, personal contacts.

Why that fails:
1. **Time pressure.** Prepared food has a short usable window (hours).
2. **Information gap.** The donor does not know which organization is nearby, open, has capacity, and accepts that kind of food.
3. **No trust signal.** Donors cannot easily tell which organizations are genuine.
4. **No tracking.** Nobody can see whether a donation was collected or served.

## Proposed solution
FoodBridge is a web platform that lets donors post surplus food and automatically finds, ranks and explains suitable
**verified** organizations, then tracks the donation to completion and records impact.

## Scope
In scope: accounts and roles, donations, verification, rule-based matching, status workflow, pickups, reports, impact
analytics, maps. Out of scope: food-safety inspection, logistics/delivery, payments, hardware or IoT, machine learning.

## Important disclaimers
FoodBridge does not guarantee food safety, collection, or that food reaches beneficiaries, and it does not replace
government or NGO food-safety processes. Donors are responsible for accurate information.
