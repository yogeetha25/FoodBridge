# Presentation and demo script (about 8 minutes)

1. **Problem (1 min).** Show the landing page. "Good food is wasted while organizations need it; the gap is coordination within a few hours."
2. **Architecture (1 min).** React front end, FastAPI back end, SQLite; matching engine and status machine are pure functions.
3. **Donor (2 min).** `college@foodbridge.demo`: open the 120-meal donation, point to the ranked organizations, explain one ticket, open "How this score was calculated", show the "not eligible" list.
4. **Urgency (1 min).** `restaurant@foodbridge.demo`: the 45-portion donation with under an hour left; two organizations excluded for different reasons.
5. **Organization workflow (2 min).** `ngo1@...`: accept, schedule pickup, collect, complete. Then `ngo2@...` tries to accept the same donation and is refused.
6. **Admin (1 min).** `admin@...`: verify `ngo5`, resolve a report, show impact analytics and the "estimates" note.
7. **Close.** Limitations (no food-safety guarantee), future scope.
