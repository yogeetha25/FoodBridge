# FoodBridge: audit and bug-fixing report

Scope: full audit, debugging, fixing and verification of the FoodBridge codebase (FastAPI backend, React + TypeScript +
Vite frontend, SQLite). Every statement under "Tests performed" was actually executed; anything that could not be
executed is listed under "Remaining limitations".

## 1. Summary

| | Before | After |
|---|---|---|
| Backend tests | 100 collected: **96 pass, 4 fail** | **131 pass** (8 consecutive full runs of the final suite, no flaky test) |
| Frontend tests | none configured | **28 pass** (Vitest + Testing Library) |
| Frontend type-check / production build | pass / pass (one 860 kB bundle) | pass / pass (first load about 212 kB, pages load on demand) |
| Real-browser end-to-end checks | not available | **166 checks pass**, 0 console errors, 0 server errors |
| Layout overflow on 320 px / 375 px phones | landing, donation detail, org dashboard, org profile and admin tabs overflowed (page widened to 425 px) | none on any page |
| Donor can edit a donation in the UI | **no** (backend existed, no screen) | yes |
| Known critical security issue | JWTs could be forged when `SECRET_KEY` was not set | fixed |

The project architecture, design language and features were kept. No mock data or hard-coded responses were added.

## 2. How the audit was done

1. Extracted the ZIP, read all documentation, then read every backend module and every frontend file before changing anything.
2. Ran the original tests and frontend build to get a baseline (96/100 passing; frontend built).
3. Turned each suspicion from code reading into a **reproduction** (a throw-away test or browser script). Only reproduced problems were fixed; suspicions that did not reproduce were dropped (for example, concurrent recomputation of matches did not fail on SQLite, so it was left alone).
4. For every confirmed backend bug a permanent regression test was written, and each new test was also run against the **original** code to prove it fails there (a test that cannot fail proves nothing). The same was done for the two most important frontend tests.
5. Verified the finished system with a real backend, the production frontend build and a real Chromium browser.

## 3. Bugs found, root causes and fixes

Severity: **Critical** = exploitable or data-corrupting, **High** = wrong results or broken feature, **Medium** = incorrect behaviour in less common cases, **Low** = polish or hardening.

### 3.1 Security

| ID | Sev. | Problem (reproduced) | Root cause | Fix | Files |
|---|---|---|---|---|---|
| S1 | Critical | A token signed with the publicly visible default key `dev-only-insecure-key-change-me` was accepted (HTTP 200), so anyone could impersonate any user, including the admin, whenever `SECRET_KEY` was not set. The README called setting it "optional". | `config.py` fell back to a hard-coded secret. | No secret is stored in the source any more. A missing, short (< 32 chars) or placeholder key (including the text in `.env.example`) is replaced by a random key generated once into the git-ignored `backend/.dev_secret_key`. `ENVIRONMENT=production` refuses to start with a weak key or with `CORS_ORIGINS=*`. | `app/config.py`, `.env.example` (both), `.gitignore`, `tests/conftest.py` |
| S2 | High | 30 wrong passwords in a row were all processed (no limit). | No brute-force protection. | In-memory throttle per (client IP, email): 5 failures in 15 minutes gives HTTP 429 `too_many_attempts`; a success resets it; a different account is unaffected. Configurable. | new `app/auth/throttle.py`, `app/api/auth.py`, `app/config.py` |
| S3 | Medium | A validly signed token with no `exp` claim would be accepted. | `jwt.decode` did not require claims. | `exp` and `sub` are now required; only HS256 is accepted. | `app/auth/security.py` |
| S4 | Low | Searching users for `%` returned every user (LIKE wildcards were interpreted). Not SQL injection (queries are parameterized) but unintended. | Unescaped user input in `LIKE`. | Wildcards escaped. | `app/api/admin.py` |
| S5 | Low | `python seed.py` silently deleted the whole database. | No guard. | Asks for confirmation if data exists; `--yes` skips; refuses in non-interactive mode without `--yes`. | `seed.py` |
| S6 | Low | Unknown routes (404) and wrong methods (405) returned `{"detail": ...}` without the `code` field used everywhere else; `/api/health` did not check the database. | Default Starlette handler; static health response. | Uniform error shape; health does a real `SELECT 1` and returns 503 if the database is down. | `app/main.py` |

Verified and found **already correct**: bcrypt password hashing, JWT expiry (8 h), role checks on all admin routes, ownership checks, hidden donor contact details before acceptance, no password hash in any response, no stack traces in error responses, parameterized SQL.

### 3.2 Backend logic, data integrity and concurrency

| ID | Sev. | Problem (reproduced) | Root cause | Fix | Files |
|---|---|---|---|---|---|
| B1 | High | A name, address, phone or donation title made only of spaces was **saved** (HTTP 201), e.g. an organization with an empty name. Same for profile updates and donation edits. | `Field(min_length)` runs before the trimming validator, so `"   "` passed the length check and was then stored empty. | New `strip_min()` helper (trim, then re-check length) applied to every required text field in register, profile, organization create/update, donation create/update. | `schemas/common.py`, `auth.py`, `organization.py`, `donation.py` |
| B2 | High | An edit could be applied **after** an organization accepted the donation (quantity changed from 100 to 1 meal after the capacity check passed). | Read-then-write with no guard. | `ensure_status()` locks the row and re-checks that the donation is still open before any edit; otherwise HTTP 409. | new `services/transitions.py`, `donation_service.py` |
| B3 | High | Two simultaneous "mark completed" requests: the second crashed with a raw database `IntegrityError` (HTTP 500). | Status changes (except accept) were read-check-write. | Every status change is now one atomic `UPDATE ... WHERE status IN (...)` (`transition()`); the loser gets HTTP 409. One impact record is guaranteed. | `transitions.py`, `donation_service.py` |
| B4 | Medium | Documented limitation: two acceptances at the same moment by one organization could exceed its capacity. | Capacity was checked on a snapshot before the claim. | Capacity is re-checked inside the acceptance transaction; over-capacity rolls back with HTTP 409 `capacity_exceeded`. | `donation_service.py`, `matching/engine.py` |
| B5 | Medium | Cancelling an overdue donation turned it into CANCELLED instead of EXPIRED (distorts the statistics); editing one showed a confusing date error. | Expiry sweep did not run before cancel/edit. | Sweep first; an overdue donation is EXPIRED and not editable (409). | `donation_service.py` |
| B6 | Medium | After an edit moved a donation out of everyone's range it stayed **MATCHED with 0 matches**. Also, the status flip in the matching engine was an unguarded write that could overwrite a concurrent acceptance. | `MATCHED -> AVAILABLE` did not exist; flips used plain assignment. | New legal transition `MATCHED -> AVAILABLE` (14 transitions; the "every other pair is rejected" test is unchanged), applied with guarded compare-and-set in both directions. | `status_machine.py`, `matching/engine.py` |
| B7 | Medium | Pickup notes were overwritten at each stage (schedule, collect, complete), so the first notes were lost. | `pickup.notes = new`. | Notes from every stage are kept (appended). | `donation_service.py` |
| B8 | Low | The same user could file identical open reports repeatedly. | No duplicate check. | HTTP 409 `duplicate_report` while an identical report is open or in review; a different reason is still allowed. | `report_service.py` |

### 3.3 Backend performance

| ID | Problem (measured) | Fix | Result |
|---|---|---|---|
| P1 | Organization donation list: one global load aggregate per donation. 40 donations cost **48** SQL statements. | Load computed once and passed in; single-organization query. | **9** statements |
| P2 | Admin user list: lazy-loaded organization per user plus a global aggregate. 102 users cost **66** statements. | `selectinload`, load aggregate once. | **4** statements |
| P3 | Almost every request (reads included) issued an `UPDATE` for expiry even when nothing was overdue, taking the database write lock each time. | Cheap `SELECT` first; write only if something is overdue. | 0 writes when idle |
| P4 | Impact analytics loaded every donation as a full ORM object graph. | One lean column query; output compared with the old implementation on seeded data for the platform, all 3 donors and all 5 organizations: **identical**. | 5 -> 3 statements, much less memory |

### 3.4 Frontend

| ID | Sev. | Problem | Fix | Files |
|---|---|---|---|---|
| F1 | High | **Donors had no way to edit a donation** (requirement: "Edit donation details"; `donationApi.update` existed but nothing called it). | New `EditDonationModal` (pre-filled, validated, shows server errors, matches recalculated after saving); button shown only while the donation is open and owned by the donor. | new `components/EditDonationModal.tsx`, `pages/DonationDetail.tsx` |
| F2 | High | `useFetch` let an older, slower response overwrite a newer one (user search showed results for the wrong text) and updated state after unmount. | Latest-request-wins guard. Search is also debounced (300 ms) instead of one request per keystroke. | `hooks/useFetch.ts`, `pages/admin/AdminUsers.tsx` |
| F3 | High | Any network error or 5xx while restoring the session **signed the user out**; a deactivated account kept erroring instead of signing out; verification status and capacity shown on the organization dashboard came from the login-time snapshot (an organization verified by an admin stayed "pending" until re-login). | Sign out only on 401/403; `account_inactive` triggers sign-out; session data refreshed on tab focus; dashboard reads `/organizations/me`. | `hooks/useAuth.tsx`, `services/api.ts`, `pages/org/OrgDashboard.tsx` |
| F4 | High | Leaflet map: re-fitted and reset the user's pan/zoom on **every parent re-render** (e.g. each keystroke in a notes box); threw `Cannot read properties of undefined (reading '_leaflet_pos')` when closed during its animation (**reproduced 6 of 6 times**, now 0 of 6); invalid coordinates could crash the page; "use my location" failed silently. | Effect depends on positions only, no animation for programmatic moves, invalid coordinates filtered, clear message when location is blocked, Fragment instead of `<span>` inside the map. | `components/MapView.tsx` |
| F5 | High | Clearing a latitude/longitude field silently turned it into **0** (a location in the ocean) and fields snapped back to "0" while typing. | Coordinates are held as text, blank becomes `null` and is rejected with a clear message. | `OrgForm.tsx`, `CreateDonation.tsx`, `utils/format.ts` |
| F6 | Medium | The notes typed when scheduling a pickup reappeared in the "complete" form and overwrote them. | Separate state per form. | `DonationDetail.tsx` |
| F7 | Medium | Matches were requested twice (and the page flashed "no eligible organization" in between); the recommendations page asked for each donation one after another; "Back" always went to the "available" list. | One request after the donation loads; requests in parallel; Back goes to the list the donation belongs to. | `DonationDetail.tsx`, `RecommendedOrgs.tsx` |
| F8 | High | **Phone layout**: the landing page, donation detail, org dashboard, org profile and admin filter tabs were wider than 320-375 px phones (the browser silently zoomed the page out and allowed sideways panning). 18 grids had no base column, so wide content (maps, long words) stretched the page. | Explicit single column below the breakpoint, `min-w-0` on form fieldsets, wrapping filter tabs and opening-hours row. Verified with a strict scan at 320 and 375 px on every page. | 11 component and page files |
| F9 | Medium | iPhone: inputs were 14 px so iOS Safari zoomed in on focus; the modal used `vh` (URL-bar problem); page scrolled behind modals; touch targets under 44 px. | 16 px inputs on phones, `dvh`, scroll lock, safe-area padding, 44 px targets on touch screens only. Desktop look unchanged. | `index.css`, `Modal.tsx`, `Toast.tsx`, `index.html` |
| F10 | Medium | Single 860 kB JavaScript file for everyone. | Route-level lazy loading and vendor chunks: first load about 212 kB; charts and maps only for the pages that use them. | `App.tsx`, `vite.config.ts` |
| F11 | Low | The admin's report notes were labelled "visible to the person who filed the report", but no screen showed them. | Reporters now see "Your reports on this donation" with status and the administrator's notes. | `DonationDetail.tsx` |

### 3.5 Tests that were wrong (not application bugs)

| ID | Problem | Cause and fix |
|---|---|---|
| T1 | 4 of the 100 original tests failed: `test_second_organization_cannot_accept_an_already_accepted_donation`, `test_only_the_accepting_organization_can_continue_the_workflow`, `test_atomic_claim_rejects_a_stale_second_acceptance`, `test_two_simultaneous_acceptances_produce_exactly_one_winner`. | The test fixtures registered organizations named `"A"` and `"B"`, which the application correctly rejects (names need at least 2 characters), so registration returned HTTP 422 and the tests never reached the logic they were written for. **The application was right; the test data was wrong.** I changed only the fixture names (`"Org A"`, `"Org B"`) and one assertion that referenced the old name. The validation rule was not loosened. Once the fixtures were valid, the "first valid acceptance wins" and concurrency tests passed against the real code. This is also why `docs/testing.md` had to say the API tests were never run. |
| T2 | `test_status_machine.py` enumerates the legal transitions. | Updated for the one deliberate new transition (B6). The assertion that every other pair is rejected is untouched. |

## 4. Files modified

Backend: `app/api/{admin,auth,organizations,serializers}.py`, `app/auth/security.py`, `app/config.py`, `app/main.py`,
`app/matching/engine.py`, `app/schemas/{auth,common,donation,organization}.py`,
`app/services/{donation_service,expiry,impact_service,organization_service,report_service,status_machine}.py`, `seed.py`,
`tests/{conftest,test_status_machine,test_workflow}.py`.
**New:** `app/auth/throttle.py`, `app/services/transitions.py`, `tests/test_security.py`, `tests/test_integrity.py`.

Frontend: `index.html`, `package.json` (test scripts, dev dependencies), `tsconfig.json`, `vite.config.ts`, `src/App.tsx`, `src/index.css`,
`src/components/{ImpactPanel,MapView,Modal,OrgForm,Toast}.tsx`, `src/hooks/{useAuth.tsx,useFetch.ts}`, `src/layouts/PublicLayout.tsx`,
`src/pages/{DonationDetail,Profile}.tsx`, `src/pages/admin/{AdminOrganizations,AdminUsers}.tsx`,
`src/pages/donor/{CreateDonation,RecommendedOrgs}.tsx`, `src/pages/org/OrgDashboard.tsx`,
`src/pages/public/{Landing,Register}.tsx`, `src/services/api.ts`, `src/utils/format.ts`.
**New:** `src/components/EditDonationModal.tsx`, `frontend/.env.example`, `package-lock.json`, `src/test/setup.ts`, and 5 test files
(`useFetch`, `useAuth`, `api`, `format`, `EditDonationModal`).

Configuration and documentation: `.env.example` and `backend/.env.example` (identical), `.gitignore`, `README.md`, `frontend/README.md`,
`docs/{testing,limitations,system-architecture,functional-requirements}.md`, and this report.

## 5. Tests performed and results

| Check | Command / method | Result |
|---|---|---|
| Python compile and static check | `python -m compileall app tests seed.py`; `pyflakes` | clean (only intentional re-exports) |
| Backend suite | `cd backend && pytest` | **131 passed** |
| Flakiness check | full suite repeated (12 runs at 129 tests while developing, 8 runs of the final 131) | all passed, including the two threaded race tests |
| New regression tests vs. original code | the 12 integrity regression tests (written for the bugs above) run against the unmodified backend | all 12 fail there, pass after the fixes |
| Impact calculation equivalence | old vs new `impact_service` on seeded data, 9 scopes | identical |
| Frontend type-check | `npx tsc --noEmit` | clean |
| Frontend production build | `npm run build` | success, no size warning |
| Frontend tests | `npm test` | **28 passed**; the stale-response and session tests fail on the original hooks |
| Clean-install check | copy of the final project, `npm ci`, build, tests, backend tests | all pass |
| Real-browser workflow (Chromium, real backend, production build) | donor register/login, create, **edit**, accept by organization, second organization refused, schedule, collect, complete, impact figures equal `/api/impact`, admin pages, role redirects | 30/30 |
| Multi-device layout | iPhone 13, iPhone SE, Pixel 7 (Android), iPad, 1920 px desktop: every page of every role, menu drawer, modal fit, input font size, touch targets | 123/123 |
| Registration and verification flows | register donor and organization through the UI, duplicate email, blank coordinates, unverified organization blocked, admin verifies, organization picks it up without re-login, report flow | 13/13 |
| Strict overflow scan | every page at 320 px and 375 px width | none |
| Console / server errors | captured during all browser runs | 0 |
| Live API authorization matrix | every route in the OpenAPI schema as anonymous, donor, organization and admin | no unexpected access |
| Live API security checks | SQL-injection payloads, malformed JSON, oversized input, tampered/garbage tokens, CORS, error leakage, cross-user edit/cancel, contact-info privacy | 30 passed (a 31st check used a route path that does not exist, so it was dropped and replaced by the full matrix above) |
| Startup configuration paths | no key, placeholder key, production with weak key, production with `*` CORS, production with good key | all behave as designed |

Matching verification (through the real API): nearer organizations rank higher, scores are within 0-100 and the factor points add
up to the total, and exclusions report the right reason (diet mismatch, unsupported category, insufficient capacity); expired donations
are excluded from organization lists, recommendations, acceptance and matches.

## 6. Remaining limitations

These are real; none could be removed within the scope of this work, and none stops the application from working.

1. **Not tested on physical devices or in real Safari/Firefox.** Responsive checks used Chromium with device emulation (viewport, touch, user agent). Real iPhones and Android phones should still be tried once. Exact steps: `npm run build && npm run preview -- --host`, then open `http://<PC-IP>:4173` on the phone.
2. **Map tiles could not be loaded in the test environment** (no internet to OpenStreetMap). Markers, layout and interaction were verified; the tile images were not. **OSRM road routing** (`USE_OSRM=true`) was not tested for the same reason; the default Haversine path is fully tested.
3. **Only SQLite was tested.** The atomic updates are plain SQL that PostgreSQL supports, but this was not run against PostgreSQL.
4. **Login throttling is in memory, per server process.** With several workers or behind a proxy that hides client IPs it is weaker; use a shared store for that. No CAPTCHA.
5. **Dependency advisories** (`npm audit`): the original project already carried advisories in `react-router` 6 and in the Vite 5 dev server. The Vitest dev dependency I added brings dev-only advisories as well. None affects the production build: the app does no server-side rendering and never passes user-controlled URLs to `Link`/`navigate`; the Vite and Vitest issues concern running the dev/test servers on a hostile network. All of them are cleared by upgrading to `react-router-dom@7`, `vite@8`, `@vitejs/plugin-react@6` and `vitest@5` (I tried this in a scratch copy: type-check, build and all 28 tests pass and `npm audit` reports 0 issues). It needs **Node 20.19+ or 22.12+** (your README says 18+), and `vite.config.ts` must drop the `manualChunks` object (not supported by Vite 8's bundler; route-level lazy loading already splits the code). I did not apply it so that the project keeps working on the Node version it documented.
6. **Known design limits** (documented in `docs/limitations.md`): token stored in `localStorage`, no refresh tokens or server-side revocation, no password reset or email verification, no notifications, manual organization verification, estimated (not measured) impact figures, `create_all` instead of migrations.
7. The landing page hero shows a clearly labelled **illustrative example** match card (static text marked "Example"); every number elsewhere comes from the database.
8. Demo accounts and passwords in the README are for local demo data only; change or delete them before any real deployment.
9. No CI pipeline is configured; run the commands in section 5 manually.

## 7. How to re-run the verification yourself

```bash
cd backend  && pip install -r requirements.txt && pytest                # 131 tests
cd frontend && npm ci && npm run typecheck && npm test && npm run build  # 28 tests + build
```
