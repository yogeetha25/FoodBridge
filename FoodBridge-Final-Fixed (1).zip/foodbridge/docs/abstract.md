# Abstract

Large amounts of edible food are left over at restaurants, hotels, caterers and college events, while NGOs and
community kitchens serving people in need often struggle to obtain food. Because prepared food is perishable, the
problem is mainly one of **coordination**: donors have only a few hours and do not know which nearby organization can
take a given quantity and type of food in time.

**FoodBridge** is a web application that connects surplus-food donors with *verified* receiving organizations. A donor
posts a donation; the server validates it; a transparent, rule-based **matching algorithm** removes ineligible
organizations (unverified, too far, insufficient capacity, incompatible food, unable to arrive before expiry) and scores the
rest using five weighted factors (distance 30%, capacity fit 20%, time feasibility 25%, food compatibility 15%,
availability 10%). Each organization's score comes with a plain-language explanation. The first organization to accept wins
(enforced by an atomic database update), and the donation then moves through a strictly validated lifecycle: accepted,
pickup pending, collected, completed. Completed donations feed an impact dashboard whose figures are explicitly labelled as
estimates.

The system is built with React, TypeScript and Tailwind CSS on the front end and FastAPI, SQLAlchemy and SQLite on the
back end, with JWT authentication, bcrypt password hashing, role-based authorization (donor, organization, admin),
OpenStreetMap/Leaflet maps and Haversine distance. It uses no machine learning and no hardware. FoodBridge facilitates
redistribution; it does not guarantee food safety or collection.

**Keywords:** food redistribution, matching algorithm, rule-based scoring, FastAPI, React, role-based access control.
