# Functional requirements (as implemented)

| ID | Requirement | Where |
|---|---|---|
| FR1 | Users register as Donor or Organization; admins are created by seed only. Login returns a JWT. | `api/auth.py`, `services/auth_service.py` |
| FR2 | A new organization is `PENDING` and is excluded from matching until an admin verifies it. | `matching/scoring.py` (filter), `api/admin.py` |
| FR3 | Donors create donations; the server validates quantity > 0, meals > 0, coordinates, future expiry (max 72 h), prepared time before expiry, known category/unit. | `schemas/donation.py` |
| FR3a | Donors may edit a donation until an organization accepts it (AVAILABLE or MATCHED). The server re-validates every field and re-runs the matching; the edit is refused if the donation was accepted, even by a simultaneous request. | `donation_service.update_donation`, `transitions.ensure_status`, `EditDonationModal` |
| FR4 | On creation the matching engine scores all organizations and stores the ranking. A donation with at least one eligible organization becomes `MATCHED`. | `matching/engine.py` |
| FR5 | Every match has a score (0-100), a rank and a structured explanation. | `matches.score_breakdown` |
| FR6 | Organizations see *recommended* donations (eligible, best first) and *available nearby* donations (inside service radius, with the reason if not eligible). | `donation_service.list_donations` |
| FR7 | An organization accepts a donation only if verified, eligible (capacity, distance, diet, category, time) and the donation is still open. First valid acceptance wins; others receive HTTP 409. | `donation_service.accept_donation` |
| FR8 | Organizations schedule a pickup (before expiry), mark food collected, and mark distribution completed. | `donation_service` |
| FR9 | Status changes follow the state machine; illegal transitions return HTTP 409. | `services/status_machine.py` |
| FR10 | Donors may cancel before pickup begins (AVAILABLE, MATCHED, ACCEPTED). Admins may also cancel PICKUP_PENDING. | `donation_service.cancel_donation` |
| FR11 | AVAILABLE/MATCHED/ACCEPTED donations become `EXPIRED` after their available-until time. | `services/expiry.py` |
| FR12 | Completing a donation creates an impact record. | `impact_service.record_impact` |
| FR13 | Donors and organizations report problems (reason + details) on donations they are involved in; admins change status and add resolution notes. | `api/reports.py` |
| FR14 | Admins view users (and deactivate), organizations (verify / reject), donations and platform statistics. | `api/admin.py` |
| FR15 | Impact is shown platform-wide, per donor, and per organization, with weekly and monthly trends. | `api/impact.py` |
| FR16 | Donor contact details are visible only to the donor, admins, and the organization that accepted. | `api/serializers.py` |
| FR17 | Maps show donation and organization locations (OpenStreetMap). | `components/MapView.tsx` |
