# Non-functional requirements (as implemented)

| Quality | How it is met |
|---|---|
| **Security** | bcrypt password hashing; JWT (HS256) with expiry; role-based dependencies; ownership checks in services; Pydantic validation; CORS allow-list; secrets via environment variables (`.env.example`); contact info hidden until acceptance; login error message identical for unknown email and wrong password. |
| **Correctness** | Atomic `UPDATE ... WHERE status IN (open)` for acceptance plus a unique constraint on `pickups.donation_id`; central state machine; database CHECK constraints; foreign keys enabled. |
| **Transparency** | Matching weights in one config file; every factor returns a number and a sentence; estimates labelled and assumptions listed. |
| **Usability** | Responsive layout (sidebar on desktop, drawer on mobile), clear status badges, empty/loading/error states, friendly error messages, visible focus styles, labelled form fields, reduced-motion support. |
| **Reliability** | The app works with no external service: Haversine by default, OSRM optional with automatic fallback; map tiles failing does not break the UI; global error handlers hide stack traces from users. |
| **Maintainability** | Layered backend (routes, services, models), pure matching and status modules, typed frontend, 100 automated tests. |
| **Performance** | Matching is O(number of organizations) in pure Python; adequate for hundreds of organizations. |
| **Cost** | No paid APIs. |
| **Portability** | Runs on Windows, macOS and Linux with Python and Node.js. |
