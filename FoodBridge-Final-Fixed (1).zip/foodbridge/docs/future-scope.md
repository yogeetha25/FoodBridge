# Future scope

* OSRM (or another routing service) as the default for road distance and live travel time
* Image upload for donations
* Email, SMS and push notifications; real-time updates
* Delivery-volunteer matching (the "pickup capability" factor)
* Partial acceptance: split one large donation across several organizations
* Ratings, reviews and recurring donors
* Password reset, email verification, refresh tokens, rate limiting
* Alembic migrations, PostgreSQL and cloud deployment
* Multilingual interface and a mobile app
* Learning the matching weights from real historical outcomes (only meaningful once enough real data exists)
