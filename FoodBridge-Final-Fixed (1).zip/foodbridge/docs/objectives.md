# Objectives

1. Let donors register and publish surplus-food donations quickly, with all key details validated **on the server**.
2. Let receiving organizations register, describe their capacity, location and preferences, and be verified by an administrator.
3. Automatically find eligible verified organizations and rank them with a **transparent, configurable, rule-based** score.
4. **Explain** every score so users understand why an organization was recommended.
5. Ensure only one organization can accept a donation, even under simultaneous requests.
6. Enforce a strict donation lifecycle; reject illegal status changes.
7. Expire donations automatically when their available-until time passes.
8. Give administrators tools to verify organizations, monitor donations and resolve reports.
9. Report measurable impact, clearly labelled as estimates with documented assumptions.
10. Keep the system software-only, free of paid APIs, and understandable enough to explain in a viva.
