# Database design

SQLite, accessed with SQLAlchemy 2. Foreign keys are enforced.

## ER diagram (Mermaid; paste into https://mermaid.live or view in GitHub / VS Code)
```mermaid
erDiagram
    USERS ||--o| ORGANIZATIONS : "has (role = ORGANIZATION)"
    USERS ||--o{ DONATIONS : "donates (role = DONOR)"
    DONATIONS ||--o{ MATCHES : "is ranked into"
    ORGANIZATIONS ||--o{ MATCHES : "appears in"
    DONATIONS ||--o| PICKUPS : "is collected via"
    ORGANIZATIONS ||--o{ PICKUPS : "performs"
    DONATIONS ||--o| IMPACT_RECORDS : "produces"
    DONATIONS ||--o{ REPORTS : "is subject of"
    USERS ||--o{ REPORTS : "files / resolves"

    USERS { int id PK; string email UK; string password_hash; string role; string full_name; string phone; string donor_type; bool is_active; datetime created_at }
    ORGANIZATIONS { int id PK; int user_id FK_UK; string name; string organization_type; string contact_person; string phone; string address; float latitude; float longitude; float service_radius_km; int max_capacity_meals; json preferred_categories; string food_preferences; string operating_hours; string verification_status; datetime created_at }
    DONATIONS { int id PK; int donor_id FK; string title; string category; bool is_vegetarian; float quantity; string unit; int estimated_meals; datetime prepared_at; datetime available_until; string pickup_address; float latitude; float longitude; text description; text handling_notes; string contact_info; string status; datetime created_at }
    MATCHES { int id PK; int donation_id FK; int organization_id FK; float score; json score_breakdown; int rank; datetime created_at }
    PICKUPS { int id PK; int donation_id FK_UK; int organization_id FK; datetime scheduled_at; datetime collected_at; datetime completed_at; text notes }
    IMPACT_RECORDS { int id PK; int donation_id FK_UK; int meals_redistributed; float quantity_kg_est; int people_served_est; datetime created_at }
    REPORTS { int id PK; int donation_id FK; int reporter_id FK; string reason; text details; string status; int resolved_by FK; text resolution_notes; datetime created_at }
```

## Tables and rules
| Table | Notes |
|---|---|
| `users` | `email` unique and indexed; `role` is DONOR, ORGANIZATION or ADMIN. |
| `organizations` | `user_id` unique (one organization per user); CHECK latitude/longitude ranges, radius > 0, capacity > 0; `verification_status` PENDING / VERIFIED / REJECTED. |
| `donations` | CHECK quantity > 0, meals > 0, coordinates; index on (`status`, `available_until`) for expiry sweeps. |
| `matches` | Unique (`donation_id`, `organization_id`); `score_breakdown` JSON holds factors, weights and reasons; replaced on every recomputation. |
| `pickups` | `donation_id` unique: a donation can only ever be accepted by one organization. |
| `impact_records` | `donation_id` unique; created when a donation becomes COMPLETED. Values are estimates. |
| `reports` | Two foreign keys to `users` (reporter, resolver). `resolution_notes` was added to the minimum field list. |

## Normalization notes
Tables are in 3NF except for two deliberate choices: `preferred_categories` is stored as a JSON list instead of a
junction table, and `score_breakdown` is stored as JSON because it is a snapshot of an explanation, not data to query.
