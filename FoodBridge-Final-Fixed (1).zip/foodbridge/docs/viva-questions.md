# Viva questions and answers

**1. What problem does FoodBridge solve?**
Surplus edible food and organizations that need it exist in the same city, but perishable food needs fast coordination. FoodBridge finds, ranks and tracks the connection.

**2. Why did you not use machine learning?**
The problem does not need it. A rule-based score is explainable (users see why), testable, needs no training data, and is easy to defend. Adding ML only to say "AI" would reduce transparency.

**3. Explain the matching algorithm.**
Two stages. First, hard filters remove organizations that cannot take the donation (unverified, inactive, too far, no capacity, wrong diet or category, cannot arrive before expiry). Then a weighted score: distance 30%, capacity fit 20%, time feasibility 25%, food compatibility 15%, availability 10%, each 0 to 1, times 100.

**4. Why is the weight on distance 30%?**
Nearer organizations collect faster, keeping food fresher. The weights are a design choice, stored in one config file, and can be changed with environment variables; the weights must sum to 1.

**5. How is capacity scored without favouring huge NGOs?**
By fill ratio (meals / free capacity). A comfortable fit (50 to 95%) gets 1.0, a tiny donation for a huge organization scores lower (down to 0.4), and an exact fit gets 0.9 because it leaves no spare room.

**6. How do you make sure only one NGO accepts a donation?**
A single conditional SQL statement: `UPDATE donations SET status='ACCEPTED' WHERE id=? AND status IN ('AVAILABLE','MATCHED') AND available_until > now`. The database applies it to one request at a time; the loser updates 0 rows and gets HTTP 409. A unique constraint on `pickups.donation_id` is a second safety net. We test it with a stale-read test and a two-thread test.

**7. What is the status lifecycle and how is it enforced?**
AVAILABLE, MATCHED, ACCEPTED, PICKUP_PENDING, COLLECTED, COMPLETED, plus CANCELLED and EXPIRED. A dictionary of allowed transitions in `status_machine.py` is checked before every change; illegal changes return HTTP 409. A test checks all 64 state pairs.

**8. How are passwords stored?**
Hashed with bcrypt (salted, slow by design). Plain text is never stored or returned. Login errors are identical for unknown email and wrong password to avoid revealing which emails exist.

**9. How does authentication work?**
Login returns a JWT (signed with a secret from the environment, with an expiry). The React app sends it in the `Authorization: Bearer` header; a FastAPI dependency decodes it and loads the user.

**10. How is authorization done?**
Role-based dependencies (`require_donor`, `require_org`, `require_admin`) plus ownership checks in services (for example, a donor can only edit their own donation). Tests prove donor B cannot change donor A's donation.

**11. What validation exists and why on the server?**
Pydantic schemas validate types, ranges, enums, and rules like "available-until must be in the future". The browser can be bypassed, so the server is authoritative; the frontend validation is only for convenience.

**12. How do you prevent unverified NGOs from getting food?**
Verification status is the first hard filter in matching and is re-checked on accept. Only an admin can verify.

**13. How are expired donations handled?**
A background task runs every minute, and every list/detail request also runs the sweep. AVAILABLE, MATCHED and ACCEPTED donations past their time become EXPIRED. PICKUP_PENDING does not auto-expire because the pickup is already arranged.

**14. How do you calculate distance?**
The Haversine formula on latitude/longitude gives straight-line distance. Travel time = distance x 1.3 / 25 km/h plus 15 minutes of preparation. Optional OSRM gives road distance, with automatic fallback.

**15. Are the impact numbers exact?**
No, they are estimates: meals come from the donor's estimate, kilograms assume 0.4 kg per meal unless measured in kg, people served assumes one meal per person. We deliberately do not compute CO2. The UI says "estimate" and lists the assumptions.

**16. Does FoodBridge guarantee food safety?**
No, and it says so. Donors are responsible for accurate information and safe food; FoodBridge only coordinates.

**17. Why SQLite and SQLAlchemy?**
SQLite needs no setup, ideal for development and demos. SQLAlchemy abstracts the database, so moving to PostgreSQL mostly means changing the connection URL.

**18. Why a single users table?**
All roles share login fields; the organizations table extends a user 1:1. It avoids duplicating authentication logic.

**19. Why is `preferred_categories` stored as JSON?**
A junction table is purer, but at this scale it adds joins without benefit. It is a conscious trade-off and easy to normalize later.

**20. Which design pattern separates your code?**
Layered architecture: routes handle HTTP, services hold business rules, models handle persistence, and the matching/state-machine modules are pure functions with no I/O.

**21. How do organizations see explanations?**
On the donation page, each match shows reasons (for example "Only 0.9 km away") and an expandable table of factor, score, weight and points. These are produced by the scoring function and stored as JSON.

**22. What happens if no organization is eligible?**
The donation stays AVAILABLE, the donor sees "No eligible organization" with the reasons organizations were excluded, and any organization that becomes eligible can still accept it.

**23. How would you scale this?**
PostgreSQL with Alembic migrations, background jobs for expiry and notifications, caching, geospatial indexes (PostGIS) for nearby search, and deployment behind HTTPS.

**24. What are the main limitations?**
No food-safety checking, approximate distance, simple capacity model, manual verification, no notifications. Documented in `limitations.md`.

**25. What would you add next?**
Notifications, volunteer delivery matching, partial acceptance, OSRM as default, and learning weights from real outcomes once data exists.

**26. How did you test the matching algorithm?**
25 unit tests on the pure function covering near vs far, capacity, verification, diet, category, urgency, closed vs open, no eligible organization, deterministic ranking, and custom weights.
