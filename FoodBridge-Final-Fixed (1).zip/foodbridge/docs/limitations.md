# Limitations

1. **Food safety is not verified.** FoodBridge cannot check what donors enter. It does not guarantee food is safe, that it will be collected, or that it reaches beneficiaries. It does not replace government or NGO food-safety processes.
2. **Estimates, not measurements.** Meals, kilograms and people served derive from donor-supplied estimates and assumptions (1 meal ~ 0.4 kg, 1 meal ~ 1 person). No CO2 figures are produced because they cannot be calculated reliably here.
3. **Distance is approximate.** Straight-line (Haversine) distance with a 1.3 detour factor and 25 km/h average speed. OSRM is optional and needs internet.
4. **Capacity model is simple.** One number (meals at one time) minus meals already committed. The limit is re-checked inside the acceptance transaction, so two simultaneous acceptances cannot exceed it.
5. **All-or-nothing acceptance.** One organization takes the whole donation; no splitting.
6. **No logistics.** Organizations collect food themselves; there are no delivery volunteers.
7. **Verification is manual**, by an administrator reading the registration details.
8. **No notifications** (email, SMS, push). Users see updates when they open the app.
9. **Security scope.** JWT in `localStorage` (XSS exposure), no refresh tokens or server-side token revocation, no email verification, no password reset. Login brute-force protection is in-memory and per server process (use a shared store such as Redis if you run several workers), and behind a reverse proxy it sees the proxy's IP unless the proxy is configured to forward the client address. There is no CAPTCHA.
10. **Operational scope.** SQLite (the atomic status changes are written to behave the same on PostgreSQL, but only SQLite was tested), `create_all` instead of migrations, a single fixed timezone for operating hours, no image upload.
11. **Demo data is fictional**, set in Bengaluru.
12. **Tested with emulation, not hardware.** Responsive behaviour was verified in Chromium with device emulation (iPhone, Android, iPad, desktop sizes). It was not run on physical devices or in real Safari/Firefox.
13. **Map tiles need internet** (OpenStreetMap). Without it the map shows markers on a grey background.
14. **Reporters see their own reports on the donation page only**; there is no separate "my reports" screen and no notification when an administrator resolves one.
