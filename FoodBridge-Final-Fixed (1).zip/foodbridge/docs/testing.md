# Testing

Framework: **pytest** with FastAPI's `TestClient`. Each test gets a fresh temporary SQLite database (`tests/conftest.py`).
Password hashing uses 4 bcrypt rounds in tests for speed.

```bash
cd backend
pytest              # 131 tests
pytest -v -k matching
```

## Backend test files (131 tests)
| File | Tests | What it proves |
|---|---|---|
| `test_matching.py` | 25 | **Pure matching engine**: nearby vs distant, enough vs insufficient capacity (including already-committed load), verified vs unverified, inactive, veg-only / non-veg-only mismatch, unsupported category, specialist vs generalist food score, urgency formula, cannot-arrive-in-time exclusion, expired donation, open vs closed organization, score between 0 and 100 and factor points adding up, explanation present, ranking and exclusion list, **no eligible organization**, configurable weights change the ranking, OSRM-style custom travel estimator, weights must sum to 1 |
| `test_geo_hours.py` | 7 | Haversine (zero, known distance, symmetry), coordinate validity, operating-hours parsing, UTC offset, overnight windows |
| `test_status_machine.py` | 5 | All 14 valid transitions allowed; **every other** of the 64 pairs rejected; terminal states; no skipping steps |
| `test_impact_calc.py` | 5 | Impact estimates (meals, kg, people), week buckets start on Monday, weekly and monthly trend bucketing including year boundary |
| `test_auth.py` | 13 | Registration (donor, organization starts PENDING), duplicate email, cannot self-register as admin, weak password, org details required, password stored hashed, login success / wrong password / unknown email (same message), `/me` auth, deactivated user |
| `test_authorization.py` | 11 | Role checks on admin endpoints, anonymous access, donor vs organization actions, **donor A cannot touch donor B's donation**, organization cannot edit another organization, unverified organization blocked, contact info hidden until acceptance, admin verify / reject |
| `test_donations.py` | 16 | Creation (matched vs available), validation (past expiry, zero/negative quantity, bad coordinates, missing fields, unknown category/unit, time ordering), ranking through the API, excluded-organization reasons, unverified organizations hidden from donors, editing recomputes matches, cancel, double cancel, 404, overdue shown as expired |
| `test_workflow.py` | 14 | Full lifecycle updates impact (platform, donor, organization), invalid transitions, donor cannot cancel after pickup is scheduled, second organization refused (409), only accepting organization continues, capacity exceeded, capacity accounts for committed meals, expired donation cannot be accepted, pickup before expiry, organization list views, expiry service touches only expirable statuses, **concurrent acceptance**: a stale-read test and a two-thread test each produce exactly one winner |
| `test_security.py` | 17 | Weak/placeholder `SECRET_KEY` detection and production refusal, **tokens forged with the old public default key are rejected**, tokens without expiry / unsigned (`alg: none`) / expired are rejected, login brute-force throttling (per IP + email, window expiry, success resets), whitespace-only names/addresses rejected, uniform 404/405 error shape, health check hits the database |
| `test_integrity.py` | 14 | Overdue donations become EXPIRED (not CANCELLED) and are not editable, `MATCHED` returns to `AVAILABLE` when nobody is eligible, **two simultaneous completions give one winner and one impact record**, an edit cannot be applied after acceptance, capacity re-checked inside the accept transaction, notes from every stage kept, duplicate open reports refused, query-count guards (no N+1 on organization and admin lists), LIKE wildcards in search are literal, **end-to-end matching through the API** (ranking, scores add up, exclusion reasons, expired donations excluded everywhere) |
| `test_reports.py` | 4 | Report and resolve, cannot report uninvolved donations, non-admin cannot update, "Other" needs details |

## Frontend tests (28 tests, Vitest + Testing Library)
```bash
cd frontend
npm test            # vitest run
npm run typecheck   # tsc --noEmit
npm run build       # type-check + production bundle
```
| File | Tests | What it proves |
|---|---|---|
| `hooks/useFetch.test.tsx` | 5 | Loading/error/reload; an **older, slower response never overwrites a newer one**; no state update after unmount |
| `hooks/useAuth.test.tsx` | 5 | Session restored from a stored token; signed out on 401; **a network error / 5xx does not sign the user out**; login/logout; forced sign-out event |
| `services/api.test.ts` | 7 | Bearer header and JSON body; per-field validation errors; friendly "cannot reach server" message; sign-out on expired/invalid token and on a deactivated account; no sign-out for a wrong password |
| `utils/format.test.ts` | 7 | Blank coordinates become `null` (never `0`), organization form <-> API payload, time-remaining text, datetime-local round trip |
| `components/EditDonationModal.test.tsx` | 4 | Pre-filled, saves through the API, blocks blank coordinates and past times, shows server errors and stays open |

## Verification actually performed on the final code
| Check | Result |
|---|---|
| `python -m compileall`, `pyflakes` (backend) | clean (only intentional re-exports) |
| Backend `pytest` | 131 passed; the whole suite was repeated 12 times in a row to detect flaky concurrency tests: 12/12 passed |
| Frontend `tsc --noEmit`, `npm run build`, `npm test` | clean / success / 28 passed |
| Real-browser end-to-end (Chromium via Playwright, real backend + production build) | 166 checks across desktop, iPhone 13, iPhone SE, Pixel 7 (Android), iPad and 1920px Windows-size viewports; 0 console errors, 0 server errors |
| Layout overflow scan at 320 px and 375 px on every page | no horizontal overflow |
| Live API authorization matrix (every route x anonymous/donor/organization/admin) | no unexpected access |
| Live API injection / token / CORS / error-leakage checks | 30/30 |

Honest limits: the browser checks use **viewport and user-agent emulation**, not physical devices or real Safari/WebKit;
map tiles come from OpenStreetMap and could not be loaded in the test sandbox (markers and layout were verified, tile images were not).

## Manual test checklist (for the demo)
1. Register a donor and an organization; log in and out.
2. Log in as the unverified organization: no matches, cannot accept. Verify it as admin, then it can.
3. Post a donation with past expiry or quantity 0: the form shows server messages.
4. Post a donation: see ranked organizations and their explanations.
5. Accept with one organization; try a second organization: refused.
6. Schedule pickup, collect, complete; check the impact numbers changed.
7. Try to cancel after pickup is scheduled as the donor: refused.
8. File a report, resolve it as admin; the donor sees the outcome under "Your reports on this donation".
9. As the donor, open a donation that is still waiting for an organization and use **Edit donation**; the matches are recalculated. After an organization accepts, the button disappears.
