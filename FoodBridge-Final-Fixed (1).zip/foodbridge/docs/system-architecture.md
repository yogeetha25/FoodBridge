# System architecture

## Three tiers
```
Browser: React + TypeScript + Tailwind + Leaflet
   |  HTTPS/JSON, Authorization: Bearer <JWT>
FastAPI application
   api/        routes: parse request, call a service, serialize response
   auth/       bcrypt hashing, JWT creation, role dependencies
   services/   business rules: donation workflow, impact, expiry, auth, reports, organizations
   matching/   scoring.py (pure), engine.py (loads data, saves matches)
   schemas/    Pydantic validation   models/  SQLAlchemy tables
   |
SQLite (development), accessed only through SQLAlchemy
Optional external: OpenStreetMap tiles (browser), OSRM routing (server, off by default)
```

## Request flow: creating a donation
1. React form posts `POST /api/donations` with the JWT.
2. `require_donor` decodes the token and checks the role.
3. Pydantic (`DonationCreate`) validates every field; invalid input returns 422 with per-field messages.
4. `donation_service.create_donation` saves the donation (AVAILABLE) and calls `matching.engine.compute_matches`.
5. The engine loads organizations and their committed load, calls the **pure** `rank_organizations`, deletes old matches,
   inserts new ones with rank and `score_breakdown`, and keeps the status honest: AVAILABLE becomes MATCHED if anyone is eligible, and MATCHED returns to AVAILABLE when nobody is.
6. The serializer returns the donation (hiding fields the viewer may not see).

## Data flow (summary)
Donor > donation > matching engine > matches > organization (recommended list) > accept (atomic update) > pickup row >
status changes > completion > impact record > analytics queries > charts.

## Key design decisions
* **Rule-based matching, no ML**: explainable, testable, no training data needed.
* **Pure functions for matching and the state machine**: no database needed to test them.
* **Atomic status changes**: every status change (accept, cancel, pickup, collect, complete, and the MATCHED/AVAILABLE flips) is one conditional `UPDATE ... WHERE status IN (...)` in `services/transitions.py`, so exactly one of two simultaneous requests wins and the other gets HTTP 409. Edits take a guard on the same row so they can never be applied after acceptance. Capacity is re-checked inside the acceptance transaction.
* **Timestamps in UTC**, serialized with a `Z`; the browser shows local time.
* **Single `users` table** for all roles; `organizations` is a 1:1 extension. `preferred_categories` is a JSON list rather than a junction table, which keeps the schema small.
* **Capacity is "meals the organization can take at one time"**; meals already committed (ACCEPTED, PICKUP_PENDING, COLLECTED) are subtracted.

## Status state machine
```
AVAILABLE -> MATCHED -> ACCEPTED -> PICKUP_PENDING -> COLLECTED -> COMPLETED
MATCHED -> AVAILABLE (nobody is eligible any more, e.g. after an edit or when capacity was used up)
AVAILABLE -> ACCEPTED (matching found nobody at creation time but an organization can still accept)
AVAILABLE / MATCHED / ACCEPTED -> EXPIRED (automatic)
AVAILABLE / MATCHED / ACCEPTED / PICKUP_PENDING -> CANCELLED (donors: not from PICKUP_PENDING)
COMPLETED, CANCELLED, EXPIRED are terminal
```
